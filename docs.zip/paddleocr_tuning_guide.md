# PaddleOCR: running it, reading the output, tuning it

PaddleOCR is the only OCR engine in this project. There is no fallback:
if Paddle is not installed, a scan stops with an error.

---

## 1. Install and check

```bash
pip install -r requirements.txt          # paddlepaddle + paddleocr are in it
python -c "import paddleocr; print(paddleocr.__version__)"    # 3.x
```

The first scan downloads the models (~200 MB) into `~/.paddlex`. That
needs internet once; after that it works offline.

GPU: uninstall `paddlepaddle`, install the `paddlepaddle-gpu` build for
your CUDA version, and pass `--device gpu:0`.

---

## 2. Scan

```bash
python scripts/scan_photo.py back_9.jpeg
python scripts/scan_photo.py photos/                        # a whole folder
python scripts/scan_photo.py back_9.jpeg --secondary-lang hi  # Hindi + English pack
python scripts/scan_photo.py back_9.jpeg --coverage-complete  # photo shows EVERY panel
```

Each photo produces:

| File | What it is |
|---|---|
| `data/reports/back_9.html` | The inspector report. At the bottom: **What was read** (each extracted declaration, with notes) and **Raw OCR lines** (every line Paddle read, with its confidence). |
| `data/ocr_dumps/back_9.paddle.json` | Exactly what Paddle read: text, score, polygon, settings, timings. **Send this file when a report looks wrong.** |
| `data/.ocr_cache/` | Cached OCR. Re-running the same photo after a code change skips the model, so it takes about a second. `--no-cache` forces a fresh read. |

The console prints the model used, OCR time, every extracted field and
every violation, so you usually don't need to open the HTML to see
whether a change helped.

---

## 3. When a report looks wrong

Open the HTML and expand **Raw OCR lines**.

- **The line is misread there** (e.g. `Net wt. 69` where the pack says
  `6 g`): an OCR problem. Try the settings in section 5.
- **The line is read correctly but the finding is still wrong**: an
  extraction or rules problem. Send the `.paddle.json`. It can be
  replayed without a model:

  ```bash
  python scripts/scan_photo.py back_9.jpeg --replay data/ocr_dumps/back_9.paddle.json
  ```

  This re-runs everything after OCR in under a second, so a fix can be
  checked against your exact photo.

Some findings are INDETERMINATE by design, because OCR loses these
things even when they are printed:

- **No ₹ read in the price.** Paddle drops or misreads the rupee sign,
  so a missing currency is never reported as a violation. Check the pack,
  and check the price did not gain a leading `7` or `2` (a ₹ misread as
  a digit).
- **"Inclusive of all taxes" read, but not on the price line.** Check it
  belongs to the MRP.
- **A unit inferred from a digit** (`69` read as `6 g`). The report adds
  a note to the declaration saying so.

---

## 4. What the backend changes from a plain `PaddleOCR().predict()`

These are fixed in the code (`src/vision/ocr/paddle.py`); you don't need
to set them.

1. **Document unwarping and orientation are OFF.** Paddle 3.x turns them
   on by default and then returns boxes in the coordinates of the
   *warped* image, not your photo. Every measurement that used those
   boxes (glyph height, clear space, evidence crops) pointed at the wrong
   pixels - the likeliest cause of the impossible width ratios (0.07,
   3.56) in the earlier reports.
2. **Small print gets more pixels.** The detector input is scaled up to
   at least 1280 px on its short side (Paddle's default never scales
   up), and photos under 1200 px are upscaled 2x before reading. Boxes
   are mapped back to the original photo.
3. **Weak lines get a second read.** Lines scoring below 0.80 are
   re-cropped with extra margin, so descenders survive (a clipped `g` is
   how `6 g` becomes `69`), upscaled 3x, contrast-normalised and read
   again. The new read replaces the old one only if it scores at least
   0.05 higher.
4. **Bilingual labels.** `--lang hi` loads a weaker mobile model and
   reads the English half badly. `--secondary-lang hi` keeps the strong
   English model and re-reads each line with the Devanagari model,
   keeping that read only where the line really is Devanagari.
5. **Rotated date codes.** Tall text boxes are rotated before reading, and
   the line is marked vertical so it is never spliced into the
   horizontal row next to it. Coded pairs like `MAR/26-NOV/26` are read
   as MFD/USE BY, with the earlier date taken as manufacture.
6. **Padded boxes.** Paddle's boxes sit well outside the ink. Clear
   space (Rule 8) is measured between the actual ink, not the boxes.
   Glyph height uses only the digits and capitals, identified by
   matching blobs to the recognised text, so brackets and descenders
   (`(approx.)`, `g`, `y`) are not mistaken for numerals.
7. **Models load once per process** and are shared, so a folder of
   photos pays the load cost once.
8. **OCR reads the photo as taken.** Our deglare/contrast/sharpen pass is
   now only used for measurement. On three real photos Paddle read the
   un-enhanced image better ("Strong, Long, Thick Hair" vs "Brong, Long,
   Thick Hak", "(Rs.0.40/ml)" vs "(Rs.0.4 0/ml)", the "6 g" beside NET
   QUANTITY found vs missed). `PipelineConfig(ocr_on_enhanced=True)` puts
   it back.
9. **Vertical inkjet codes are re-read rotated.** A narrow column of junk
   fragments (5, 寸, ON, 心 - the real Maggi date code) is cropped as one
   band, rotated both ways and read again as a line.
10. **Chinese glyphs are dropped** (PP-OCRv6 reads smudges as 印, 心, 出).

---

## 5. Tuning, when the raw lines are wrong

Compare several settings at once:

```bash
python scripts/paddle_probe.py back_9.jpeg
python scripts/paddle_probe.py photos/ --out data/probe.json
```

This prints one column per setting with each field's extracted value.
Where one setting gets a field right and the others don't, that setting
is the fix for that field. The individual flags on `scan_photo.py`:

| Symptom in Raw OCR lines | Try |
|---|---|
| Small print missing entirely | `--det-side 1920` (then 2560) |
| Faint or low-contrast print missing | `--det-thresh 0.2 --box-thresh 0.45` |
| Descenders cut off: `6 g`→`69`, `g`→`9` | `--unclip 2.0` |
| Two lines merged into one | `--unclip 1.3` |
| Everything plausible but noisy | `--ocr-version PP-OCRv5` to compare models |
| Many lines slightly wrong on a clean, sharp photo | the `noprep` column of `paddle_probe.py` (OCR without our deglare/contrast/sharpen pass) |
| Too slow on CPU | `--mkldnn` (if it doesn't crash), `--device gpu:0`, or `--no-refine` |

`--mkldnn` is off by default because on some Windows CPUs Paddle 3.x
crashes with `ConvertPirAttribute2RuntimeAttribute not support`. If it
runs on your machine it is noticeably faster.

What no setting fixes: glare over the text, a label curved away from the
camera, or text smaller than about 12 px tall in the photo. Retake those
closer, flatter, or at an angle that moves the glare.

---

## 6. Measuring without a printed marker

If the photo has no ArUco marker, measure the panel with a ruler and pass it:

```bash
python scripts/scan_photo.py back_9.jpeg --panel-mm 95x70
```

The scale then comes from the real panel edges found in the photo, the report
says "user_supplied_dimension", and the uncertainty is wider than with a
marker. **Never paste a marker into a photo afterwards**: its size in the
picture is whatever it was drawn at, so every millimetre measured from it is
invented.

## 7. Gemini for what OCR missed

```bash
set GEMINI_API_KEY=...        (pip install google-genai)
python scripts/scan_photo.py back_9.jpeg --vlm gemini
python scripts/scan_real.py back_9.jpeg          # uses Gemini automatically when the key is set
```

Gemini is asked only for the declarations OCR did not find, and must say where
it read them. If OCR read the same text there, the declaration is marked
`vlm+ocr` and counts normally. If only Gemini saw it, it is marked `vlm` and
every finding on it is INDETERMINATE, with a crop to confirm.

## 8. Measure progress on real photos

```bash
python scripts/real_eval.py
```

This replays the saved Paddle output in `tests/fixtures/real` against the
hand-written ground truth. It prints reads that are correct, wrong or missed,
plus false violations. To add a photo, put `name.jpg` and its
`data/ocr_dumps/name.paddle.json` there, add an entry to `ground_truth.yaml`,
and run it again.

## 9. Order to work in

1. `scan_photo.py` on 5-10 real photos (a folder at once).
2. For each wrong finding: Raw OCR lines, then decide whether it's OCR or
   extraction (section 3).
3. OCR problems: `paddle_probe.py` on those photos, pick a setting.
4. Extraction or rules problems: send the `.paddle.json` files.
5. One genuinely bilingual pack with `--secondary-lang hi`.
