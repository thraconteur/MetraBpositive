# Connecting the METRA app to the backend

The app takes the photo, the backend does everything else: OCR, rules, evidence crops, reports.
All of it is plain HTTP + JSON, so the stack doesn't matter (Flutter, React Native, Kotlin).

---

## 1. Run the backend so a phone can reach it

On the laptop (same Wi-Fi as the phone):

```bash
uvicorn src.api.main:app --host 0.0.0.0 --port 8000
```

- `--host 0.0.0.0` is what makes it reachable from the phone. Without it only the laptop can connect.
- Find the laptop's IP: `ipconfig` (Windows) → "IPv4 Address", e.g. `192.168.1.23`.
- From the phone's browser, open `http://192.168.1.23:8000/health`. If that loads, the app can connect too.
- Windows asks whether to let Python through the firewall. Allow it on **Private** networks.
- Android emulator: use `http://10.0.2.2:8000`, not localhost.
- Android blocks plain `http://` by default. For development, add `android:usesCleartextTraffic="true"` to `<application>` in `AndroidManifest.xml`. For a demo on the open internet, use HTTPS instead, e.g. `cloudflared tunnel --url http://localhost:8000`.
- The OCR models load in the background when the server starts (~30–60 s the first time). A scan sent before then waits for them. Set the app's request timeout to **at least 60 s**.

Optional, set on the server and never in the app:

```bash
set SIH_VLM=gemini              # Gemini reads what OCR missed (PowerShell: $env:SIH_VLM="gemini")
set GEMINI_API_KEY=...          # the key stays on the server
set SIH_CORS_ORIGINS=*          # web builds only; lock down for production
```

---

## 2. Auth

Every call needs a header:

```
Authorization: Bearer demo-inspector
```

The demo tokens are `demo-inspector` (scan + read), `demo-supervisor` (+ confirm / override) and `demo-admin`.
They're for the demo only. Real login replaces the `TOKENS` dict in `src/api/main.py`.

---

## 3. Screens → endpoints

| App screen | Call | Notes |
|---|---|---|
| **Scan** → take photo | `POST /scan` (multipart, field `file`) | Returns the full result plus an `app` block, shaped for the screens (below) |
| Scan → "Enter manually" size | same call with `?panel_width_mm=95&panel_height_mm=70` | A ruler measurement of the panel gives a mm scale when there's no printed marker in the frame |
| Scan → all panels photographed | `?coverage_complete=true` | Only then can "missing" become a violation instead of "to confirm" |
| **Result** detail | the `app` block, or `GET /scans/{id}/summary` | |
| Evidence thumbnail | `GET {evidence_url}` | PNG crop. Send the auth header with the image request |
| **History** | `GET /scans?q=maggi&verdict=non_compliant&limit=50` | |
| **Dashboard** | `GET /dashboard` | Totals, top violated rules, 30-day trend |
| Report share / download | `GET /scans/{id}/report?fmt=pdf` (or `html`, `docx`) | |
| Supervisor confirm / override | `POST /scans/{id}/action` `{"rule_id": "...", "action": "confirmed" \| "overridden", "note": "..."}` | Needs the supervisor token. Every action is logged |

---

## 4. The `app` block

```json
{
  "scan_id": "660d13b51f73",
  "verdict": "non_compliant",
  "product": {"name": "Atta Maggi", "category": "food_packaged"},
  "counts": {"violations": {"CRITICAL": 1, "MAJOR": 2, "MINOR": 0},
             "to_confirm": 4, "passed": 11},
  "checks": {"passed": 11, "failed": 3, "to_confirm": 4},
  "findings": [
    {"rule_id": "retail_sale_price.required_phrasing", "citation": "Rule 6(1)(e) ...",
     "outcome": "VIOLATION", "severity": "CRITICAL", "field": "retail_sale_price",
     "message": "Price stated without the required 'inclusive of all taxes' qualifier.",
     "measured": null, "required": null, "unit": "", "confidence": 0.9,
     "evidence_url": "/scans/660d13b51f73/evidence/660d13b51f73_03_retail_sale_price_required_phrasing.png"}
  ],
  "declarations": [
    {"field": "net_quantity", "value": 6.0, "unit": "g", "text": "NET QUANTITY: 69",
     "source": "ocr", "notes": ["Unit 'g' inferred from a '9' glyph ... confirm on the pack."]}
  ],
  "calibration": {"method": "none", "px_per_mm": null, "note": "No calibration marker detected in frame."},
  "retake_advice": ["Text is only 11 px tall in this photo - ... Retake this panel closer."],
  "report_urls": {"pdf": "/scans/.../report?fmt=pdf", "html": "...", "docx": "..."}
}
```

How to show it:

- **`verdict`** is `compliant`, `non_compliant` or `undecided`. Show `undecided` as "needs another photo", never as a pass.
- **`outcome`** per finding:
  - `VIOLATION`: red.
  - `INDETERMINATE`: "confirm by eye", amber. The system could not decide from this photo. Show the message; it says why.
  - `COMPLIANT`: green.
- **`source`** on a declaration:
  - `ocr`: normal.
  - `vlm+ocr`: Gemini read it and OCR agreed.
  - `vlm`: only Gemini read it. Show a "check this" tag; its findings are always `INDETERMINATE`.
- **`retake_advice`**: show it as a banner on the result. It's the "guided capture" message.
- **Score**: there's deliberately no "3/10" score. If the design needs a number, use `checks.passed` of `passed + failed`. It's a count anyone can check.

---

## 5. Minimal client code

**Flutter** (`http` package):

```dart
final req = http.MultipartRequest('POST', Uri.parse('$base/scan?product_name=$name'))
  ..headers['Authorization'] = 'Bearer demo-inspector'
  ..files.add(await http.MultipartFile.fromPath('file', photo.path));
final res = await http.Response.fromStream(await req.send().timeout(const Duration(seconds: 90)));
final app = jsonDecode(res.body)['app'];

// evidence image
Image.network('$base${f['evidence_url']}', headers: {'Authorization': 'Bearer demo-inspector'});
```

**React Native / Expo**:

```js
const form = new FormData();
form.append('file', { uri: photo.uri, name: 'scan.jpg', type: 'image/jpeg' });
const res = await fetch(`${BASE}/scan?product_name=${encodeURIComponent(name)}`, {
  method: 'POST', headers: { Authorization: 'Bearer demo-inspector' }, body: form,
});
const { app } = await res.json();

<Image source={{ uri: BASE + f.evidence_url, headers: { Authorization: 'Bearer demo-inspector' } }} />
```

Don't set `Content-Type` yourself for multipart. The library adds the boundary.

---

## 6. Error codes the app should handle

| Code | Meaning | App action |
|---|---|---|
| 400 | Empty or undecodable image | "Couldn't read the photo, try again" |
| 401 / 403 | Missing/invalid token, or role not allowed | Back to login |
| 413 | Image over 25 MB | Compress to JPEG ~2000 px long side before upload (also makes scans faster) |
| 404 | Unknown scan / evidence | Refresh history |
| 500 with "PaddleOCR is not installed" | Server set-up problem | Server-side: `pip install paddlepaddle paddleocr` |

---

## 7. Things on the current mock-ups the backend does not do

These appear on the PPT app screens. Change the design, or build the feature first, before showing them as working:

- **"Short Weight Deviation — measured weight 12% below declared"**. A photo can't weigh a pack. This needs a scale reading typed in or sent from a connected balance.
- **"Expired Batch Detected"**. Not implemented yet. The use-by date is often read (the date pair), so it's a small addition, but it isn't there today.
- **"Compliance rating 3/10"**. Not defined anywhere. See the score note in section 4.
