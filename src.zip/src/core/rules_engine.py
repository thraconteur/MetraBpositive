"""
The rules engine.

Reads rules/lmpc_2011.yaml and rules/exemptions.yaml, evaluates a set of
extracted declarations against them, and emits Findings with citations.

Three properties worth preserving if you rewrite this:

  1. NO LEGAL THRESHOLD IS HARDCODED HERE. Every number comes from the
     YAML. If you find yourself typing "2.1" into this file, stop.

  2. UNVERIFIED RULES CANNOT FIRE. If a rule's `verified` flag is false,
     the engine emits UNVERIFIED_RULE instead of VIOLATION. This is what
     stops a placeholder number from becoming a false accusation on an
     inspector's report.

  3. EXEMPTIONS RESOLVE BEFORE EVALUATION. classify -> exempt -> evaluate.
     Filtering violations after the fact produces subtly different (and
     wrong) results, because an exempt field should never have been
     measured against a threshold in the first place.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Optional

import yaml

from .schema import (
    BBox,
    Declaration,
    Finding,
    Outcome,
    PackageContext,
    ScanResult,
    Severity,
)

DEFAULT_RULES_DIR = Path(__file__).resolve().parents[2] / "rules"


_NUMBER_UNITS = {"piece", "pieces", "pc", "pcs", "no", "nos", "number", "unit",
                 "units", "n", "u", "set", "pair"}

_TAX_LETTERS = re.compile(r"incl[a-z]{0,7}of(?:al+)?tax")   # "alll" was read on a real sachet


def _ocr_conf(decl) -> float:
    """How cleanly the declaration's own text was read (0-1)."""
    if decl is None:
        return 0.0
    if decl.spans:
        return sum(sp.confidence for sp in decl.spans) / len(decl.spans)
    return min(1.0, (decl.extraction_confidence or 0.0) / 0.92)


# Absence of a word in OCR TEXT is only evidence of its absence on the
# PACK when that text was read cleanly. Below this, "not found in the
# text" is reported as something to confirm, never as a violation.
CLEAN_READ = 0.88


def _qualifier_resemblance(scan) -> tuple[bool, float, str]:
    """
    Does any read line look like a garbled tax qualifier?

    Two bars, both in rules/lexicon.yaml: a general one, and a lower one
    for a line that also names the MRP - "For MRP Rs. (nd of al aes),
    Batch No." is a real Dabur bottle printing "(incl. of all taxes)" by
    reference, and scores 65 where unrelated lines score about 50.
    """
    from ..extraction import fuzzy as _fz

    t = _fz.lexicon().get("thresholds") or {}
    general = float(t.get("qualifier_resemblance", 70))
    on_mrp_line = float(t.get("qualifier_resemblance_mrp_line", 60))
    best = (False, 0.0, "")
    for sp in scan.spans or []:
        low = (sp.text or "").lower()
        if not re.search(r"\bof\b|\(", low):
            continue
        mrp_line = bool(re.search(r"\bm\.?\s*r\.?\s*p\b|retail\s+price", low))
        score = max(_fz.resembles(sp.text, tgt, 0)[1]
                    for tgt in ("(incl. of all taxes)", "inclusive of all taxes"))
        hit = score >= (on_mrp_line if mrp_line else general)
        if (hit, score) > (best[0], best[1]):
            best = (hit, score, sp.text)
    return best


def _hold_vlm_only(scan, findings):
    """
    A declaration only a vision-language model read (source "vlm") cannot
    carry a verdict: the model may have read words that are not printed.
    Its findings become INDETERMINATE, keeping the message and the crop so
    the officer can confirm in seconds. Reads OCR confirmed ("vlm+ocr")
    are left alone.
    """
    vlm_only = {d.field_id for d in scan.declarations
                if d.present and getattr(d, "source", "ocr") == "vlm"}
    if not vlm_only:
        return findings
    for f in findings:
        if f.field_id in vlm_only and f.outcome in (Outcome.COMPLIANT, Outcome.VIOLATION):
            f.message = (f"[Vision-model read, not confirmed by OCR - would be "
                         f"{f.outcome.value}] {f.message}")
            f.outcome = Outcome.INDETERMINATE
            f.confidence = min(f.confidence, 0.45)
    return findings


def _has_tax_qualifier(text: str, variants) -> bool:
    """
    'Inclusive of all taxes' in any of the printed forms, compared on
    letters only so OCR spacing / punctuation loss does not matter.
    Also accepts the Hindi form (सभी करों सहित).
    """
    if not text:
        return False
    low = text.lower()
    letters = re.sub(r"[^a-z]", "", low)
    if _TAX_LETTERS.search(letters):
        return True
    for v in variants or []:
        vl = re.sub(r"[^a-z]", "", v.lower())
        if vl and vl in letters:
            return True
    dev = re.sub(r"\s+", "", text)
    return "\u0915\u0930\u094b\u0902\u0938\u0939\u093f\u0924" in dev or "\u0915\u0930\u094b\u0938\u0939\u093f\u0924" in dev


# =====================================================================
# Config loading
# =====================================================================

class RuleConfig:
    """Parsed view over the two YAML files."""

    def __init__(self, rules_dir: Path | str = DEFAULT_RULES_DIR):
        self.rules_dir = Path(rules_dir)
        with open(self.rules_dir / "lmpc_2011.yaml", encoding="utf-8") as fh:
            self.rules: dict = yaml.safe_load(fh)
        with open(self.rules_dir / "exemptions.yaml", encoding="utf-8") as fh:
            self.exemptions_doc: dict = yaml.safe_load(fh)

        self.declarations: list[dict] = self.rules.get("declarations", []) or []
        self.presentation: list[dict] = (
            (self.rules.get("presentation", []) or [])
            # Rules added by later amendments live in their own block but
            # evaluate identically - keep them in one list so no rule is
            # silently skipped because of where it sits in the file.
            + (self.rules.get("additional_rules", []) or [])
        )
        self.measurement: dict = self.rules.get("measurement", {}) or {}
        self.exemptions: list[dict] = self.exemptions_doc.get("exemptions", []) or []
        # Fail at load, with the offending rule named, rather than
        # mid-scan with a bare ValueError.
        self.validate(strict=True)

    # -- lookups ------------------------------------------------------

    def declaration(self, field_id: str) -> Optional[dict]:
        return next((d for d in self.declarations if d["id"] == field_id), None)

    def presentation_rule(self, rule_id: str) -> Optional[dict]:
        return next((p for p in self.presentation if p["id"] == rule_id), None)

    def exemption(self, ex_id: str) -> Optional[dict]:
        return next((e for e in self.exemptions if e["id"] == ex_id), None)

    @property
    def abstain_band_mm(self) -> float:
        return float(
            self.measurement.get("uncertainty", {}).get("abstain_band_mm", 0.3)
        )

    # Keys a rule entry may legitimately carry. Anything else is almost
    # certainly a typo, and a typo'd key in YAML is silently ignored -
    # the same failure mode that hid every other bug in this ruleset.
    _KNOWN_RULE_KEYS = {
        "id", "label", "short_label", "citation", "verified", "source", "severity", "notes",
        "checks", "check", "applies_unless", "applies_only_if", "formulas",
        "excluded_surfaces", "table_I", "table_II", "other_law_carve_out",
        "medical_device_carve_out", "requires_calibration", "proviso",
        "effective_from", "keyed_by", "bands", "boundary_reading",
    }

    def validate(self, strict: bool = True) -> list[str]:
        """
        Check the ruleset for typos and invalid values BEFORE it is used.

        Two failures motivated this. An invalid `severity` value raised a
        bare ValueError in the middle of evaluating a scan, so one typo
        took down every request with a stack trace that named neither the
        file nor the rule. And an unknown key - `verifed` for `verified` -
        was silently dropped by the YAML loader, quietly changing the
        rule's meaning with no error anywhere.
        """
        problems: list[str] = []
        valid_sev = {"critical", "major", "minor"}

        for item in self.declarations + self.presentation:
            rid = item.get("id", "<no id>")
            if "id" not in item:
                problems.append("a rule entry has no 'id'")
            if "citation" not in item:
                problems.append(f"{rid}: missing 'citation'")
            if "verified" not in item:
                problems.append(f"{rid}: missing 'verified' flag")
            sev = item.get("severity")
            if sev is not None and sev not in valid_sev:
                problems.append(
                    f"{rid}: severity {sev!r} is not one of {sorted(valid_sev)}"
                )
            unknown = set(item) - self._KNOWN_RULE_KEYS
            if unknown:
                problems.append(
                    f"{rid}: unrecognised key(s) {sorted(unknown)} - likely a typo, "
                    f"and unrecognised keys are silently ignored"
                )

        for ex in self.exemptions:
            if "id" not in ex:
                problems.append("an exemption entry has no 'id'")
            if "condition" not in ex and "relaxation" not in ex:
                problems.append(f"{ex.get('id','<no id>')}: missing 'condition'")

        if problems and strict:
            raise ValueError(
                "Invalid ruleset:\n  - " + "\n  - ".join(problems)
            )
        return problems

    def audit(self) -> dict:
        """
        Report which rules are still placeholders. Run this in CI and in
        your pitch - "17 of 19 rules verified against the gazette" is a
        much stronger claim than silence.
        """
        verified, unverified = [], []
        for item in self.declarations + self.presentation:
            (verified if item.get("verified") else unverified).append(item["id"])
        for ex in self.exemptions:
            (verified if ex.get("verified") else unverified).append(f"exemption:{ex['id']}")
        return {
            "verified": sorted(verified),
            "unverified": sorted(unverified),
            "coverage": len(verified) / max(1, len(verified) + len(unverified)),
        }


# =====================================================================
# Exemption resolution
# =====================================================================

class ExemptionResolver:
    """
    Decides which declarations do not apply to this package.

    Runs BEFORE evaluation. Returns a mapping field_id -> exemption_id
    so the engine can mark those findings NOT_APPLICABLE with a reason,
    rather than silently omitting them (an inspector needs to see that
    a field was considered and excused, not just missing from the list).
    """

    def __init__(self, config: RuleConfig):
        self.config = config

    def resolve(
        self,
        context: PackageContext,
        declarations: list[Declaration],
    ) -> dict[str, str]:
        exempted: dict[str, str] = {}
        by_id = {d.field_id: d for d in declarations}

        for ex in self.config.exemptions:
            if not self._condition_met(ex, context, by_id):
                continue
            for field_id in ex.get("exempts_declarations", []) or []:
                # First matching exemption wins; record which one.
                exempted.setdefault(field_id, ex["id"])
        return exempted

    def size_rule_relaxation(
        self,
        context: PackageContext,
        declarations: list[Declaration],
    ) -> tuple[bool, set[str], Optional[dict]]:
        """
        Rule 7(5): where the same information is required under ANOTHER
        law, the size rules in Rule 7(1)-(4) do not apply - EXCEPT for
        net quantity, retail sale price, expiry/best-before and consumer
        care, which always keep their minimum heights.

        Returns (relaxed, never_exempt_fields, exemption).

        This matters more than it looks. `other_law_applies` is set for
        every packaged food, beverage and pharmaceutical - i.e. most of
        a supermarket - because those are governed by FSSAI and the
        Drugs rules. The exemption resolved correctly and then did
        nothing, because `relax_size_rules` was never read by any code.
        Every one of those packages was being measured against Table-I
        for fields the Rules expressly relax.
        """
        by_id = {d.field_id: d for d in declarations}
        for ex in self.config.exemptions:
            eff = ex.get("effect") or {}
            if not eff.get("relax_size_rules"):
                continue
            if not self._condition_met(ex, context, by_id):
                continue
            never = set(eff.get("never_exempt_fields") or [])
            return True, never, ex
        return False, set(), None

    def deferred_to_other_law(
        self,
        context: PackageContext,
        declarations: list[Declaration],
    ) -> Optional[dict]:
        """
        Exemptions carrying `defer_to`: medical devices (Medical Devices
        Rules 2017) and alcoholic beverages (State Excise law). The size
        and declaration regime of a different statute governs, so
        asserting an LMPC violation would be wrong.

        Alcoholic beverages additionally carry `action:
        flag_for_human_review`, because whether State Excise actually
        provides for a price declaration is jurisdiction-dependent and
        not decidable from a photograph.
        """
        by_id = {d.field_id: d for d in declarations}
        for ex in self.config.exemptions:
            eff = ex.get("effect") or {}
            if not eff.get("defer_to"):
                continue
            if self._condition_met(ex, context, by_id):
                return ex
        return None

    def chapter_ii_exemption(
        self,
        context: PackageContext,
        declarations: list[Declaration],
    ) -> Optional[dict]:
        """
        Is this package outside Chapter II's scope ENTIRELY - Rule 3's
        >25kg/25L packages, cement/fertiliser/farm produce over 50kg
        bags, and goods for industrial or institutional consumers?

        This is a SCOPE question, not a per-declaration exemption, and
        it needed its own path. `resolve()` only ever populates fields
        listed under `exempts_declarations`, so an exemption whose only
        effect is `chapter_ii_not_applicable: true` and an empty
        `exempts_declarations` list - which is exactly how
        industrial_institutional, over_25kg_25l and farm_produce were
        written - resolved its CONDITION correctly and then exempted
        nothing at all. The condition fired; the effect was inert. All
        three exemptions were reachable and silently did nothing.

        Returns the matching exemption dict, or None if Chapter II
        applies normally.
        """
        by_id = {d.field_id: d for d in declarations}
        for ex in self.config.exemptions:
            if not (ex.get("effect") or {}).get("chapter_ii_not_applicable"):
                continue
            if self._condition_met(ex, context, by_id):
                return ex
        return None

    def _condition_met(
        self,
        ex: dict,
        ctx: PackageContext,
        by_id: dict[str, Declaration],
    ) -> bool:
        cond = ex.get("condition") or {}
        ctype = cond.get("type")

        if ctype == "net_quantity_at_most":
            # excluded_commodities sits on the EXEMPTION, not inside its
            # condition block, because it is a carve-out FROM the
            # exemption rather than a term of the quantity test itself.
            # GSR 881(E) (2025) added exactly one: pan masala loses the
            # <=10g/10ml exemption regardless of its actual size. This
            # branch previously ignored that field entirely, so the one
            # amendment clause specifically transcribed for this
            # exemption was silently never enforced.
            if ctx.commodity_category in (ex.get("excluded_commodities") or []):
                return False
            d = by_id.get("net_quantity")
            if not d or d.value is None or d.unit is None:
                return False
            qty = _normalise_quantity(d.value, d.unit)
            if qty is None:
                return False
            if not _same_dimension(d.unit, cond.get("units", [])):
                return False
            return qty <= float(cond["value"])

        if ctype == "package_capacity_at_most_cc":
            return ctx.capacity_cc is not None and ctx.capacity_cc <= float(cond["value"])

        if ctype == "package_capacity_greater_than_cc":
            return ctx.capacity_cc is not None and ctx.capacity_cc > float(cond["value"])

        if ctype == "package_class":
            return ctx.package_class == cond.get("value")

        if ctype == "commodity_category":
            return ctx.commodity_category == cond.get("value")

        if ctype == "flag":
            return bool(getattr(ctx, cond.get("value", ""), False))

        if ctype == "bag_weight_above_kg":
            # Rule 3(b): cement, fertiliser, agricultural farm produce in
            # bags above 50 kg. Referenced in exemptions.yaml since the
            # farm_produce entry was written but this branch was never
            # implemented - the exemption existed on paper and could
            # never actually fire, for any package, regardless of what
            # the classifier detected.
            if ctx.commodity_category not in (cond.get("commodities") or []):
                return False
            d = by_id.get("net_quantity")
            if not d or d.value is None or d.unit is None:
                return False
            qty_g = _normalise_quantity(d.value, d.unit)
            unit_l = _base_unit(d.unit)
            if qty_g is None or unit_l not in ("g", "kg"):
                return False
            return (qty_g / 1000.0) > float(cond["value"])

        if ctype == "net_quantity_above":
            # Rule 3(a): packages above 25 kg or 25 L. Same gap as above
            # - referenced, never implemented.
            d = by_id.get("net_quantity")
            if not d or d.value is None or d.unit is None:
                return False
            if not _same_dimension(d.unit, cond.get("units", [])):
                return False
            qty = _normalise_quantity(d.value, d.unit)
            if qty is None:
                return False
            # cond["value"] is in kg/L; qty is normalised to g/ml.
            return qty > float(cond["value"]) * 1000.0

        if ctype == "computed":
            # Only the one expression we actually support, evaluated
            # explicitly. Never eval() a config string.
            if cond.get("expr") == "unit_sale_price == retail_sale_price":
                usp, mrp = by_id.get("unit_sale_price"), by_id.get("retail_sale_price")
                # A pack of exactly ONE unit sold by number ("NET QUANTITY
                # 1 PIECE"): the price per unit IS the retail sale price,
                # so the second proviso applies whether or not a separate
                # unit price is printed. Flagging a wrist watch for not
                # printing "Rs. 1495.00 per piece" under its MRP of
                # Rs. 1495.00 is a finding no inspector would sign.
                nq = by_id.get("net_quantity")
                if (nq is not None and nq.present and nq.value is not None
                        and float(nq.value) == 1.0
                        and (nq.unit or "").lower().rstrip(".") in _NUMBER_UNITS
                        and (usp is None or usp.value is None)):
                    return True
                if not usp or not mrp:
                    return False
                if usp.value is None or mrp.value is None:
                    return False
                return abs(float(usp.value) - float(mrp.value)) < 1e-6
            return False

        return False


# =====================================================================
# The engine
# =====================================================================

# Check types the declaration evaluator implements. Anything outside
# this set is reported as unevaluated rather than skipped in silence.
_IMPLEMENTED_DECLARATION_CHECKS = {
    "presence", "banned_phrases", "required_phrasing", "unit_is_si",
    "decimal_places", "contact_reachable_format", "price_rounding",
    "currency_present", "date_plausible", "structure",
}


class RulesEngine:

    def __init__(
        self,
        config: Optional[RuleConfig] = None,
        relaxation_lookup=None,
    ):
        self.config = config or RuleConfig()
        self.resolver = ExemptionResolver(self.config)
        # Rule 33 lets a manufacturer apply for relaxation from specific
        # requirements. A granted relaxation is package-specific and
        # time-bound, so it lives in the database, not in the YAML - the
        # config says `lookup: database` and nothing ever read it. The
        # API created a `relaxations` table and the engine never queried
        # it, so a manufacturer holding a valid relaxation was still
        # reported as violating.
        #
        # Injected rather than hardwired to SQLite: the engine must stay
        # runnable with no database at all (tests, batch jobs), and a
        # missing lookup means "no relaxations on record", never a crash.
        self.relaxation_lookup = relaxation_lookup

    def _relaxation_for(self, scan: ScanResult, rule_id: str) -> Optional[dict]:
        if self.relaxation_lookup is None:
            return None
        decl = scan.declaration("manufacturer_details")
        manufacturer = decl.raw_text if decl and decl.present else None
        if not manufacturer:
            return None
        try:
            return self.relaxation_lookup(manufacturer, rule_id)
        except Exception:
            # A failing lookup must never turn into a false compliance
            # result; treat it as "no relaxation on record".
            return None

    def _apply_relaxations(self, scan: ScanResult, findings: list[Finding]) -> list[Finding]:
        """
        Suppress violations covered by a Rule 33 relaxation.

        The finding is RECORDED as suppressed, never dropped: an
        inspector needs to see that a relaxation was claimed, by whom,
        and under what reference. Silently removing it would hide the
        claim from the person who has to sign off on the report.
        """
        if self.relaxation_lookup is None:
            return findings

        # Rule 33(2): where the Medical Devices Rules 2017 apply, the
        # Rule 33 relaxation does not. Without this check a medical
        # device manufacturer holding any relaxation record could
        # suppress findings the Rules say they cannot relax - a hole
        # opened by implementing relaxations at all.
        deferred = self.resolver.deferred_to_other_law(
            scan.context, scan.declarations
        )
        if deferred and (deferred.get("effect") or {}).get("relaxation_unavailable"):
            return findings

        for f in findings:
            if f.outcome is not Outcome.VIOLATION:
                continue
            rec = self._relaxation_for(scan, f.rule_id)
            if not rec:
                continue
            f.outcome = Outcome.SUPPRESSED
            ref = rec.get("reference") or "unreferenced"
            until = rec.get("valid_until") or "no expiry recorded"
            f.message += (
                f" [Suppressed under Rule 33 relaxation {ref}, valid until {until}."
                f" Recorded for inspector review, not dismissed.]"
            )
            f.exemption_applied = "relaxation_rule_33"
        return findings

    # -----------------------------------------------------------------
    def evaluate(self, scan: ScanResult) -> ScanResult:
        """Populate scan.findings. Mutates and returns the scan."""
        findings: list[Finding] = []

        if not scan.image_quality_ok:
            findings.append(
                Finding(
                    rule_id="image_quality_gate",
                    citation="measurement.image_quality_gate",
                    outcome=Outcome.INDETERMINATE,
                    severity=Severity.MINOR,
                    message=(
                        "Image quality below threshold - retake requested. "
                        f"{scan.quality_notes}"
                    ),
                    confidence=1.0,
                )
            )
            scan.findings = findings
            return scan

        # Scope gate BEFORE anything else. If this package is outside
        # Chapter II entirely - a >25kg/25L pack, a 50kg+ cement or
        # fertiliser bag, or a package for an industrial/institutional
        # consumer - evaluating individual rules against it is
        # meaningless, and doing so risks producing a violation report
        # for a package the Rules never governed in the first place.
        ch2 = self.resolver.chapter_ii_exemption(scan.context, scan.declarations)
        if ch2 is not None:
            findings.append(
                Finding(
                    rule_id="chapter_ii_scope",
                    citation=ch2.get("citation", "Rule 3"),
                    outcome=Outcome.NOT_APPLICABLE,
                    severity=Severity.MINOR,
                    message=(
                        f"Package is outside the scope of Chapter II "
                        f"({ch2.get('label', ch2['id'])}); no declaration "
                        f"or presentation rule in this chapter applies."
                    ),
                    exemption_applied=ch2["id"],
                    rule_verified=bool(ch2.get("verified", False)),
                    confidence=1.0,
                )
            )
            scan.findings = findings
            return scan

        exempted = self.resolver.resolve(scan.context, scan.declarations)

        # -- Rule 6: presence and content of each declaration ----------
        for spec in self.config.declarations:
            findings.extend(self._eval_declaration(spec, scan, exempted))

        # -- Rules 7-9: presentation --------------------------------
        for spec in self.config.presentation:
            if "check" not in spec:
                continue  # e.g. pdp_area_formula is data, not a check
            findings.extend(
                self._eval_presentation(spec, scan, exempted, findings)
            )

        findings = _hold_vlm_only(scan, findings)
        scan.findings = self._apply_relaxations(scan, findings)
        return scan

    # -----------------------------------------------------------------
    def _eval_declaration(
        self,
        spec: dict,
        scan: ScanResult,
        exempted: dict[str, str],
    ) -> list[Finding]:
        field_id = spec["id"]
        citation = spec.get("citation", "")
        severity = Severity(spec.get("severity", "minor"))
        verified = bool(spec.get("verified", False))
        out: list[Finding] = []

        # applies_only_if gate (e.g. country_of_origin for imports)
        only_if = spec.get("applies_only_if") or []
        if "imported_goods" in only_if and not scan.context.is_imported:
            return [
                Finding(
                    rule_id=field_id,
                    citation=citation,
                    outcome=Outcome.NOT_APPLICABLE,
                    severity=severity,
                    field_id=field_id,
                    message="Not an imported package.",
                    rule_verified=verified,
                    confidence=1.0,
                )
            ]

        if field_id in exempted:
            ex_id = exempted[field_id]
            ex = self.config.exemption(ex_id) or {}

            # Some exemptions cannot be resolved from a photograph.
            # Alcoholic beverages defer to State Excise law, and whether
            # that law provides for a price declaration is
            # jurisdiction-dependent - so the config marks them
            # `action: flag_for_human_review`. Auto-clearing them would
            # silently pass packages nobody actually checked; that key
            # existed and was never read.
            if ex.get("action") == "flag_for_human_review":
                return [
                    Finding(
                        rule_id=field_id,
                        citation=citation,
                        outcome=Outcome.INDETERMINATE,
                        severity=severity,
                        field_id=field_id,
                        message=(
                            f"{ex.get('label', ex_id)} ({ex.get('citation','')}): "
                            f"cannot be decided from the package alone - depends on "
                            f"the law of the manufacturing State. Referred for "
                            f"inspector review rather than cleared."
                        ),
                        exemption_applied=ex_id,
                        rule_verified=verified and bool(ex.get("verified", False)),
                        confidence=0.5,
                    )
                ]

            return [
                Finding(
                    rule_id=field_id,
                    citation=citation,
                    outcome=Outcome.NOT_APPLICABLE,
                    severity=severity,
                    field_id=field_id,
                    message=f"Exempt: {ex.get('label', ex_id)} ({ex.get('citation','')}).",
                    exemption_applied=ex_id,
                    rule_verified=verified and bool(ex.get("verified", False)),
                    confidence=1.0,
                )
            ]

        decl = scan.declaration(field_id)

        for check in spec.get("checks", []) or []:
            ctype = check.get("type")
            # A check may carry its own verified flag (e.g. banned_phrases).
            check_verified = verified and bool(check.get("verified", True))
            check_citation = check.get("citation", citation)

            if ctype == "presence":
                present = bool(decl and decl.present)

                # Absence cannot be established from a partial view.
                if not present and not scan.coverage_complete:
                    out.append(
                        Finding(
                            rule_id=f"{field_id}.presence",
                            citation=check_citation,
                            outcome=Outcome.INDETERMINATE,
                            severity=severity,
                            field_id=field_id,
                            message=(
                                f"{spec['label']} not visible in this image. A "
                                f"single view cannot establish that it is absent "
                                f"from the package - declarations are routinely "
                                f"split across panels. Capture the remaining "
                                f"panels to decide this."
                            ),
                            confidence=0.9 if scan.image_quality_ok else 0.4,
                            rule_verified=check_verified,
                        )
                    )
                    break

                out.append(
                    Finding(
                        rule_id=f"{field_id}.presence",
                        citation=check_citation,
                        outcome=Outcome.COMPLIANT if present else Outcome.VIOLATION,
                        severity=severity,
                        field_id=field_id,
                        # PRESENCE ONLY. The old wording ("Retail sale
                        # price (MRP), inclusive of all taxes present.")
                        # sat in the same report as "Price stated without
                        # the 'inclusive of all taxes' qualifier" and read
                        # as a contradiction. This row only says the
                        # declaration was LOCATED; its content is judged
                        # by the separate checks.
                        message=(
                            f"{spec.get('short_label') or spec['label']} located. "
                            f"(Presence only - its content is assessed by the "
                            f"other checks on this field.)"
                            if present
                            else f"{spec['label']} not found on the package."
                        ),
                        evidence_bbox=decl.bbox if decl else None,
                        # Confidence in the FINDING, not in an extraction
                        # that by definition did not happen. When a field
                        # is absent the declaration object still exists
                        # with extraction_confidence 0.0, so a critical
                        # violation was rendered as "Conf. 0.00" - which
                        # reads to an inspector as "the system is unsure",
                        # exactly inverting the meaning. Absence is a
                        # confident finding when the image was readable;
                        # it is the IMAGE we might doubt, not the result.
                        confidence=(
                            decl.extraction_confidence
                            if (present and decl)
                            else (0.9 if scan.image_quality_ok else 0.4)
                        ),
                        rule_verified=check_verified,
                    )
                )
                if not present:
                    # No point running content checks on an absent field.
                    break

            elif ctype == "banned_phrases" and decl:
                hit = _find_banned_phrase(decl.raw_text, check.get("phrases", []))
                allowed = self._conditional_phrase_allowed(check, scan.context, decl.raw_text)
                if hit and not allowed:
                    out.append(
                        Finding(
                            rule_id=f"{field_id}.banned_phrase",
                            citation=check_citation,
                            outcome=Outcome.VIOLATION if check_verified else Outcome.UNVERIFIED_RULE,
                            severity=Severity.MAJOR,
                            field_id=field_id,
                            message=(
                                f"Quantity declaration contains the qualifying "
                                f"expression '{hit}', which creates an exaggerated "
                                f"or inadequate impression of quantity."
                            ),
                            evidence_bbox=decl.bbox,
                            confidence=0.95,
                            rule_verified=check_verified,
                        )
                    )
                else:
                    out.append(
                        Finding(
                            rule_id=f"{field_id}.banned_phrase",
                            citation=check_citation,
                            outcome=Outcome.COMPLIANT,
                            severity=Severity.MINOR,
                            field_id=field_id,
                            message="No prohibited qualifying expression found.",
                            confidence=0.9,
                            rule_verified=check_verified,
                        )
                    )

            elif ctype == "required_phrasing" and decl:
                # Matched on LETTERS ONLY. PaddleOCR returns whole lines
                # and routinely drops or merges the spaces and dots in
                # small print: "(Incl.of all taxes)", "Incl.ofalltaxes",
                # "INCL OF ALL TAXES)". A literal substring test missed
                # every one of those on a real Maggi sachet and reported
                # a missing qualifier that was plainly printed.
                ok = _has_tax_qualifier(decl.raw_text, check.get("any_of", []))
                elsewhere = (not ok) and any(
                    _has_tax_qualifier(sp.text, check.get("any_of", []))
                    for sp in (scan.spans or [])
                )
                looks_like, resemblance, resembling = (False, 0.0, "")
                if not ok and not elsewhere:
                    looks_like, resemblance, resembling = _qualifier_resemblance(scan)
                if ok:
                    outcome, conf = Outcome.COMPLIANT, 0.9
                    msg = "Price carries the inclusive-of-all-taxes qualifier."
                elif looks_like:
                    # "For MRP Rs. (nd of al aes)" - a real bottle printing
                    # "(incl. of all taxes)" in 5-point type. Probably the
                    # qualifier, garbled by OCR; not ours to call either way.
                    outcome, conf = Outcome.INDETERMINATE, 0.5
                    msg = (f"A line that looks like the tax qualifier was read as "
                           f"'{resembling.strip()}' ({resemblance:.0f}% similar). "
                           f"Confirm on the pack that 'inclusive of all taxes' is printed.")
                elif _ocr_conf(decl) < CLEAN_READ:
                    outcome, conf = Outcome.INDETERMINATE, 0.5
                    msg = ("No 'inclusive of all taxes' qualifier was read, but the "
                           "price was read with low OCR confidence "
                           f"({_ocr_conf(decl):.2f}). Confirm on the pack.")
                elif elsewhere:
                    # The words are on the panel, just not on a line the
                    # extractor tied to the price (wrapped into another
                    # column, or read as a separate text block). Not a
                    # violation we can stand behind.
                    outcome, conf = Outcome.INDETERMINATE, 0.6
                    msg = ("An 'inclusive of all taxes' qualifier was read on the "
                           "panel but not on the price line. Confirm visually that "
                           "it belongs to the MRP.")
                else:
                    outcome, conf = Outcome.VIOLATION, 0.9 if scan.image_quality_ok else 0.5
                    msg = ("Price stated without the required "
                           "'inclusive of all taxes' qualifier.")
                out.append(
                    Finding(
                        rule_id=f"{field_id}.required_phrasing",
                        citation=check_citation,
                        outcome=outcome,
                        severity=severity,
                        field_id=field_id,
                        message=msg,
                        evidence_bbox=decl.bbox,
                        confidence=conf,
                        rule_verified=check_verified,
                    )
                )

            elif ctype == "unit_is_si" and decl:
                allowed = check.get("allowed_units", [])
                unit_ok = decl.unit in allowed or _base_unit(decl.unit or "") in allowed
                out.append(
                    Finding(
                        rule_id=f"{field_id}.unit_is_si",
                        citation=check_citation,
                        outcome=Outcome.COMPLIANT if unit_ok else Outcome.VIOLATION,
                        severity=Severity.MAJOR,
                        field_id=field_id,
                        message=(
                            f"Quantity declared in '{decl.unit}'."
                            if unit_ok
                            else f"Quantity unit '{decl.unit}' is not a permitted SI unit."
                        ),
                        evidence_bbox=decl.bbox,
                        confidence=0.9,
                        rule_verified=check_verified,
                    )
                )

            elif ctype == "decimal_places" and decl and decl.raw_text:
                want = int(check.get("exactly", 2))
                m = re.search(r"\d+\.(\d+)", decl.raw_text)
                ok = bool(m and len(m.group(1)) == want)
                out.append(
                    Finding(
                        rule_id=f"{field_id}.decimal_places",
                        citation=check_citation,
                        outcome=Outcome.COMPLIANT if ok else Outcome.VIOLATION,
                        severity=Severity.MINOR,
                        field_id=field_id,
                        message=(
                            f"Unit sale price stated to {want} decimal places."
                            if ok
                            else f"Unit sale price not stated to {want} decimal places."
                        ),
                        evidence_bbox=decl.bbox,
                        confidence=0.85,
                        rule_verified=check_verified,
                    )
                )

            elif ctype == "price_rounding" and decl and decl.raw_text:
                # Rule 6(1)(e) as amended 2017: price in rupees and paise
                # rounded to the nearest rupee or 50 paise. So .00 and
                # .50 are compliant and Rs.119.99 is not. Transcribed
                # from the gazette and then never implemented - the
                # engine's elif chain simply fell through on an unknown
                # check type and emitted no finding at all.
                allowed = check.get("allowed_paise_endings", [0, 50])
                m = re.search(r"(\d+)\.(\d{2})", decl.raw_text)
                if m:
                    paise = int(m.group(2))
                    ok = paise in allowed
                    out.append(
                        Finding(
                            rule_id=f"{field_id}.price_rounding",
                            citation=check_citation,
                            outcome=Outcome.COMPLIANT if ok else Outcome.VIOLATION,
                            severity=Severity.MINOR,
                            field_id=field_id,
                            message=(
                                "Price rounded to the nearest rupee or 50 paise."
                                if ok else
                                f"Price ends in {paise:02d} paise; the Rules require "
                                f"rounding to the nearest rupee or 50 paise."
                            ),
                            evidence_bbox=decl.bbox,
                            confidence=0.9,
                            rule_verified=check_verified,
                        )
                    )

            elif ctype == "currency_present" and decl:
                symbols = check.get("symbols", ["Rs", "Rs.", "INR", "\u20b9"])
                low = decl.raw_text.lower()
                ok = any(sym.lower() in low for sym in symbols) or bool(
                    re.search(r"\u0930\u0941|\u0930\u0942", decl.raw_text)  # रु / रू
                )
                # ABSENCE IS NOT ASSERTED. The rupee sign is the glyph OCR
                # handles worst: PaddleOCR drops it, or reads it as '?',
                # 'F', 'Z', 'R' or even a leading '7' / '2'. On a real
                # sachet printing "MRP \u20b910.00" this check reported a
                # MAJOR violation for a symbol that was there. A missing
                # currency in the TEXT is therefore reported as something
                # for the officer to confirm, never as a violation.
                out.append(
                    Finding(
                        rule_id=f"{field_id}.currency_present",
                        citation=check_citation,
                        outcome=Outcome.COMPLIANT if ok else Outcome.INDETERMINATE,
                        severity=Severity.MAJOR,
                        field_id=field_id,
                        message=(
                            "Price carries a currency indication."
                            if ok else
                            "No currency indication (Rs., INR or \u20b9) was read in "
                            "the price text. OCR frequently drops or misreads the "
                            "\u20b9 sign, so this is not asserted as a violation - "
                            "confirm on the pack. If \u20b9 is present, also check "
                            "the price was not misread with an extra leading digit."
                        ),
                        evidence_bbox=decl.bbox,
                        confidence=0.85 if ok else 0.5,
                        rule_verified=check_verified,
                    )
                )

            elif ctype == "date_plausible" and decl and decl.raw_text:
                # A future manufacture date is prima facie non-compliant.
                import datetime as _dt

                allow_future = bool(check.get("allow_future", False))
                # The extracted VALUE is the manufacture date. Re-parsing
                # raw_text picked the use-by date out of "03/2026 (B4) /
                # 03/2029" on a real bottle and called it "in the future".
                m = re.fullmatch(r"(\d{1,2})/(\d{4})", str(decl.value or "")) or \
                    re.search(r"(\d{1,2})\s*[/\-.]\s*(\d{4})", decl.raw_text)
                if m:
                    mon, yr = int(m.group(1)), int(m.group(2))
                    now = _dt.datetime.now(_dt.UTC)
                    valid_month = 1 <= mon <= 12
                    future = (yr, mon) > (now.year, now.month)
                    ok = valid_month and (allow_future or not future)
                    out.append(
                        Finding(
                            rule_id=f"{field_id}.date_plausible",
                            citation=check_citation,
                            outcome=Outcome.COMPLIANT if ok else Outcome.VIOLATION,
                            severity=Severity.MAJOR,
                            field_id=field_id,
                            message=(
                                f"Date {mon:02d}/{yr} is plausible."
                                if ok else
                                f"Date {mon:02d}/{yr} is not plausible"
                                + (" (month out of range)." if not valid_month
                                   else " (dated in the future).")
                            ),
                            evidence_bbox=decl.bbox,
                            confidence=0.85,
                            rule_verified=check_verified,
                        )
                    )

            elif ctype == "structure" and decl:
                # A complete address under Rule 10 needs enough parts to
                # actually locate the manufacturer, not just a company
                # name. Counts commas plus any PIN code as components.
                need = int(check.get("min_components", 2))
                parts = [x for x in re.split(r"[,\n]", decl.raw_text) if x.strip()]
                has_pin = bool(re.search(r"\b\d{6}\b", decl.raw_text))
                found = len(parts) + (1 if has_pin else 0)
                ok = found >= need
                clean_read = _ocr_conf(decl) >= CLEAN_READ
                out.append(
                    Finding(
                        rule_id=f"{field_id}.structure",
                        citation=check_citation,
                        outcome=(Outcome.COMPLIANT if ok else
                                 Outcome.VIOLATION if clean_read else
                                 Outcome.INDETERMINATE),
                        severity=severity,
                        field_id=field_id,
                        message=(
                            "Address appears to be a complete postal address."
                            if ok else
                            "Address appears incomplete - a complete postal "
                            "address is required so a consumer can locate the "
                            "manufacturer, packer or importer."
                            if clean_read else
                            "No complete postal address (PIN code, locality) was "
                            "read in the address block, which was read with low "
                            "OCR confidence. Confirm on the pack."
                        ),
                        evidence_bbox=decl.bbox,
                        confidence=0.7,
                        rule_verified=check_verified,
                    )
                )

            elif ctype == "contact_reachable_format" and decl:
                # REGRESSION FOUND ON A REAL PHOTO. The old pattern only
                # matched a single unbroken 10-digit run or exactly ONE
                # separator, which fails on the printed format almost
                # every Indian toll-free number actually uses: grouped
                # digits with a space or hyphen between EACH group, e.g.
                # "1800 103 1947" or "1800-103-1947" (4-3-4). Neither
                # matched, and this check fell back to whether an email
                # happened to survive in the same window - so a page
                # printing a perfectly legible toll-free number could
                # still be reported as lacking a usable phone.
                has_phone = bool(re.search(
                    r"(?:\+?91[\s-]?)?\d(?:[\s-]?\d){9}\b", decl.raw_text
                ))
                has_email = bool(re.search(r"[\w.+-]+@[\w-]+\.[\w.]+", decl.raw_text))
                ok = has_phone or has_email
                if ok:
                    msg = "Consumer care contact present ("
                    msg += ", ".join(
                        x for x, present in
                        [("phone", has_phone), ("email", has_email)] if present
                    ) + ")."
                else:
                    msg = (
                        "Consumer care details lack a phone number or email "
                        "in a recognisable format. If a phone or email is "
                        "visible on the pack, this may be an extraction "
                        "issue rather than an absent declaration - check "
                        "against the raw OCR text."
                    )
                clean_read = _ocr_conf(decl) >= CLEAN_READ
                out.append(
                    Finding(
                        rule_id=f"{field_id}.contact_format",
                        citation=check_citation,
                        outcome=(Outcome.COMPLIANT if ok else
                                 Outcome.VIOLATION if clean_read else
                                 Outcome.INDETERMINATE),
                        severity=severity,
                        field_id=field_id,
                        message=msg,
                        evidence_bbox=decl.bbox,
                        confidence=0.85 if ok else 0.5,
                        rule_verified=check_verified,
                    )
                )


            elif ctype not in _IMPLEMENTED_DECLARATION_CHECKS:
                # An unrecognised check type used to fall straight
                # through this chain and emit nothing - the rule looked
                # implemented in the config, carried a citation, and
                # produced no finding whatsoever. Four real checks
                # (price_rounding, currency_present, date_plausible,
                # structure) sat dead this way. Fail loudly instead.
                out.append(
                    Finding(
                        rule_id=f"{field_id}.{ctype}",
                        citation=check_citation,
                        outcome=Outcome.UNVERIFIED_RULE,
                        severity=Severity.MINOR,
                        field_id=field_id,
                        message=(
                            f"Check type '{ctype}' is declared in the ruleset "
                            f"but not implemented by the engine, so this "
                            f"requirement was NOT evaluated."
                        ),
                        rule_verified=False,
                        confidence=0.0,
                    )
                )
        return out

    def _conditional_phrase_allowed(
        self, check: dict, ctx: PackageContext, text: str
    ) -> bool:
        for cp in check.get("conditional_phrases", []) or []:
            if cp["phrase"].lower() in text.lower():
                if ctx.commodity_category in (cp.get("allowed_for_categories") or []):
                    return True
        return False

    # -----------------------------------------------------------------
    def _eval_presentation(
        self,
        spec: dict,
        scan: ScanResult,
        exempted: dict[str, str],
        findings_so_far: list[Finding] = (),
    ) -> list[Finding]:
        rule_id = spec["id"]
        citation = spec.get("citation", "")
        severity = Severity(spec.get("severity", "minor"))
        verified = bool(spec.get("verified", False))
        check = spec.get("check", {})
        ctype = check.get("type")

        # -- Rule 7(3): width >= 1/3 height. No calibration needed. ----
        if ctype == "aspect_ratio":
            return self._eval_aspect_ratio(spec, check, scan, verified, citation, severity)

        # -- Rule 8: clear space. No calibration needed. ---------------
        if ctype == "clear_space":
            return self._eval_clear_space(spec, check, scan, verified, citation, severity)

        # -- Rule 7(2): minimum height in mm. Needs calibration. -------
        if ctype == "min_height_mm":
            return self._eval_min_height(spec, scan, verified, citation, severity)

        # -- Rule 7: grouping on the PDP -------------------------------
        if ctype == "all_declarations_within_region":
            return self._eval_pdp_grouping(
                spec, scan, verified, citation, severity, findings_so_far
            )

        if ctype == "overlay_detection":
            return self._eval_sticker(spec, scan, verified, citation, severity)

        if ctype == "token_at_pdp_top":
            return self._eval_gm_label(spec, check, scan, verified, citation, severity)

        return []

    # -- Rule 6(3): sticker altering a declaration ---------------------

    def _eval_sticker(self, spec, scan, verified, citation, severity):
        """
        A sticker is unlawful only if it conceals the printed MRP or
        raises the price. The proviso permits a downward revision that
        leaves the original visible, so this must not fire on every
        pasted label - see vision/overlay.py.
        """
        from ..vision.overlay import assess_price_overlay

        if getattr(scan, "overlay_detection_failed", False):
            return [
                Finding(
                    rule_id="sticker_alteration",
                    citation=citation,
                    outcome=Outcome.INDETERMINATE,
                    severity=severity,
                    field_id="retail_sale_price",
                    message=(
                        "Sticker detection failed on this image; whether a "
                        "pasted label conceals the price could not be "
                        "determined. Not asserting compliance."
                    ),
                    rule_verified=verified,
                    confidence=0.0,
                )
            ]

        overlays = getattr(scan, "overlays", None)
        if overlays is None:
            return []

        mrp = scan.declaration("retail_sale_price")
        mrp_bbox = mrp.bbox if mrp and mrp.present else None

        violation, reason, ov = assess_price_overlay(
            overlays,
            mrp_bbox,
            printed_price=getattr(scan.context, "printed_price", None),
            sticker_price=getattr(scan.context, "sticker_price", None),
        )
        return [
            Finding(
                rule_id="sticker_alteration",
                citation=citation,
                outcome=Outcome.VIOLATION if violation else Outcome.COMPLIANT,
                severity=severity,
                field_id="retail_sale_price",
                message=reason,
                evidence_bbox=(ov.bbox if ov else mrp_bbox),
                confidence=(ov.confidence if ov else 0.7),
                rule_verified=verified,
            )
        ]

    # -- Rule 6(7): 'GM' at the top of the PDP -------------------------

    def _eval_gm_label(self, spec, check, scan, verified, citation, severity):
        """
        Reads facts the vision stage already established. Detection lives
        in the pipeline because the mark has to be looked for on both the
        rectified and the original image - rectification resamples a 3mm
        mark near the panel edge badly enough to turn "GM" into "|".
        """
        only_if = check.get("applies_only_if", []) or []
        if "genetically_modified_food" in only_if and not getattr(
            scan.context, "genetically_modified_food", False
        ):
            return [
                Finding(
                    rule_id="gm_food_label",
                    citation=citation,
                    outcome=Outcome.NOT_APPLICABLE,
                    severity=severity,
                    message="Not declared as genetically modified food.",
                    rule_verified=verified,
                    confidence=1.0,
                )
            ]

        token = check.get("token", "GM")

        if getattr(scan.context, "gm_detection_failed", False):
            return [
                Finding(
                    rule_id="gm_food_label",
                    citation=citation,
                    outcome=Outcome.INDETERMINATE,
                    severity=severity,
                    message=(
                        f"Detection of the '{check.get('token', 'GM')}' mark "
                        f"failed on this image; absence could not be "
                        f"established. Not asserting a violation."
                    ),
                    rule_verified=verified,
                    confidence=0.0,
                )
            ]

        present = getattr(scan.context, "gm_mark_present", False)
        at_top = getattr(scan.context, "gm_mark_at_top", False)

        if not present:
            outcome = Outcome.VIOLATION
            msg = (f"Genetically modified food does not bear the mark "
                   f"'{token}' on the principal display panel.")
        elif not at_top:
            # A distinct finding from absence: the mark exists but is in
            # the wrong place, and an inspector needs to know which.
            outcome = Outcome.VIOLATION
            msg = (f"The mark '{token}' is present but not at the top of "
                   f"the principal display panel as required.")
        else:
            outcome = Outcome.COMPLIANT
            msg = f"'{token}' declared at the top of the principal display panel."

        return [
            Finding(
                rule_id="gm_food_label",
                citation=citation,
                outcome=outcome,
                severity=severity,
                message=msg,
                evidence_bbox=scan.context.pdp_bbox,
                confidence=0.8,
                rule_verified=verified,
            )
        ]

    # -- individual presentation checks --------------------------------

    def _eval_aspect_ratio(self, spec, check, scan, verified, citation, severity):
        out = []
        min_ratio = float(check.get("min_width_over_height", 1 / 3))
        for field_id in check.get("applies_to_fields", []):
            if field_id in exempt_set(scan, self.config):
                continue
            decl = scan.declaration(field_id)
            if not decl or not decl.glyph or decl.glyph.width_over_height is None:
                continue
            ratio = decl.glyph.width_over_height
            n_glyphs = decl.glyph.n_glyphs_measured

            # PLAUSIBILITY FLOOR. Printed text does not get narrower than
            # roughly 0.15 - even aggressively condensed type measured
            # 0.25 in controlled tests, and the rule's own threshold is
            # 0.33. A real photograph produced 0.08, i.e. characters
            # twelve times taller than wide, which is not text at all but
            # a merged stroke, a box spanning two lines, or noise. The
            # engine asserted a Rule 7(3) VIOLATION from that reading.
            # An implausible measurement is a failure to measure, not
            # evidence of an offence.
            if not _glyph_measurement_plausible(decl.glyph):
                out.append(
                    Finding(
                        rule_id=f"glyph_aspect_ratio.{field_id}",
                        citation=citation,
                        outcome=Outcome.INDETERMINATE,
                        severity=severity,
                        field_id=field_id,
                        measured_value=round(ratio, 4),
                        required_value=round(min_ratio, 4),
                        unit="width/height",
                        message=(
                            f"Text is only {decl.glyph.cap_height_px:.0f} px tall in "
                            f"this photo - too small to measure character shape "
                            f"reliably. Retake this panel closer."
                            if decl.glyph.cap_height_px < MIN_CAP_PX else
                            f"Character shape could not be measured reliably "
                            f"(ratio {ratio:.2f} from {n_glyphs} glyph(s)). "
                            f"Printed text does not fall below about "
                            f"{IMPLAUSIBLE_RATIO}, so this is a measurement "
                            f"failure rather than a finding. Retake this panel "
                            f"closer or in better focus."
                        ),
                        evidence_bbox=decl.bbox,
                        confidence=0.0,
                        rule_verified=verified,
                    )
                )
                continue

            ok = ratio >= min_ratio
            out.append(
                Finding(
                    rule_id=f"glyph_aspect_ratio.{field_id}",
                    citation=citation,
                    outcome=Outcome.COMPLIANT if ok else Outcome.VIOLATION,
                    severity=severity,
                    field_id=field_id,
                    measured_value=round(ratio, 4),
                    required_value=round(min_ratio, 4),
                    unit="width/height",
                    message=(
                        f"Character width/height ratio {ratio:.2f} meets the "
                        f"one-third minimum."
                        if ok
                        else f"Character width/height ratio {ratio:.2f} is below "
                             f"the required minimum of {min_ratio:.2f}."
                    ),
                    evidence_bbox=decl.bbox,
                    confidence=0.85,
                    rule_verified=verified,
                )
            )
        return out

    def _eval_clear_space(self, spec, check, scan, verified, citation, severity):
        field_id = check.get("target_field", "net_quantity")
        decl = scan.declaration(field_id)
        if not decl or not decl.bbox or not decl.glyph or decl.glyph.cap_height_px <= 0:
            return []

        if not _glyph_measurement_plausible(decl.glyph):
            return [
                Finding(
                    rule_id="quantity_clear_space",
                    citation=citation,
                    outcome=Outcome.INDETERMINATE,
                    severity=severity,
                    field_id=field_id,
                    message=(
                        "Clear space could not be assessed: it is measured in "
                        "multiples of the numeral height, and that height was "
                        "not measured reliably on this image"
                        + (f" (numerals only {decl.glyph.cap_height_px:.0f} px "
                           f"tall - retake closer)."
                           if decl.glyph.cap_height_px < MIN_CAP_PX else ".")
                    ),
                    evidence_bbox=decl.bbox,
                    confidence=0.0,
                    rule_verified=verified,
                )
            ]

        margins = check.get("margins", {})
        h = decl.glyph.cap_height_px
        required_px = {k: float(v) * h for k, v in margins.items()}

        # Distance to the nearest other text in each direction.
        actual_px = _nearest_neighbour_gaps(decl, scan)

        # Measurement tolerance. A gap is measured between ink edges that
        # blur and anti-alias over a pixel or two, and the numeral height
        # that the gap is divided by carries its own pixel of error. A
        # real Maggi sachet measured 0.97 numeral heights against a
        # required 1.0 - inside that error, so not a finding either way.
        tol_px = max(1.5, 0.08 * h)
        worst_side, worst_deficit = None, 0.0
        marginal = None
        for side, req in required_px.items():
            act = actual_px.get(side)
            if act is None:
                continue  # nothing on that side - clear by definition
            deficit = req - act
            if deficit <= 0:
                continue
            best_case = (act + tol_px) / max(1.0, h - 1.0)
            if best_case >= float(margins[side]):
                if marginal is None or deficit > marginal[1]:
                    marginal = (side, deficit)
                continue
            if deficit > worst_deficit:
                worst_deficit, worst_side = deficit, side

        if worst_side is None and marginal is not None:
            side = marginal[0]
            return [
                Finding(
                    rule_id="quantity_clear_space",
                    citation=citation,
                    outcome=Outcome.INDETERMINATE,
                    severity=severity,
                    field_id=field_id,
                    measured_value=round(actual_px[side] / h, 2),
                    required_value=float(margins[side]),
                    unit="numeral heights",
                    uncertainty=round(tol_px / h, 2),
                    message=(
                        f"Clear space to the {side} of the net quantity declaration "
                        f"measures {actual_px[side]/h:.2f} numeral heights against a "
                        f"required {margins[side]} - within measurement tolerance "
                        f"(±{tol_px / h:.2f}). Not asserted either way; check by eye."
                    ),
                    evidence_bbox=decl.bbox,
                    confidence=0.5,
                    rule_verified=verified,
                )
            ]

        if worst_side is None:
            return [
                Finding(
                    rule_id="quantity_clear_space",
                    citation=citation,
                    outcome=Outcome.COMPLIANT,
                    severity=severity,
                    field_id=field_id,
                    message="Required clear space around the quantity declaration is present.",
                    evidence_bbox=decl.bbox,
                    confidence=0.85,
                    rule_verified=verified,
                )
            ]

        return [
            Finding(
                rule_id="quantity_clear_space",
                citation=citation,
                outcome=Outcome.VIOLATION,
                severity=severity,
                field_id=field_id,
                measured_value=round(actual_px[worst_side] / h, 2),
                required_value=float(margins[worst_side]),
                unit="numeral heights",
                message=(
                    f"Insufficient clear space to the {worst_side} of the net "
                    f"quantity declaration: {actual_px[worst_side]/h:.2f} numeral "
                    f"heights against a required {margins[worst_side]}."
                ),
                evidence_bbox=decl.bbox,
                confidence=0.8,
                rule_verified=verified,
            )
        ]

    def _eval_min_height(self, spec, scan, verified, citation, severity):
        """
        Rule 7(2) / Table-I. The only check that needs real-world scale.

        Emits UNVERIFIED_RULE while the table values are placeholders,
        which is the state this scaffold ships in.
        """
        decl = scan.declaration("net_quantity")
        if not decl or not decl.glyph:
            return []

        if not verified:
            return [
                Finding(
                    rule_id="numeral_height",
                    citation=citation,
                    outcome=Outcome.UNVERIFIED_RULE,
                    severity=severity,
                    field_id="net_quantity",
                    measured_value=decl.glyph.cap_height_mm,
                    required_value=None,
                    unit="mm",
                    uncertainty=decl.glyph.cap_height_mm_uncertainty,
                    message=(
                        "Numeral height measured but not evaluated: Table-I "
                        "thresholds in rules/lmpc_2011.yaml are placeholders. "
                        "Transcribe the gazette values and set verified: true."
                    ),
                    evidence_bbox=decl.bbox,
                    confidence=0.0,
                    rule_verified=False,
                )
            ]

        if not scan.calibration.available or decl.glyph.cap_height_mm is None:
            return [
                Finding(
                    rule_id="numeral_height",
                    citation=citation,
                    outcome=Outcome.INDETERMINATE,
                    severity=severity,
                    field_id="net_quantity",
                    message=(
                        "Cannot measure numeral height: no scale reference in "
                        "frame. Retake with the calibration card visible."
                    ),
                    evidence_bbox=decl.bbox,
                    confidence=1.0,
                    rule_verified=verified,
                )
            ]

        # Rule 7(5) / medical-device proviso: the size rules may not
        # apply to this field at all. Checked BEFORE looking up a
        # threshold, because measuring against a threshold that does not
        # govern the package is how a compliant pack gets a violation.
        relaxed, never_exempt, relax_ex = self.resolver.size_rule_relaxation(
            scan.context, scan.declarations
        )
        if relaxed and "net_quantity" not in never_exempt:
            return [
                Finding(
                    rule_id="numeral_height",
                    citation="Rule 7(5)",
                    outcome=Outcome.NOT_APPLICABLE,
                    severity=severity,
                    field_id="net_quantity",
                    message=(
                        f"Size requirements relaxed: this information is also "
                        f"required under another law "
                        f"({relax_ex.get('label', relax_ex['id'])})."
                    ),
                    exemption_applied=relax_ex["id"],
                    rule_verified=verified,
                    confidence=1.0,
                )
            ]

        deferred = self.resolver.deferred_to_other_law(
            scan.context, scan.declarations
        )
        if deferred is not None:
            target = (deferred.get("effect") or {}).get("defer_to")
            return [
                Finding(
                    rule_id="numeral_height",
                    citation=deferred.get("citation", "Rule 7(2) proviso"),
                    outcome=Outcome.NOT_APPLICABLE,
                    severity=severity,
                    field_id="net_quantity",
                    message=(
                        f"Numeral and letter height for this package are "
                        f"governed by {target}, not by Table-I."
                    ),
                    exemption_applied=deferred["id"],
                    rule_verified=bool(deferred.get("verified", False)),
                    confidence=1.0,
                )
            ]

        required = self._lookup_required_height(spec, scan, decl)
        if required is None:
            return [
                Finding(
                    rule_id="numeral_height",
                    citation=citation,
                    outcome=Outcome.INDETERMINATE,
                    severity=severity,
                    field_id="net_quantity",
                    message="No applicable Table band matched this package.",
                    confidence=0.5,
                    rule_verified=verified,
                )
            ]

        measured = decl.glyph.cap_height_mm
        band = max(self.config.abstain_band_mm, decl.glyph.cap_height_mm_uncertainty)

        if measured + band < required:
            outcome, msg = Outcome.VIOLATION, (
                f"Numeral height {measured:.2f} mm is below the required "
                f"{required:.2f} mm (uncertainty +/-{band:.2f} mm)."
            )
        elif measured - band > required:
            outcome, msg = Outcome.COMPLIANT, (
                f"Numeral height {measured:.2f} mm meets the required "
                f"{required:.2f} mm."
            )
        else:
            outcome, msg = Outcome.INDETERMINATE, (
                f"Numeral height {measured:.2f} mm is within measurement "
                f"uncertainty (+/-{band:.2f} mm) of the {required:.2f} mm "
                f"threshold. Not asserting a violation."
            )

        return [
            Finding(
                rule_id="numeral_height",
                citation=citation,
                outcome=outcome,
                severity=severity,
                field_id="net_quantity",
                measured_value=round(measured, 3),
                required_value=required,
                unit="mm",
                uncertainty=round(band, 3),
                message=msg,
                evidence_bbox=decl.bbox,
                confidence=0.8,
                rule_verified=verified,
            )
        ]

    def _lookup_required_height(self, spec, scan, decl) -> Optional[float]:
        """
        Table-I lookup, keyed to PRINCIPAL DISPLAY PANEL AREA.

        This used to branch on the unit: Table-I by net quantity for
        weight/volume goods, Table-II by PDP area for length/area/number
        goods. That branch is gone. G.S.R. 629(E) (2017) substituted
        Table-I to key on PDP area for everything and omitted Table-II
        outright.

        The practical consequence is that there is no longer a shortcut
        path where the threshold can be read off the declared net
        quantity. Every font-size evaluation now needs a real-world
        panel area, so calibration plus a fully visible PDP is a hard
        prerequisite rather than an optimisation.
        """
        col = (
            "min_height_mm_embossed"
            if scan.context.is_embossed
            else "min_height_mm_printed"
        )

        area = scan.context.pdp_area_cm2
        if area is None:
            return None

        for b in spec.get("table_I", {}).get("bands", []) or []:
            cap = b.get("max_area_cm2")
            if cap is None or area <= float(cap):
                return b.get(col)
        return None

    def _eval_pdp_grouping(self, spec, scan, verified, citation, severity,
                           findings_so_far=()):
        pdp = scan.context.pdp_bbox
        if pdp is None:
            return []
        required = [
            d["id"]
            for d in self.config.declarations
            if d.get("severity") in ("critical", "major")
        ]
        found = {d.field_id for d in scan.declarations if d.present}

        # Only fields that actually APPLY to this package. A domestic
        # pack has no country-of-origin declaration to group, and an
        # exempt field is not missing - it is not required. Without this
        # the grouping check demanded declarations the Rules never asked
        # for and could never return COMPLIANT on an ordinary package.
        not_applicable = {
            f.field_id for f in findings_so_far
            if f.outcome in (Outcome.NOT_APPLICABLE, Outcome.SUPPRESSED)
            and f.field_id
        }
        missing = [
            f for f in required
            if f not in found and f not in not_applicable
        ]
        if missing:
            # Grouping only inspected fields that were FOUND, so it
            # reported "all declarations grouped on the panel" on the
            # same report that said those declarations were missing -
            # two findings flatly contradicting each other. You cannot
            # judge the arrangement of declarations you never located.
            return [
                Finding(
                    rule_id="pdp_grouping",
                    citation=citation,
                    outcome=Outcome.INDETERMINATE,
                    severity=severity,
                    message=(
                        "Cannot assess grouping: "
                        + ", ".join(missing)
                        + " not located in this image."
                    ),
                    evidence_bbox=pdp,
                    confidence=0.9,
                    rule_verified=verified,
                )
            ]

        outside = [
            d.field_id
            for d in scan.declarations
            if d.present and d.bbox and d.field_id in required and not pdp.contains(d.bbox, tol=4.0)
        ]
        ok = not outside
        return [
            Finding(
                rule_id="pdp_grouping",
                citation=citation,
                outcome=Outcome.COMPLIANT if ok else Outcome.VIOLATION,
                severity=severity,
                message=(
                    "All mandatory declarations are grouped on the principal display panel."
                    if ok
                    else "Declarations found outside the principal display panel: "
                         + ", ".join(outside)
                ),
                evidence_bbox=pdp,
                confidence=0.75,
                rule_verified=verified,
            )
        ]


# =====================================================================
# Helpers
# =====================================================================

_UNIT_ALIASES = {
    "gm": "g", "gms": "g", "gram": "g", "grams": "g", "g": "g",
    "kg": "kg", "kgs": "kg", "kilogram": "kg",
    "ml": "ml", "mls": "ml", "millilitre": "ml", "milliliter": "ml",
    "l": "l", "ltr": "l", "litre": "l", "liter": "l",
    "n": "N", "u": "U",
}



_MASS_UNITS = {"g", "kg"}
_VOLUME_UNITS = {"ml", "l"}


def _same_dimension(unit: str, limit_units: list[str]) -> bool:
    """
    Does `unit` measure the same physical dimension as the threshold?

    The previous check asked whether the unit STRING appeared in the
    threshold's unit list, so "26000 g" failed a ">25 kg" test purely
    because the label said grams - the exemption compared labels rather
    than quantities. A 26 kg sack was in scope or out of it depending on
    which unit the packer chose to print.
    """
    u = _base_unit(unit)
    limits = {_base_unit(x) for x in limit_units}
    if u in limits:
        return True
    if u in _MASS_UNITS and limits & _MASS_UNITS:
        return True
    if u in _VOLUME_UNITS and limits & _VOLUME_UNITS:
        return True
    return False

# Printed text does not get narrower than roughly 0.15 width/height -
# aggressively condensed type measured 0.25 in controlled tests, and the
# rule's own threshold is 0.33. A real photograph produced 0.08, i.e.
# characters twelve times taller than wide, which is a merged stroke or
# a box spanning two lines, not text.
IMPLAUSIBLE_RATIO = 0.15
MIN_GLYPHS = 3
MIN_CAP_PX = 16.0


def _glyph_measurement_plausible(glyph) -> bool:
    """
    Did we actually measure glyphs, or produce a number from noise?

    Used by BOTH Rule 7(3) and Rule 8, because clear space is expressed
    in multiples of the numeral height - so the same bad cap height that
    yields an impossible width ratio also corrupts the clear-space
    denominator. Judging them independently let one rule abstain on a
    failed measurement while the other asserted a violation from it.
    """
    if glyph is None or not glyph.cap_height_px:
        return False
    if glyph.n_glyphs_measured < MIN_GLYPHS:
        return False
    # Below ~16 px a character is a handful of pixels: one pixel is 6%+
    # of its height, and neighbouring glyphs merge when binarised. On
    # real 720x1280 phone photos of a bottle the net quantity is ~11 px
    # tall and clear space measured 0.57 numeral heights where the print
    # shows about 1.1. Ask for a closer photo instead of a finding.
    if glyph.cap_height_px < MIN_CAP_PX:
        return False
    ratio = glyph.width_over_height
    if ratio is not None and ratio < IMPLAUSIBLE_RATIO:
        return False
    return True


def _base_unit(unit: str) -> str:
    return _UNIT_ALIASES.get((unit or "").strip().lower(), (unit or "").strip())


def _normalise_quantity(value: Any, unit: str) -> Optional[float]:
    """Convert to grams or millilitres so table bands can be compared."""
    if value is None:
        return None
    try:
        v = float(value)
    except (TypeError, ValueError):
        return None
    u = _base_unit(unit)
    if u == "kg":
        return v * 1000.0
    if u == "l":
        return v * 1000.0
    if u in ("g", "ml"):
        return v
    return None


def _find_banned_phrase(text: str, phrases: list[str]) -> Optional[str]:
    low = (text or "").lower()
    for p in phrases:
        if re.search(rf"\b{re.escape(p.lower())}\b", low):
            return p
    return None


def _union(boxes: list[BBox]) -> BBox:
    x0 = min(b.x for b in boxes); y0 = min(b.y for b in boxes)
    x1 = max(b.x2 for b in boxes); y1 = max(b.y2 for b in boxes)
    return BBox(x0, y0, x1 - x0, y1 - y0)


def _nearest_neighbour_gaps(decl: Declaration, scan: ScanResult) -> dict[str, float]:
    """
    Distance in px from the declaration box to the nearest other printed
    text on each side. Returns only sides where something was found.
    """
    gaps: dict[str, float] = {}
    if decl.bbox is None:
        return gaps
    # Measure between INK, not between OCR boxes: PaddleOCR pads every
    # box outward, and two padded boxes swallow a large part of the very
    # gap Rule 8 is about (see vision/ink.py).
    own_ink = [s.ink_bbox or s.bbox for s in decl.spans]
    box = _union(own_ink) if own_ink else decl.bbox

    others: list[BBox] = []

    # Prefer the full OCR span set. Rule 8 is about "other printed
    # matter", which is mostly text that never became a declaration -
    # marketing copy, ingredients, a barcode caption. Searching only
    # declarations makes a crowded label look compliant.
    if scan.spans:
        # Use the already-null-checked local, not a fresh read of
        # decl.bbox. Re-reading defeats the guard four lines above and
        # leaves an AttributeError one refactor away.
        own = decl.bbox
        for sp in scan.spans:
            # Skip the spans that make up the declaration itself.
            if any(sp is s for s in decl.spans):
                continue
            if own.iou(sp.bbox) > 0.5 or own.contains(sp.bbox, tol=2.0):
                continue
            others.append(sp.ink_bbox or sp.bbox)
    else:
        for d in scan.declarations:
            if d.field_id == decl.field_id or not d.bbox:
                continue
            others.append(d.bbox)
            for s in d.spans:
                others.append(s.bbox)

    for other in others:
        v_overlap = min(box.y2, other.y2) - max(box.y, other.y)
        h_overlap = min(box.x2, other.x2) - max(box.x, other.x)

        if v_overlap > 0 and h_overlap > 0:
            # The other print actually touches or overlaps the
            # declaration. These pairs used to fall through both branches
            # below and be ignored - so the MOST crowded case of all
            # measured as "no neighbour, compliant". Zero gap, on the side
            # its centre lies.
            dx = (other.cx - box.cx) / max(box.w, 1.0)
            dy = (other.cy - box.cy) / max(box.h, 1.0)
            if abs(dy) >= abs(dx):
                side = "bottom" if dy > 0 else "top"
            else:
                side = "right" if dx > 0 else "left"
            gaps[side] = 0.0
            continue

        if v_overlap > 0:  # same horizontal band -> left/right neighbour
            if other.x2 <= box.x:
                gaps["left"] = min(gaps.get("left", 1e9), box.x - other.x2)
            elif other.x >= box.x2:
                gaps["right"] = min(gaps.get("right", 1e9), other.x - box.x2)
        if h_overlap > 0:  # same vertical band -> top/bottom neighbour
            if other.y2 <= box.y:
                gaps["top"] = min(gaps.get("top", 1e9), box.y - other.y2)
            elif other.y >= box.y2:
                gaps["bottom"] = min(gaps.get("bottom", 1e9), other.y - box.y2)

    return {k: v for k, v in gaps.items() if v < 1e9}


def exempt_set(scan: ScanResult, config: RuleConfig) -> set[str]:
    return set(ExemptionResolver(config).resolve(scan.context, scan.declarations).keys())
