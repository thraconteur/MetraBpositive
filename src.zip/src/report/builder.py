"""
Compliance report generation.

The PS asks for reports in "PDF and editable formats" with photographs
and supporting evidence attached. This module produces both, plus an
evidence crop per finding.

WHAT MAKES A REPORT USABLE RATHER THAN IMPRESSIVE
-------------------------------------------------
An inspector may have to defend this document. So every finding carries:

    rule citation | measured vs required | evidence crop | confidence
    | the measurement method used | space for a human decision

And the report NEVER states a bare verdict when the system abstained.
"Indeterminate - retake required" is a real outcome and it is printed as
prominently as a violation. A tool that always produces a verdict is a
tool that sometimes produces a confident wrong one, and the first time
that happens in front of an officer, the tool is finished.

The human-decision column is not decoration either. The system proposes;
a person disposes. That is both better law and a much better answer when
a judge asks who is accountable for a wrong flag.
"""

from __future__ import annotations

import base64
import html
from pathlib import Path
from typing import Optional

import cv2

from ..core.schema import Outcome, ScanResult, Severity

OUTCOME_STYLE = {
    Outcome.VIOLATION:       ("#96271F", "#FBF4F3", "VIOLATION"),
    Outcome.COMPLIANT:       ("#2C6349", "#F2F7F4", "COMPLIANT"),
    Outcome.INDETERMINATE:   ("#8A6D1F", "#FCF8EC", "INDETERMINATE"),
    Outcome.UNVERIFIED_RULE: ("#5B5B6B", "#F4F4F7", "RULE NOT VERIFIED"),
    Outcome.NOT_APPLICABLE:  ("#69757E", "#F4F6F6", "NOT APPLICABLE"),
    Outcome.SUPPRESSED:      ("#69757E", "#F4F6F6", "SUPPRESSED"),
}


# ---------------------------------------------------------------------
# Evidence crops
# ---------------------------------------------------------------------

def extract_evidence_crops(
    scan: ScanResult,
    out_dir: str | Path,
    pad: int = 14,
    annotate: bool = True,
) -> dict[str, str]:
    """
    Save one annotated crop per finding that has a bounding box.

    Annotated with the measurement overlay where a measurement was made,
    so the crop shows not just WHERE the finding is but WHAT was measured
    to produce it.
    """
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    paths: dict[str, str] = {}

    image = getattr(scan, "analysed_image", None)
    if image is None:
        if not scan.image_path or not Path(scan.image_path).exists():
            return paths
        image = cv2.imread(scan.image_path)
    if image is None:
        return paths

    h, w = image.shape[:2]
    for i, finding in enumerate(scan.findings):
        if finding.evidence_bbox is None:
            continue
        b = finding.evidence_bbox
        x0, y0 = max(0, int(b.x) - pad), max(0, int(b.y) - pad)
        x1, y1 = min(w, int(b.x2) + pad), min(h, int(b.y2) + pad)
        if x1 <= x0 or y1 <= y0:
            continue

        crop = image[y0:y1, x0:x1].copy()
        if annotate:
            colour = (60, 60, 220) if finding.outcome is Outcome.VIOLATION else (70, 150, 70)
            cv2.rectangle(crop, (pad, pad), (crop.shape[1] - pad, crop.shape[0] - pad),
                          colour, 2)

        path = out_dir / f"{scan.scan_id}_{i:02d}_{finding.rule_id.replace('.', '_')}.png"
        cv2.imwrite(str(path), crop)
        finding.evidence_crop_path = str(path)
        paths[finding.rule_id] = str(path)

    return paths


def _img_b64(path: Optional[str]) -> Optional[str]:
    if not path or not Path(path).exists():
        return None
    with open(path, "rb") as fh:
        return base64.b64encode(fh.read()).decode()


# ---------------------------------------------------------------------
# HTML report
# ---------------------------------------------------------------------

def build_html_report(
    scan: ScanResult,
    rule_audit: Optional[dict] = None,
    embed_images: bool = True,
) -> str:
    verdict, vcolour, vnote = _verdict(scan)

    rows = []
    order = [Outcome.VIOLATION, Outcome.INDETERMINATE, Outcome.UNVERIFIED_RULE,
             Outcome.COMPLIANT, Outcome.NOT_APPLICABLE, Outcome.SUPPRESSED]
    findings = sorted(scan.findings, key=lambda f: order.index(f.outcome))

    for f in findings:
        colour, bg, label = OUTCOME_STYLE[f.outcome]

        measured = "—"
        if f.measured_value is not None:
            measured = f"{f.measured_value:g}"
            if f.unit:
                measured += f" {f.unit}"
            if f.uncertainty:
                measured += f" ±{f.uncertainty:g}"
        required = "—"
        if f.required_value is not None:
            required = f"{f.required_value:g}" + (f" {f.unit}" if f.unit else "")

        crop_html = ""
        b64 = _img_b64(f.evidence_crop_path) if embed_images else None
        if b64:
            crop_html = f'<img class="crop" src="data:image/png;base64,{b64}" alt="evidence">'

        rows.append(f"""
        <tr>
          <td><span class="badge" style="color:{colour};background:{bg};border-color:{colour}">{label}</span></td>
          <td class="mono">{html.escape(f.citation or '—')}{
            f'<br><span class="muted">{html.escape(f.field_id)}</span>'
            if f.field_id else ''
          }</td>
          <td>{html.escape(f.message)}</td>
          <td class="num">{html.escape(measured)}</td>
          <td class="num">{html.escape(required)}</td>
          <td class="num">{f.confidence:.2f}</td>
          <td>{crop_html}</td>
          <td class="decision"></td>
        </tr>""")

    audit_html = ""
    if rule_audit:
        unverified = rule_audit.get("unverified", [])
        cov = rule_audit.get("coverage", 0) * 100
        if unverified:
            audit_html = f"""
      <div class="audit">
        <b>Rule verification status: {cov:.0f}% of rules verified against the gazette text.</b>
        The following rules are still placeholders and CANNOT produce a violation:
        <span class="mono">{html.escape(', '.join(unverified))}</span>.
        Findings against them are reported as "RULE NOT VERIFIED" and must not be
        treated as compliance decisions.
      </div>"""

    full_b64 = _img_b64(scan.image_path) if embed_images else None
    photo_html = (
        f'<img class="full" src="data:image/png;base64,{full_b64}" alt="scanned package">'
        if full_b64 else "<p class='muted'>Source image not embedded.</p>"
    )

    # -- what OCR / extraction produced --------------------------------
    engines = sorted({sp.source_engine for sp in scan.spans}) if scan.spans else []
    st = scan.ocr_stats or {}
    ocr_line = ", ".join(engines) if engines else "no text read"
    if scan.spans:
        ocr_line += f" · {len(scan.spans)} lines"
    if st.get("cache_hit"):
        ocr_line += " · cached result"
    elif st.get("total_s") is not None:
        ocr_line += f" · {st['total_s']}s"
    if st.get("refined"):
        ocr_line += f" · {st['refined']} weak line(s) re-read"
    if st.get("secondary_replaced"):
        ocr_line += f" · {st['secondary_replaced']} Devanagari line(s)"
    if st.get("vertical_bands"):
        ocr_line += f" · {st['vertical_bands']} rotated band(s) re-read"
    v = st.get("vlm") or {}
    if v:
        ocr_line += (f" · second reader {v.get('model')}: found "
                     f"{len(v.get('found') or [])} of {len(v.get('asked') or [])} missing "
                     f"({len(v.get('confirmed_by_ocr') or [])} confirmed by OCR)")
        if v.get("error"):
            ocr_line += f" - FAILED: {v['error'][:80]}"

    decl_rows = []
    for d in scan.declarations:
        if not d.present:
            continue
        val = "—" if d.value is None else str(d.value)
        if d.unit:
            val += f" {d.unit}"
        notes = "<br>".join(html.escape(n) for n in (d.notes or []))
        src = getattr(d, "source", "ocr")
        src_tag = ("" if src == "ocr" else
                   f"<br><span class='badge' style='color:#8A6D1F;border-color:#8A6D1F'>"
                   f"{'VISION MODEL + OCR' if src == 'vlm+ocr' else 'VISION MODEL ONLY'}</span>")
        decl_rows.append(
            f"<tr><td class='mono'>{html.escape(d.field_id)}{src_tag}</td>"
            f"<td>{html.escape((d.raw_text or '')[:220])}</td>"
            f"<td class='mono'>{html.escape(val[:80])}</td>"
            f"<td class='num'>{d.extraction_confidence:.2f}</td>"
            f"<td class='muted'>{notes}</td></tr>"
        )
    decl_rows = "".join(decl_rows)

    ocr_html = ""
    if scan.spans:
        lines = sorted(scan.spans, key=lambda sp: (round(sp.bbox.y / 12), sp.bbox.x))
        vert_tag = ' <span class="muted">(vertical)</span>'
        items = "".join(
            f"<tr><td class='num'>{sp.confidence:.2f}</td>"
            f"<td>{html.escape(sp.text)}{vert_tag if sp.vertical else ''}</td>"
            f"<td class='mono muted'>{html.escape(sp.source_engine)}</td></tr>"
            for sp in lines
        )
        ocr_html = f"""
<details>
  <summary><b>Raw OCR lines ({len(lines)})</b> <span class="muted">- exactly what the
  engine read. If a finding looks wrong, check here first: a misread line is an OCR
  problem, a correct line with a wrong finding is an extraction or rules problem.</span></summary>
  <table><thead><tr><th>Conf.</th><th>Text</th><th>Engine</th></tr></thead>
  <tbody>{items}</tbody></table>
</details>"""

    cal = scan.calibration
    cal_line = (
        f"{cal.method.value} · {cal.px_per_mm:.3f} px/mm"
        if cal.available else f"not calibrated ({html.escape(cal.notes or 'no marker')})"
    )

    return f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<title>Compliance Report {scan.scan_id}</title>
<style>
  @page {{ size: A4; margin: 14mm; }}
  body {{ font-family: -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
         color:#2A343C; font-size:12px; line-height:1.5; margin:0; }}
  h1 {{ font-size:19px; color:#101820; margin:0 0 2px; }}
  h2 {{ font-size:13px; color:#101820; margin:18px 0 6px;
        border-bottom:1.5px solid #2B3A67; padding-bottom:3px; }}
  .muted {{ color:#69757E; font-size:11px; }}
  .head {{ background:#E7E9F2; border-left:5px solid #2B3A67; padding:10px 14px; }}
  .verdict {{ display:inline-block; padding:6px 14px; border-radius:2px;
              font-weight:700; font-size:14px; color:#fff; }}
  table {{ width:100%; border-collapse:collapse; margin-top:6px; }}
  th {{ text-align:left; font-size:10px; text-transform:uppercase; letter-spacing:.04em;
        color:#69757E; border-bottom:1.5px solid #101820; padding:5px 6px; }}
  td {{ border-bottom:1px solid #E3E7E6; padding:6px; vertical-align:top; }}
  td.num {{ text-align:right; white-space:nowrap; font-variant-numeric:tabular-nums; }}
  td.decision {{ width:70px; border-left:1px dashed #C9CFCE; }}
  .badge {{ display:inline-block; padding:2px 6px; border:1px solid; border-radius:2px;
            font-size:9.5px; font-weight:700; white-space:nowrap; }}
  .mono {{ font-family: ui-monospace, Menlo, Consolas, monospace; font-size:10.5px; }}
  .crop {{ max-width:150px; max-height:56px; border:1px solid #D3D9D7; }}
  .full {{ max-width:250px; border:1px solid #D3D9D7; }}
  .grid {{ display:flex; gap:18px; }}
  .audit {{ background:#F4F4F7; border-left:4px solid #5B5B6B; padding:8px 12px;
            margin:12px 0; font-size:11px; }}
  .kv {{ font-size:11px; }} .kv b {{ color:#101820; }}
  .sign {{ margin-top:22px; border-top:1px solid #C9CFCE; padding-top:8px; font-size:11px; }}
</style></head><body>

<div class="head">
  <h1>Legal Metrology Compliance Report</h1>
  <div class="muted">Legal Metrology (Packaged Commodities) Rules, 2011 ·
    Scan {scan.scan_id} · {scan.created_at[:19].replace('T', ' ')} UTC ·
    Inspector: {html.escape(scan.inspector_id or 'unassigned')}</div>
</div>

<p><span class="verdict" style="background:{vcolour}">{verdict}</span>
   <span class="muted">{html.escape(vnote)}</span></p>

<div class="grid">
  <div style="flex:1">
    <h2>Package</h2>
    <div class="kv">
      <b>Category:</b> {html.escape(scan.context.commodity_category)}<br>
      <b>Class:</b> {html.escape(scan.context.package_class)}<br>
      <b>Geometry:</b> {html.escape(scan.context.geometry.value)}<br>
      <b>PDP area:</b> {f'{scan.context.pdp_area_cm2:.1f} cm²' if scan.context.pdp_area_cm2 else '—'}<br>
      <b>Calibration:</b> {html.escape(cal_line)}<br>
      <b>Image quality:</b> {'acceptable' if scan.image_quality_ok else html.escape(scan.quality_notes)}<br>
      <b>OCR:</b> {html.escape(ocr_line)}
    </div>
  </div>
  <div>{photo_html}</div>
</div>

{audit_html}

<h2>Findings</h2>
<table>
  <thead><tr>
    <th>Outcome</th><th>Rule</th><th>Finding</th><th>Measured</th>
    <th>Required</th><th>Conf.</th><th>Evidence</th><th>Officer</th>
  </tr></thead>
  <tbody>{''.join(rows)}</tbody>
</table>

<h2>What was read</h2>
<table>
  <thead><tr><th>Field</th><th>Read as</th><th>Value</th><th>Conf.</th><th>Notes</th></tr></thead>
  <tbody>{decl_rows or '<tr><td colspan="5" class="muted">No declarations extracted.</td></tr>'}</tbody>
</table>

{ocr_html}

<div class="sign">
  <b>Inspecting officer:</b> ________________________ &nbsp;&nbsp;
  <b>Signature:</b> ________________ &nbsp;&nbsp; <b>Date:</b> ____________<br>
  <span class="muted">This report is machine-generated decision support. Every finding
  requires confirmation by an authorised officer before any enforcement action.
  Measured values carry the stated uncertainty; findings marked INDETERMINATE were
  within measurement tolerance of the threshold and no violation is asserted.</span>
</div>

</body></html>"""


def _verdict(scan: ScanResult) -> tuple[str, str, str]:
    if not scan.image_quality_ok:
        return "RETAKE REQUIRED", "#8A6D1F", scan.quality_notes
    state = scan.is_compliant
    if state is False:
        n = len(scan.violations)
        crit = sum(1 for f in scan.violations if f.severity is Severity.CRITICAL)
        return ("NON-COMPLIANT", "#96271F",
                f"{n} violation(s), {crit} critical.")
    if state is True:
        return "COMPLIANT", "#2C6349", "All applicable checks passed."
    return ("INDETERMINATE", "#8A6D1F",
            f"{len(scan.indeterminate)} check(s) inconclusive, "
            f"{len(scan.unverified)} rule(s) unverified. No verdict asserted.")


# ---------------------------------------------------------------------
# Outputs
# ---------------------------------------------------------------------

def save_html(scan: ScanResult, out_path: str | Path, rule_audit=None) -> str:
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(build_html_report(scan, rule_audit), encoding="utf-8")
    return str(out)


def save_pdf(scan: ScanResult, out_path: str | Path, rule_audit=None) -> Optional[str]:
    """
    PDF via WeasyPrint when available.

    Deliberately NOT a screenshot-to-PDF hack: the PS asks for a report
    an officer can file, which means selectable text, working page breaks
    and a document that survives printing.
    """
    try:
        from weasyprint import HTML  # type: ignore
    except ImportError:
        return None
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    HTML(string=build_html_report(scan, rule_audit)).write_pdf(str(out))
    return str(out)


def save_docx(scan: ScanResult, out_path: str | Path) -> Optional[str]:
    """
    Editable format, per the PS requirement. Officers routinely need to
    add context before filing, so this deliberately carries the findings
    as editable text rather than as a flattened image.
    """
    try:
        from docx import Document  # type: ignore
        from docx.shared import Pt
    except ImportError:
        return None

    doc = Document()
    doc.add_heading("Legal Metrology Compliance Report", level=1)
    doc.add_paragraph(
        f"Scan {scan.scan_id} · {scan.created_at[:19].replace('T', ' ')} UTC · "
        f"Inspector: {scan.inspector_id or 'unassigned'}"
    )
    verdict, _, note = _verdict(scan)
    p = doc.add_paragraph()
    p.add_run(f"Verdict: {verdict}. ").bold = True
    p.add_run(note)

    doc.add_heading("Findings", level=2)
    table = doc.add_table(rows=1, cols=6)
    table.style = "Light Grid Accent 1"
    for i, h in enumerate(["Outcome", "Rule", "Finding", "Measured", "Required", "Conf."]):
        cell = table.rows[0].cells[i]
        cell.text = h
        for r in cell.paragraphs[0].runs:
            r.bold = True
            r.font.size = Pt(9)

    for f in scan.findings:
        if f.outcome is Outcome.NOT_APPLICABLE:
            continue
        cells = table.add_row().cells
        cells[0].text = OUTCOME_STYLE[f.outcome][2]
        # Include the field. Rule 7(3) is evaluated per declaration, so a
        # report could show two Rule 7(3) rows with opposite verdicts and
        # no way to tell which field each referred to - unusable for an
        # officer who has to act on it.
        cells[1].text = (
            f"{f.citation or '—'}\n{f.field_id}" if f.field_id
            else (f.citation or "—")
        )
        cells[2].text = f.message
        cells[3].text = (
            f"{f.measured_value:g} {f.unit}".strip() if f.measured_value is not None else "—"
        )
        cells[4].text = (
            f"{f.required_value:g} {f.unit}".strip() if f.required_value is not None else "—"
        )
        cells[5].text = f"{f.confidence:.2f}"

    doc.add_paragraph()
    doc.add_paragraph(
        "Machine-generated decision support. Every finding requires confirmation "
        "by an authorised officer before enforcement action."
    ).italic = True

    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(out))
    return str(out)


# =====================================================================
# Rehydration + unified entry point
# =====================================================================

def scan_from_dict(payload: dict) -> ScanResult:
    """
    Rebuild a ScanResult from its stored JSON.

    Reports are generated from the database long after the scan ran, so
    the builder must work from persisted JSON, not only from a live
    object. Keeping this in one place means the report always reflects
    exactly what was stored - no second, subtly different code path that
    formats a live scan differently from a recalled one.
    """
    from ..core.schema import (
        BBox,
        Calibration,
        CalibrationMethod,
        Declaration,
        Finding,
        GlyphMetrics,
        Outcome,
        PackageContext,
        PackageGeometry,
        Severity,
        TextSpan,
    )

    def box(d):
        return BBox(**d) if d else None

    scan = ScanResult(
        scan_id=payload.get("scan_id", ""),
        created_at=payload.get("created_at", ""),
        image_path=payload.get("image_path"),
        inspector_id=payload.get("inspector_id"),
        image_quality_ok=payload.get("image_quality_ok", True),
        quality_notes=payload.get("quality_notes", ""),
        pipeline_version=payload.get("pipeline_version", ""),
    )
    scan.ocr_stats = dict(payload.get("ocr_stats") or {})
    for sp in payload.get("spans") or []:
        try:
            scan.spans.append(TextSpan(
                text=sp.get("text", ""),
                bbox=BBox(**sp["bbox"]),
                confidence=sp.get("confidence", 1.0),
                source_engine=sp.get("source_engine", "unknown"),
                language=sp.get("language", "en"),
                vertical=sp.get("vertical", False),
                ink_bbox=box(sp.get("ink_bbox")),
            ))
        except (KeyError, TypeError):
            continue

    c = payload.get("calibration") or {}
    scan.calibration = Calibration(
        px_per_mm=c.get("px_per_mm"),
        method=CalibrationMethod(c.get("method", "none")),
        uncertainty_px_per_mm=c.get("uncertainty_px_per_mm", 0.0),
        marker_id=c.get("marker_id"),
        marker_size_mm=c.get("marker_size_mm"),
        notes=c.get("notes", ""),
    )

    # Rebuild PackageContext GENERICALLY from its dataclass fields
    # rather than by naming each one. The hand-written version listed
    # fields explicitly and silently dropped every field added after it
    # was written - barcode, printed_price, pdp_detection_method,
    # pdp_confidence and the detection-failure flags all vanished on the
    # way out of the database. That quietly defeated the GTIN work
    # entirely: the dual-MRP endpoint reads scans back through this
    # function, found no barcode, and downgraded every finding from
    # definitive (0.90) to inferred (0.55).
    import dataclasses

    ctx = payload.get("context") or {}
    ctx_kwargs = {}
    for f in dataclasses.fields(PackageContext):
        if f.name not in ctx:
            continue
        val = ctx[f.name]
        if f.name == "geometry":
            val = PackageGeometry(val)
        elif f.name == "pdp_bbox":
            val = box(val)
        ctx_kwargs[f.name] = val
    scan.context = PackageContext(**ctx_kwargs)

    for d in payload.get("declarations", []):
        g = d.get("glyph")
        scan.declarations.append(Declaration(
            field_id=d["field_id"],
            raw_text=d.get("raw_text", ""),
            value=d.get("value"),
            unit=d.get("unit"),
            bbox=box(d.get("bbox")),
            glyph=GlyphMetrics(**g) if g else None,
            extraction_confidence=d.get("extraction_confidence", 0.0),
            present=d.get("present", False),
            notes=list(d.get("notes") or []),
            source=d.get("source", "ocr"),
        ))

    for f in payload.get("findings", []):
        scan.findings.append(Finding(
            rule_id=f["rule_id"],
            citation=f.get("citation", ""),
            outcome=Outcome(f["outcome"]),
            severity=Severity(f.get("severity", "minor")),
            message=f.get("message", ""),
            field_id=f.get("field_id"),
            measured_value=f.get("measured_value"),
            required_value=f.get("required_value"),
            unit=f.get("unit", ""),
            uncertainty=f.get("uncertainty", 0.0),
            evidence_bbox=box(f.get("evidence_bbox")),
            evidence_crop_path=f.get("evidence_crop_path"),
            confidence=f.get("confidence", 0.0),
            rule_verified=f.get("rule_verified", True),
            exemption_applied=f.get("exemption_applied"),
            human_override=f.get("human_override"),
            human_note=f.get("human_note", ""),
        ))

    return scan


def build_report(payload, out_path, fmt: str = "pdf", rule_audit=None):
    """
    Single entry point used by the API. Accepts a live ScanResult or the
    stored JSON dict, and falls back from PDF to HTML when WeasyPrint is
    not installed - a missing optional dependency should degrade the
    format, never fail the request.
    """
    scan = payload if isinstance(payload, ScanResult) else scan_from_dict(payload)
    out_path = Path(out_path)

    if fmt == "html":
        return save_html(scan, out_path, rule_audit)

    pdf = save_pdf(scan, out_path, rule_audit)
    if pdf:
        return pdf
    return save_html(scan, out_path.with_suffix(".html"), rule_audit)
