"""
Field extraction: OCR text -> bound legal declarations.

THE POINT EVERY SHALLOW SUBMISSION MISSES
-----------------------------------------
Finding the string "Rs 120" on a package proves nothing. The legal
question is whether the package bears a RETAIL SALE PRICE DECLARATION,
which means a price, correctly worded as inclusive of all taxes, on the
principal display panel. Those are different questions and only the
second one is what Rule 6(1)(e) asks.

So extraction is a key-value binding problem, not a keyword search. Each
extractor here answers "which declaration is this text, and what is its
parsed value", and hands the rules engine a typed Declaration object.

TWO IMPLEMENTATIONS
-------------------
`RegexExtractor`   - deterministic, fast, no dependencies, fully
                     debuggable. Handles the majority of real labels
                     because Indian packaging is highly formulaic.
`SchemaVLMExtractor` - constrained JSON extraction for the messy tail.

Start with regex. Add the VLM for what regex misses, and MEASURE the
difference so you can say what it bought you. A hybrid that you can
explain beats a black box that you cannot.
"""

from __future__ import annotations

import json
import re
from collections.abc import Callable
from dataclasses import dataclass
from typing import Optional

from ..core.schema import BBox, Declaration, TextSpan

# =====================================================================
# Text normalisation
# =====================================================================

# OCR routinely confuses these on packaging print. Applied only inside
# numeric contexts - never to whole strings, or "Sol" becomes "S01".
_DIGIT_CONFUSIONS = {"O": "0", "o": "0", "l": "1", "I": "1", "S": "5", "B": "8"}


def normalise_unit(raw: str) -> str:
    """
    Map an OCR-confused unit token back to its intended unit.

    Applied only in unit position, never to free text - "1" means one
    everywhere else, and only here does it stand a real chance of being
    a mangled litre.
    """
    u = (raw or "").strip()
    hu = re.sub(r"\s+", "", u).rstrip(".")
    if hu in HINDI_UNITS:
        return HINDI_UNITS[hu]
    if u in OCR_UNIT_CONFUSIONS:
        return OCR_UNIT_CONFUSIONS[u]
    low = u.lower()
    if low in OCR_UNIT_CONFUSIONS:
        return OCR_UNIT_CONFUSIONS[low]
    return u


def normalise_numeric(text: str) -> str:
    return "".join(_DIGIT_CONFUSIONS.get(c, c) for c in text)


# Bilingual packs print Devanagari numerals (५०० ग्राम). Normalising them
# here means every numeric pattern below works on either script.
_DEV_DIGITS = str.maketrans("०१२३४५६७८९", "0123456789")


# CJK glyphs never occur on Indian packaging, but PP-OCRv6's recogniser
# is bilingual Chinese/English and reads smudges, bar-code fragments and
# rotated inkjet dots as 印, 心, 出 ... (every one of these came back on
# real photos). They are noise, never text.
_CJK = re.compile(r"[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uac00-\ud7af\uf900-\ufaff]")
# "(Rs.0.4 0/ml)": OCR splits a decimal with a space. Only re-joined
# directly before a unit-price marker, where the reading is unambiguous.
_SPLIT_DECIMAL = re.compile(r"(\d\.\d) (\d)(?=\s*(?:/|per\b|\)))", re.I)


def clean(text: str) -> str:
    t = _CJK.sub("", (text or "").translate(_DEV_DIGITS))
    t = re.sub(r"\s+", " ", t.strip())
    return _SPLIT_DECIMAL.sub(r"\1\2", t)


# =====================================================================
# Patterns
# =====================================================================

CURRENCY = r"(?:₹|Rs\.?|INR|R s\.?|रु\.?|रू\.?)"
# The comma-grouped branch uses + not *, and plain digits come second.
# With * the first branch matched "149" out of "1495.00" - three digits,
# zero comma groups, and the optional decimal could not attach because
# the next character was "5". Regex alternation then returned that
# partial match rather than trying the long-number branch. Every MRP
# above Rs.999 written without a comma was silently read as its first
# three digits: Rs.1495.00 became Rs.149.00. On a real Casio watch box
# that is a tenfold error in the single most important declaration.
NUMBER = r"\d{1,3}(?:,\d{2,3})+(?:\.\d{1,2})?|\d+(?:\.\d{1,2})?"

# OCR confuses a handful of glyphs that matter enormously here, because
# the unit carries the legal meaning: "1 l" of cooking oil read as "1 |"
# extracts no quantity at all, and the package is then reported as
# missing its net quantity declaration - a false violation from a single
# misread character.
#
# The pipe/one/ell family is the worst: |, I, 1 and l are near-identical
# in many packaging faces, and litre is a single lowercase l.
OCR_UNIT_CONFUSIONS = {
    "|": "l", "I": "l", "1": "l", "!": "l",      # litre
    "9": "g", "q": "g", "6": "g", "&": "g",       # gram - "500 g" is
                                                  # very often read "500 6"
    "mI": "ml", "m|": "ml", "rnl": "ml",          # millilitre
    "kq": "kg", "k9": "kg",                       # kilogram
    "0": "g",                                     # rare, but seen on foil
}

# Hindi unit spellings as printed on bilingual packs, trailing dot removed.
HINDI_UNITS = {
    "ग्राम": "g", "ग्रा": "g", "कि.ग्रा": "kg", "किग्रा": "kg", "किलोग्राम": "kg",
    "कि.ग्रा.": "kg", "मि.ली": "ml", "मिली": "ml", "मिलीलीटर": "ml",
    "ली": "l", "लीटर": "l", "नग": "N",
}
_HINDI_UNIT_RE = (
    r"किलोग्राम|कि\.?\s?ग्रा\.?|ग्राम|ग्रा\.?|मिलीलीटर|मि\.?\s?ली\.?|मिली|"
    r"लीटर|ली\.?|नग"
)

QTY_UNITS = (
    r"(?:" + _HINDI_UNIT_RE + r"|"
    r"kg|kgs|k[q96]|g|gm|gms|gram|grams|ml|mls|m[I|]|rnl|"
    r"l|ltr|litre|liter|[|I!69&]|N|U|mm|cm|m|"
    # Rule 13(5)(ii) prescribes the symbol N or U for goods sold by
    # number, but almost nothing on a real shelf obeys that: a Casio
    # watch box reads "NET QUANTITY 1 PIECE". Without these the
    # quantity line fails to match at all and a greedy fallback grabs
    # whatever number it finds first - on the Casio box it captured
    # "MANUFACTURED ON : 03/2026" as the net quantity.
    r"piece|pieces|pc|pcs|no|nos|number|unit|units|"
    r"pkt|pkts|packet|packets|tablet|tablets|cap|caps|capsule|capsules)"
)

# "1 l" frequently comes back as a single token "11" - the space is lost
# and the litre glyph reads as a one. Only applied behind an explicit
# "Net Qty" prefix, where a bare trailing digit cannot plausibly be part
# of the quantity itself.
MERGED_LITRE = re.compile(
    r"(?:net\s*(?:qty|quantity|vol|volume))\s*:?\s*(\d+)\s*[1lI|]\b", re.I
)

PATTERNS: dict[str, list[re.Pattern]] = {
    "retail_sale_price": [
        re.compile(
            rf"(?:M\.?R\.?P\.?|maximum\s+retail\s+price|"
            rf"अधिकतम\s*खुदरा\s*मूल्य|अधि\.?\s*खु\.?\s*मू\.?|अ\.?\s*खु\.?\s*मू\.?|"
            rf"एम\.?\s*आर\.?\s*पी\.?)"
            rf"\s*:?\s*{CURRENCY}?\s*({NUMBER})",
            re.I,
        ),
        re.compile(rf"{CURRENCY}\s*({NUMBER})\s*(?:only)?", re.I),
    ],
    "net_quantity": [
        re.compile(
            rf"(?:net\s*(?:qty|quantity|wt|weight|vol|volume)|contents?|"
            rf"शुद्ध\s*(?:मात्रा|भार|वजन)|कुल\s*मात्रा|नेट\s*(?:मात्रा|वजन))\s*[:.\-]*\s*"
            # NOT \b here: a word boundary after a non-word unit glyph
            # such as "|" can never match, so every OCR-mangled litre
            # silently failed to extract.
            rf"({NUMBER})\s*({QTY_UNITS})(?![A-Za-z0-9])",
            re.I,
        ),
        
        MERGED_LITRE,
    ],
    "unit_sale_price": [
        re.compile(
            rf"(?:unit\s+sale\s+price|price\s+per\s+unit|per\s+{QTY_UNITS}|"
            rf"इकाई\s*(?:बिक्री\s*)?मूल्य)\s*:?\s*"
            rf"{CURRENCY}?\s*({NUMBER})",
            re.I,
        ),
        re.compile(rf"{CURRENCY}\s*({NUMBER})\s*(?:/|per|प्रति)\s*({QTY_UNITS})", re.I),
        # The rupee sign is the glyph OCR drops most often: "(₹0.83 per g)"
        # comes back as "(0.83 per g)" and the currency-anchored pattern
        # above then misses a unit price that is plainly printed. Without
        # a currency, require the shape that makes it unambiguous: a
        # two-decimal amount (Rule 6(11) prints them to two places)
        # followed by "per <unit>", optionally with a basis quantity.
        re.compile(
            rf"(?<![\d.])(\d+\.\d{{2}})\s*(?:/|per|प्रति)\s*(?:\d+\s*)?({QTY_UNITS})(?![A-Za-z0-9])",
            re.I,
        ),
    ],
    "manufacture_date": [
        re.compile(
            r"(?:mfg|mfd|pkd|manufactured|packed|packing|"
            r"date\s+of\s+(?:mfg|manufacture|packing)|"
            r"निर्माण\s*(?:की\s*)?(?:तिथि|तारीख)|उत्पादन\s*तिथि|पैकिंग\s*तिथि|"
            r"पैक\s*करने\s*की\s*तिथि)"
            # month/year, or day/month/year. The 4-digit year is tried
            # first and must not be followed by a digit, or "03/2026"
            # would split as month 03, "year" 20.
            r"[^\d]{0,12}(\d{1,2})[/\-.\s](\d{4}|\d{1,2})(?!\d)(?:[/\-.](\d{4}|\d{2})(?!\d))?",
            re.I,
        ),
        re.compile(
            r"(?:mfg|mfd|pkd|packed|manufactured)[^\w]{0,6}"
            r"((?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*)\.?\s*"
            r"[/\-.'\s]?\s*(\d{2,4})",
            re.I,
        ),
    ],
    "manufacturer_details": [
        # Indian packs abbreviate this relentlessly. A Nestle sachet
        # prints "Mkt by:" and "Mfg. by:"; only the fully spelled
        # "Marketed by" matched before, so the manufacturer declaration
        # was reported MISSING on a pack that plainly carries it - the
        # worst kind of false violation, because the label is compliant.
        re.compile(
            r"(?:(?:manufactured|manufacturer|mfg|mfd|mfrd|mftd|"
            r"packed|pkd|marketed|mktd|mkt|imported|imp)\.?\s*"
            r"(?:by|for)\.?|"
            # Multi-unit brands print the unit list by batch code: "For
            # name and address of mfg. unit read the first two characters
            # of batch code & see: (BM) Dabur India Limited, ..." (real).
            r"name\s*(?:and|&)\s*address|"
            r"निर्माता|विपणनकर्ता|आयातक|पैककर्ता|द्वारा\s*(?:निर्मित|विपणन|पैक(?:\s*किया)?))"
            r"\s*:?\s*(.{6,160})",
            re.I | re.S,
        ),
    ],
    "consumer_care": [
        re.compile(
            # Real packs word this many ways: "Consumer Care", "Consumer
            # Services", "Customer Support", "For queries/feedback/
            # complaints contact...", "Toll free:". The window is wide
            # (260 chars over up to 4 lines) because the phone / e-mail
            # is usually on the LAST line of the block, and a 160-char
            # cap cut it off on a real Nestle back panel.
            r"(?:consumer\s*(?:care|services?|affairs|relations?|helpline|cel+)|"
            r"customer\s*(?:care|services?|support|helpline|cel+)|complaints?|"
            r"queries|grievance|tol+[\s-]*free|helpline|let'?s\s+talk|"
            r"उपभोक्ता\s*(?:सेवा|शिकायत)|ग्राहक\s*सेवा)"
            r"[ \t]*[:\-]?\s*(.{6,260})",
            re.I | re.S,
        ),
    ],
    "common_name": [
        # Imported packs routinely head this "COMMODITY:" rather than
        # printing a bare descriptive name.
        re.compile(
            r"(?:commodity|generic\s+name|common\s+name|product\s+type)"
            r"\s*:?\s*([A-Za-z][A-Za-z \-/&]{2,40})",
            re.I,
        ),
        # NO unlabelled fallback, PROVEN unsafe by a stability test on a
        # real photo (scripts/diagnose.py --mode stability), not just
        # argued in the abstract. A negative-context gate rejects known
        # disqualifying words - "consumer", "care", "nutrition" - but on
        # a real image OCR noise destroys those exact words before the
        # regex ever sees them: "NESTLE CONSUMER CARE" was read as
        # "HESTECOIINER ARE", which contains no recognisable "consumer"
        # or "care" for the gate to catch. Perturbing the same photo by a
        # few degrees of rotation produced FIFTEEN different values for
        # this field, all garbage: "HESTECOIINER ARE", "NESTLE INDIA",
        # "i My", "te ie". A gate that a small rotation defeats is not a
        # safety net. Same failure class as the unlabelled net_quantity
        # fallback that promoted a nutrition figure to the pack quantity -
        # a wrong fact is worse than a missing one, because nobody
        # rechecks a field that looks answered.
    ],
    "country_of_origin": [
        re.compile(
            r"(?:country\s+of\s+origin|मूल\s*देश|उत्पत्ति\s*(?:का\s*)?देश)"
            r"\s*:?\s*([A-Za-z\u0900-\u097F\s]{2,40})",
            re.I,
        ),
    ],
}

MONTHS = {
    m: i + 1
    for i, m in enumerate(
        ["jan", "feb", "mar", "apr", "may", "jun",
         "jul", "aug", "sep", "oct", "nov", "dec"]
    )
}


# =====================================================================
# Extractor
# =====================================================================

@dataclass
class ExtractionContext:
    """Optional hooks the extractor uses when they are available."""
    image = None
    calibration = None
    measure_glyphs: Optional[Callable] = None


class RegexExtractor:
    """
    Deterministic extraction over OCR spans.

    Two-pass by design:
      Pass 1 - line-level match against a labelled pattern ("MRP: 120").
               High precision; a labelled field is unambiguous.
      Pass 2 - for fields still missing, unlabelled fallback patterns
               over the whole text ("₹120" on its own). Lower precision,
               so matches get lower confidence and the rules engine can
               weigh them accordingly.

    Multi-line fields (addresses) get a lookahead window, because a
    consumer-care block is nearly always 2-4 lines and the first line
    alone fails the reachability check.
    """

    def __init__(self, window_lines: int = 3):
        self.window_lines = window_lines

    def extract(
        self,
        spans: list[TextSpan],
        image=None,
        calibration=None,
    ) -> list[Declaration]:
        spans = [s for s in spans if clean(s.text)]
        # Reading order via row bucketing (see vision.ocr.base.sort_reading_order);
        # a raw (y, x) sort interleaves words from adjacent lines.
        from ..vision.ocr.base import sort_reading_order
        spans = sort_reading_order(spans)
        lines = self._group_into_lines(spans)

        found: dict[str, Declaration] = {}

        # ---- Pass 1: labelled patterns, line + lookahead window -----
        # The anchor must match on THIS line before the window widens.
        # Searching a multi-line window directly lets a field latch onto
        # text belonging to an earlier line: the MRP pattern matched
        # inside the window opened at the product-name line and cut off
        # the "(inclusive of all taxes)" qualifier two lines below - a
        # confident FALSE VIOLATION on a compliant package.
        for line in lines:
            line_text = self._line_text(line)
            for field_id, patterns in PATTERNS.items():
                if field_id in found:
                    continue
                if not self._anchored_here(field_id, line, lines, line_text):
                    continue
                decl = self._match_labelled(field_id, line, lines, line_text, 0.92)
                if decl:
                    found[field_id] = decl

        # ---- Pass 1b: OCR-damaged labels (rules/lexicon.yaml) -------
        # "TINET QUNIIITY:", "Tol Free", "NESTLÉCONSUMER CARE": the label
        # is there but no exact pattern sees it. A lexicon anchor that
        # matches closely enough is swapped in for the damaged words and
        # the normal pattern runs on the repaired line. Marked on the
        # declaration, at lower confidence.
        from . import fuzzy as _fz

        for line in lines:
            line_text = self._line_text(line)
            if _fz.in_negative_context(line_text):
                continue
            for field_id, group in _FUZZY_GROUPS.items():
                if field_id in found:
                    continue
                hit = _fz.find_anchor(line_text, group)
                if hit is None:
                    continue
                canon, score, a, b = hit
                repaired = f"{_CANONICAL_LABEL.get(field_id, canon)} {line_text[b:]}".strip()
                if not PATTERNS[field_id][0].search(repaired):
                    continue
                decl = self._match_labelled(field_id, line, lines, repaired, 0.75)
                if decl:
                    decl.notes.append(
                        f"Label read as '{line_text[a:b].strip()}' and matched to "
                        f"'{canon}' by similarity ({score:.0f}/100); confirm on the pack.")
                    found[field_id] = decl

        # ---- Pass 2: unlabelled fallbacks ---------------------------
        for idx, line in enumerate(lines):
            line_text = self._line_text(line)
            for field_id, patterns in PATTERNS.items():
                if field_id in found or len(patterns) < 2:
                    continue
                # Unlabelled patterns are greedy by nature: the MRP
                # fallback is just "<currency> <number>", which happily
                # matches the "Unit Sale Price: Rs. 24.00" line when the
                # real MRP is absent. The package still gets flagged, but
                # under the wrong sub-rule and with the wrong evidence
                # crop - and an inspector who opens a violation report
                # about a missing MRP and sees a photo of the unit price
                # stops trusting the tool. So a fallback never fires on a
                # line that plainly belongs to another declaration.
                if _disqualified(field_id, line_text):
                    continue
                for pat in patterns[1:]:
                    m = pat.search(line_text)
                    if not m:
                        continue
                    decl = self._build(field_id, m, line, line_text, confidence=0.68)
                    if decl:
                        found[field_id] = decl
                    break

        # ---- Pass 3: unlabelled date pairs -------------------------
        # Many packs print "See coding area for MFD / USE BY" (Maggi) or
        # "Mfd. & Use before, See above" (Dabur) and put the dates on
        # their own, unlabelled: one inkjet line "MAR/26-NOV/26-D", or two
        # stacked lines "03/2026 (B4)" / "03/2029". When the pack refers
        # to such dates, two dates close together are MFD and USE BY, and
        # the EARLIER one is the manufacture date - chronology decides,
        # not print order. One date alone is never taken: it could be
        # either.
        if "manufacture_date" not in found:
            all_text = " ".join(self._line_text(l) for l in lines)
            if _MFG_CONTEXT.search(all_text):
                hit = self._date_pair(lines)
                if hit is not None:
                    yr, mon, tok, used_lines = hit
                    spans_used = [sp for l in used_lines for sp in l]
                    found["manufacture_date"] = Declaration(
                        field_id="manufacture_date",
                        raw_text=" / ".join(self._line_text(l) for l in used_lines),
                        value=f"{mon:02d}/{yr}",
                        bbox=self._line_bbox(spans_used),
                        spans=spans_used,
                        extraction_confidence=0.6 * _mean_conf(spans_used),
                        present=True,
                        notes=[
                            f"Read from an unlabelled date pair; the earlier date "
                            f"({clean(tok)}) is taken as manufacture, since a "
                            f"manufacture date cannot follow its use-by date."
                        ],
                    )

        # ---- Pass 4: consumer care from contact details -------------
        # No heading read, but a toll-free number or an e-mail address is
        # on the pack ("：18002668110", "infoohrlindia.com" on a curved
        # bottle where "Customer Care" wrapped out of view). A toll-free
        # number on a retail pack is the consumer helpline in practice;
        # found this way it is marked as such and carries lower weight.
        if "consumer_care" not in found:
            for line in lines:
                lt = self._line_text(line)
                if _disqualified("consumer_care", lt):
                    continue
                m = _TOLL_FREE.search(lt) or _EMAIL_LIKE.search(lt)
                if not m:
                    continue
                window = [line] + [l for l in self._below(line, lines, limit=2)
                                   if _TOLL_FREE.search(self._line_text(l))
                                   or _EMAIL_LIKE.search(self._line_text(l))]
                spans_used = [sp for l in window for sp in l]
                found["consumer_care"] = Declaration(
                    field_id="consumer_care",
                    raw_text=" ".join(self._line_text(l) for l in window),
                    value=clean(m.group(0)),
                    bbox=self._line_bbox(spans_used),
                    spans=spans_used,
                    extraction_confidence=0.5 * _mean_conf(spans_used),
                    present=True,
                    notes=["Identified from a toll-free number / e-mail address; "
                           "no 'consumer care' heading was read. Confirm on the pack."],
                )
                break

        # ---- Attach glyph metrics -----------------------------------
        if image is not None:
            from ..vision.glyph import measure_glyphs
            for decl in found.values():
                if decl.bbox is None:
                    continue
                box, hint = decl.bbox, decl.raw_text
                if decl.field_id in _MULTILINE_FIELDS and decl.spans:
                    # Measure the anchor line, not the whole block: the
                    # block's box can take in a bar code or a logo, whose
                    # bars read as impossibly narrow "letters".
                    box, hint = decl.spans[0].bbox, decl.spans[0].text
                decl.glyph = measure_glyphs(image, box, calibration, text_hint=hint)

        # ---- Emit absent fields explicitly --------------------------
        # The rules engine needs to distinguish "we looked and it is not
        # there" from "we never checked". Absent-but-declared is the
        # former; a missing key would be the latter.
        for field_id in PATTERNS:
            found.setdefault(field_id, Declaration(field_id=field_id, present=False))

        return list(found.values())

    # -- helpers ------------------------------------------------------

    def _group_into_lines(
        self, spans: list[TextSpan], y_tol_ratio: float = 0.5
    ) -> list[list[TextSpan]]:
        """
        One OCR region = one line, plus label/value re-joins.

        PaddleOCR already returns LINES, and where it splits a printed
        row into two regions it is usually because they are in different
        columns. The old grouper (written for Tesseract's word boxes)
        merged every region whose centre fell within half a line height
        into one "row". On a real Maggi back panel - three columns of
        tight 8-point text - that spliced the ingredients, the
        manufacturer address and the consumer-care block into the same
        lines, so the manufacturer "address" began with "Green cardamom
        powder" and consumer care was never found at all.

        The one join that IS needed: a fragment that is only a LABEL
        followed, on the same row, by a value - "NET QUANTITY:" ... "6 g",
        "Net Qty.:" ... "45ml" (both real). A label with nothing of its
        own next to a value is a key-value pair, not two columns.

        Vertical spans (inkjet codes printed at 90 degrees) stay alone.
        """
        if not spans:
            return []

        vertical = [s for s in spans if getattr(s, "vertical", False)]
        horiz = [s for s in spans if not getattr(s, "vertical", False)]
        horiz.sort(key=lambda s: (s.bbox.cy, s.bbox.x))

        heights = sorted(s.bbox.h for s in horiz) or [1.0]
        median_h = heights[len(heights) // 2] or 1.0
        pair_gap = median_h * 14.0

        # Labels claim their values FIRST: sorted by centre, the value
        # "45ml" can come before its label "Net Qty.:" (centres 3 px
        # apart on a real bottle) and would otherwise be taken as a line
        # of its own before the label ever looked for it.
        used: set[int] = set()
        lines: list[list[TextSpan]] = []
        for i, s in enumerate(horiz):
            if i in used or not _is_label_only(s.text):
                continue
            # The NEAREST region to the right on the same row, and only if
            # it is a value: "MANUFACTURED" | "ON" | ":" | "03/2026" must
            # not skip "ON :" to grab the date.
            best, best_gap = None, pair_gap
            for j, t in enumerate(horiz):
                if j in used or j == i:
                    continue
                tol = y_tol_ratio * min(s.bbox.h, t.bbox.h)
                if abs(t.bbox.cy - s.bbox.cy) > tol:
                    continue
                gap = t.bbox.x - s.bbox.x2
                if -0.5 * s.bbox.h <= gap < best_gap:
                    best, best_gap = j, gap
            if best is None:
                continue
            t = horiz[best]
            single = " " not in clean(s.text) and " " not in clean(t.text)
            if single:
                continue        # word-level input: the chaining below handles it
            if not _is_label_only(t.text) and _VALUE_START.search(clean(t.text)):
                lines.append([s, t])
                used.update((i, best))
        # Word-level input (single tokens, as a VLM or ground-truth list
        # may supply) is chained back into lines: two adjacent single
        # words on one row are one line. Paddle LINES are never merged
        # this way - "B) Lic. No. 10012025000032" and "18001031947" sit
        # 3 px apart on a real sachet and belong to different columns.
        singles = [(i, s) for i, s in enumerate(horiz) if i not in used]
        chained: dict[int, list[TextSpan]] = {}
        order = sorted(singles, key=lambda t: t[1].bbox.x)
        for i, s in order:
            if i in chained:
                continue
            line = [s]
            chained[i] = line
            if " " in clean(s.text):
                continue
            while True:
                last = line[-1]
                nxt = None
                for j, t in order:
                    if j in chained or " " in clean(t.text):
                        continue
                    if abs(t.bbox.cy - last.bbox.cy) > y_tol_ratio * min(last.bbox.h, t.bbox.h):
                        continue
                    gap = t.bbox.x - last.bbox.x2
                    if -0.3 * last.bbox.h <= gap <= 0.8 * max(last.bbox.h, t.bbox.h):
                        nxt = (j, t)
                        break
                if nxt is None:
                    break
                chained[nxt[0]] = line
                line.append(nxt[1])
        seen_ids = set()
        for line in chained.values():
            if id(line) not in seen_ids:
                seen_ids.add(id(line))
                lines.append(line)

        lines.sort(key=lambda l: (sum(t.bbox.cy for t in l) / len(l), l[0].bbox.x))
        lines.extend([v] for v in sorted(vertical, key=lambda s: s.bbox.x))
        return lines

    def _anchored_here(self, field_id, line, lines, line_text) -> bool:
        """
        Does this field's label start on THIS line? A heading on a line of
        its own ("Regd. Office & Consumer Cell" - Dabur) has its value on
        the lines below, so for block fields the next line is allowed to
        complete the match, as long as the label itself is on this one.
        """
        pat = PATTERNS[field_id][0]
        if pat.search(line_text):
            return True
        if field_id not in _MULTILINE_FIELDS:
            return False
        below = self._below(line, lines, limit=1)
        if not below:
            return False
        probe = f"{line_text} {self._line_text(below[0])}"
        m = pat.search(probe)
        return bool(m) and m.start() < len(line_text)

    def _match_labelled(self, field_id, line, lines, line_text, confidence):
        """Window + pattern + build for one anchored line (pass 1 and 1b)."""
        pat = PATTERNS[field_id][0]
        if field_id in _MULTILINE_FIELDS:
            # The block continues BELOW, in the same column - not "the
            # next lines in reading order", which on a multi-column back
            # panel belong to other columns.
            window = [line]
            texts = [line_text]
            # Consumer care runs to five lines on real packs (office,
            # address, e-mail, website, toll free - Dabur); a
            # manufacturer block listing units by batch code to five too.
            span_n = self.window_lines + 2
            for nxt in self._below(line, lines, limit=span_n - 1):
                nt = self._line_text(nxt)
                # Stop at OCR garbage (bar code, smudges): not part of
                # the address, and glyphs measured over a bar code read
                # as "width ratio 0.16".
                if _mean_conf(nxt) < 0.6 and not re.search(r"[\d@]", nt):
                    break
                # A block ends where the next declaration begins: with
                # line-level OCR the manufacturer window ran straight on
                # into "Consumer Care: ..." and reported it as address.
                if any(PATTERNS[o][0].search(nt) for o in PATTERNS if o != field_id):
                    break
                window.append(nxt)
                texts.append(nt)
            subject = " ".join(texts)
            m = pat.search(subject) or pat.search(line_text)
            span_line = [s for l in window for s in l]
        else:
            # Price qualifiers wrap below ("MRP Rs. 443.74" / "(inclusive
            # of all" / "taxes)") or sit to the RIGHT as their own OCR
            # region ("MRP: Rs. 1495.00" | "INCL. OF ALL TAXES", Casio).
            # The value is matched on this line only; the neighbours are
            # there so the qualifier can be seen.
            subject = line_text
            for nxt in (self._right_of(line, lines, max_gap_ratio=3.0, limit=1)
                        + self._below(line, lines, limit=2)):
                subject = f"{subject} {self._line_text(nxt)}"
                if _QUALIFIER.search(subject):
                    break
            m = pat.search(line_text)
            span_line = line
        if not m:
            return None
        return self._build(field_id, m, span_line, subject, confidence=confidence)

    def _date_pair(self, lines):
        """Two dates on one line, or on two lines stacked in one column."""
        def dates_in(text: str, date_only: bool):
            out = []
            # Dot-matrix inkjet: "N0V/26", "5EP/26" - a digit read for the
            # O or S of a month name. Only inside a letter-bearing 3-char
            # token directly followed by a year.
            text = re.sub(
                r"(?<![A-Za-z0-9])([A-Za-z0-9]{3})(?=\s*[/\-.'’]?\s*\d{2}(?!\d{3}))",
                lambda m: (m.group(1).replace("0", "O").replace("5", "S")
                           if sum(ch.isalpha() for ch in m.group(1)) >= 2 else m.group(1)),
                text)
            for mt in _MONTH_TOKEN.finditer(text):
                mon = MONTHS.get(mt.group(1)[:3].lower())
                yr = _year(mt.group(2))
                if mon and yr:
                    out.append((yr, mon, mt.group(0), mt.span()))
            squeezed = re.sub(r"(?<=\d) (?=\d)", "", text)
            for mt in _NUMERIC_DATE.finditer(squeezed):
                if mt.group(3):                      # dd/mm/yy
                    mon, yr = int(mt.group(2)), _year(mt.group(3))
                else:                                # mm/yyyy
                    mon, yr = int(mt.group(1)), _year(mt.group(2))
                if 1 <= mon <= 12 and yr:
                    out.append((yr, mon, mt.group(0), mt.span()))
            if date_only and out:
                # The line must be ABOUT the date: "03/2026 (B4)" yes,
                # "Lic. No. 10012025000032" or a nutrition line no.
                alnum = len(re.sub(r"[^0-9A-Za-z]", "", squeezed)) or 1
                covered = sum(len(re.sub(r"[^0-9A-Za-z]", "", d[2])) for d in out)
                if covered / alnum < 0.6:
                    return []
            return out

        for line in lines:
            lt = self._line_text(line)
            ds = dates_in(lt, date_only=False)
            if len(ds) >= 2 and len({(d[0], d[1]) for d in ds}) >= 2:
                yr, mon, tok, _ = min(ds)
                return yr, mon, tok, [line]
        for line in lines:
            ds = dates_in(self._line_text(line), date_only=True)
            if len(ds) != 1:
                continue
            for nxt in self._below(line, lines, limit=1):
                ds2 = dates_in(self._line_text(nxt), date_only=True)
                if len(ds2) == 1 and (ds2[0][0], ds2[0][1]) != (ds[0][0], ds[0][1]):
                    yr, mon, tok, _ = min(ds + ds2)
                    return yr, mon, tok, [line, nxt]
        return None

    @staticmethod
    def _line_h(line: list[TextSpan]) -> float:
        return max(1.0, sorted(t.bbox.h for t in line)[len(line) // 2])

    def _right_of(self, line, lines, max_gap_ratio: float = 14.0, limit: int = 2):
        """Lines on the SAME row, to the right, nearest first."""
        b = self._line_bbox(line)
        h = self._line_h(line)
        out = []
        for other in lines:
            if other is line:
                continue
            ob = self._line_bbox(other)
            if abs(ob.cy - b.cy) > 0.5 * min(h, self._line_h(other)):
                continue
            gap = ob.x - b.x2
            if -0.5 * h <= gap <= max_gap_ratio * h:
                out.append((gap, other))
        return [o for _, o in sorted(out, key=lambda t: t[0])[:limit]]

    def _below(self, line, lines, limit: int = 3, max_gap_ratio: float = 1.2):
        """
        The lines directly BELOW, in the same column, top to bottom.

        Same column = left edges within ~1.5 line heights, or at least
        half the narrower line overlapping horizontally. Stops at the
        first vertical gap larger than `max_gap_ratio` line heights, so a
        block ends where the print leaves space.
        """
        out: list[list[TextSpan]] = []
        cur = line
        pool = [l for l in lines if l is not line and not getattr(l[0], "vertical", False)]
        while len(out) < limit:
            cb = self._line_bbox(cur)
            h = self._line_h(cur)
            best, best_dy = None, None
            for other in pool:
                if other in out:
                    continue
                ob = self._line_bbox(other)
                dy = ob.cy - cb.cy
                if dy <= 0.5 * h:
                    continue
                if ob.y - cb.y2 > max_gap_ratio * h:
                    continue
                inter = max(0.0, min(cb.x2, ob.x2) - max(cb.x, ob.x))
                narrower = max(1.0, min(cb.w, ob.w))
                if abs(ob.x - cb.x) > 1.5 * h and inter / narrower < 0.5:
                    continue
                if best_dy is None or dy < best_dy:
                    best, best_dy = other, dy
            if best is None:
                break
            out.append(best)
            cur = best
        return out

    @staticmethod
    def _same_column(a: list[TextSpan], b: list[TextSpan],
                     min_overlap: float = 0.35) -> bool:
        """Kept for callers outside this class; see _below for the rule used here."""
        ax1 = min(s.bbox.x for s in a); ax2 = max(s.bbox.x2 for s in a)
        bx1 = min(s.bbox.x for s in b); bx2 = max(s.bbox.x2 for s in b)
        inter = max(0.0, min(ax2, bx2) - max(ax1, bx1))
        narrower = min(ax2 - ax1, bx2 - bx1) or 1.0
        return (inter / narrower) >= min_overlap

    @staticmethod
    def _line_text(line: list[TextSpan]) -> str:
        return clean(" ".join(s.text for s in line))

    @staticmethod
    def _line_bbox(line: list[TextSpan]) -> BBox:
        x = min(s.bbox.x for s in line)
        y = min(s.bbox.y for s in line)
        x2 = max(s.bbox.x2 for s in line)
        y2 = max(s.bbox.y2 for s in line)
        return BBox(x, y, x2 - x, y2 - y)

    def _build(
        self,
        field_id: str,
        match: re.Match,
        line: list[TextSpan],
        subject: str,
        confidence: float,
    ) -> Optional[Declaration]:
        raw = clean(match.group(0))
        bbox = self._line_bbox(line)
        value, unit = None, None
        notes: list[str] = []

        # A prohibited qualifier sits AFTER the quantity - "500 g
        # (approx.)" - so trimming evidence to the match alone hides the
        # very words Rule 12(6) forbids. Re-attach the qualifier itself,
        # not the rest of the line, so the check can see it without the
        # declaration swallowing its neighbours.
        if field_id == "net_quantity":
            banned = re.search(
                r"\(?\s*(?:approx(?:imately)?\.?|about|minimum|min\.?|"
                r"maximum|max\.?|average|avg\.?|not\s+less\s+than|"
                r"more\s+or\s+less)\s*\)?",
                subject, re.I,
            )
            if banned:
                q = clean(banned.group(0))
                if q and q.lower() not in raw.lower():
                    raw = f"{raw} {q}"

        if field_id in ("retail_sale_price", "unit_sale_price"):
            try:
                value = float(normalise_numeric(match.group(1)).replace(",", ""))
            except (ValueError, IndexError):
                return None
            # The "inclusive of all taxes" qualifier is part of the legal
            # declaration, so the phrasing check must be able to see it -
            # but taking the WHOLE window as evidence drags in whatever
            # else shares the line. On a multi-column back panel that
            # produced an MRP declaration whose raw_text carried the
            # entire nutrition block, which is useless as evidence: an
            # inspector is shown a paragraph and asked to accept that the
            # price is somewhere in it.
            #
            # Take the match itself, then re-attach ONLY the qualifier,
            # wherever it sits in the window.
            raw = clean(match.group(0))
            qualifier = _QUALIFIER.search(subject)
            if qualifier:
                q = clean(qualifier.group(0))
                if q.lower() not in raw.lower():
                    raw = f"{raw} {q}"

        elif field_id == "net_quantity":
            try:
                value = float(normalise_numeric(match.group(1)).replace(",", ""))
                try:
                    # Normalise BEFORE lowercasing: the confusion map
                    # keys on case ("I" is a mangled litre, "i" is not).
                    unit = normalise_unit(match.group(2)).lower()
                except (IndexError, re.error):
                    # The merged-litre fallback captures only the number;
                    # the unit is implied by the pattern itself.
                    unit = "l"
            except (ValueError, IndexError):
                return None
            try:
                unit_tok = match.group(2)
            except IndexError:
                unit_tok = None
            if unit_tok is None:
                notes.append("Litre inferred from a trailing '1' after the "
                             "quantity (\"1 l\" read as \"11\"); confirm on the pack.")
                confidence *= 0.5
            elif unit_tok.strip() in {"6", "9", "0", "&", "q", "|", "I", "!"}:
                notes.append(f"Unit '{unit}' inferred from a '{unit_tok.strip()}' "
                             f"glyph that OCR commonly confuses with it; confirm "
                             f"on the pack.")
                confidence *= 0.5
            # Do NOT reset raw here. The prohibited-qualifier text was
            # already re-attached above, and overwriting it discarded the
            # very words Rule 12(6) forbids - the check then passed a
            # label reading "500 g (approx.)".

        elif field_id == "manufacture_date":
            try:
                a, b = match.group(1), match.group(2)
                c = match.group(3) if (match.re.groups or 0) >= 3 else None
                if c:
                    # dd/mm/yy: "MFG. DATE: 19/06/26" (a real Haldiram pack)
                    a, b = b, c
                month = MONTHS.get(a[:3].lower()) if a[:1].isalpha() else int(a)
                year = int(b)
                if year < 100:
                    year += 2000
                if not month or not 1 <= month <= 12:
                    return None
                value = f"{month:02d}/{year}"
            except (ValueError, IndexError):
                return None

        else:
            try:
                value = clean(match.group(1))
            except IndexError:
                value = raw
            if field_id in _MULTILINE_FIELDS:
                # Multi-line fields legitimately wrap (an address runs to
                # three lines), so the window IS the evidence here. It is
                # bounded by _same_column at the point the window is
                # built, so it cannot cross into a neighbouring column.
                raw = clean(subject)

        return Declaration(
            field_id=field_id,
            raw_text=raw,
            value=value,
            unit=unit,
            bbox=bbox,
            spans=list(line),
            extraction_confidence=confidence * _mean_conf(line),
            present=True,
            notes=notes,
        )


_MULTILINE_FIELDS = {"manufacturer_details", "consumer_care"}

# Lexicon anchor group per field, and the label the repaired line gets.
_FUZZY_GROUPS = {
    "net_quantity": "net_qty",
    "retail_sale_price": "mrp",
    "unit_sale_price": "unit_price",
    "manufacture_date": "mfg_date",
    "manufacturer_details": "manufacturer",
    "consumer_care": "consumer_care",
}
# No trailing colon: the damaged label's own ":" follows in the repaired line.
_CANONICAL_LABEL = {
    "net_quantity": "Net Quantity",
    "retail_sale_price": "MRP",
    "unit_sale_price": "Unit Sale Price",
    "manufacture_date": "Mfd",
    "manufacturer_details": "Manufactured by",
    "consumer_care": "Consumer Care",
}

# The "inclusive of all taxes" qualifier in the forms packs actually use,
# tolerant of the spacing OCR loses: "(Incl.of all taxes)", "Inclusive of
# taxes", "INCL OF ALL TAXES", and the Hindi "(सभी करों सहित)".
_QUALIFIER = re.compile(
    r"\(?\s*(?:incl(?:usive|\.)?|inc\.)\s*\.?\s*(?:of)?\s*(?:a[l1iI|]+)?\s*tax(?:es)?\s*\)?"
    r"|\(?\s*(?:सभी\s*)?करों?\s*सहित\s*\)?",
    re.I,
)

# A fragment that is a declaration label and nothing else ("NET QUANTITY",
# "MRP:", "Mfd.") - see _group_into_lines, step 3.
_LABEL_ONLY = re.compile(
    r"^\s*(?:net\s*(?:qty|quantity|wt\.?|weight|vol\.?|volume|content)|contents?|"
    r"m\.?\s*r\.?\s*p\.?|maximum\s+retail\s+price|mfg\.?|mfd\.?|pkd\.?|"
    r"manufactured\s+on|packed\s+on|date\s+of\s+(?:mfg|manufacture|packing)|"
    r"unit\s+sale\s+price|best\s+before|use\s+by|expiry(?:\s+date)?|"
    r"country\s+of\s+origin|शुद्ध\s*(?:मात्रा|भार|वजन)|अधिकतम\s*खुदरा\s*मूल्य|"
    r"निर्माण\s*(?:की\s*)?तिथि)\s*[:.\-]*\s*$",
    re.I,
)
def _is_label_only(text: str) -> bool:
    """A bare label - exactly ("NET QUANTITY:") or OCR-damaged ("TINET QUNIIITY:")."""
    t = clean(text)
    if _LABEL_ONLY.search(t):
        return True
    if len(t) > 24 or re.search(r"\d", t):
        return False
    from . import fuzzy as _fz

    for group in ("net_qty", "mrp", "mfg_date", "unit_price"):
        hit = _fz.find_anchor(t, group)
        if hit and (hit[3] - hit[2]) >= 0.6 * len(re.sub(r"[^A-Za-z]", "", t)):
            return True
    return False


_VALUE_START = re.compile(r"^\s*(?:₹|rs\.?|inr|रु\.?|\d|[A-Za-z]{3}\s*[/\-.']?\s*\d)", re.I)

# Coded dates on inkjet batch lines: "MAR/26-NOV/26-D", "JAN 26 DEC 27".
_MONTH_TOKEN = re.compile(
    r"\b(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?\s*"
    r"[/\-.'’]?\s*(\d{4}|\d{2})(?!\d)",
    re.I,
)
_MFG_CONTEXT = re.compile(
    r"\b(?:mfd|mfg|pkd|packed|manufactured|date\s+of\s+pack|use\s*(?:by|before)|"
    r"best\s+before|expiry|coding\s+area)", re.I)
# mm/yyyy, or dd/mm/yy(yy). Years are checked by _year.
# A decimal like "9.1g" or "Rs.10.00" must never read as a date, so a
# dot separator is only accepted with a 4-digit year or a full d.m.y.
_NUMERIC_DATE = re.compile(
    r"(?<![\d/.])(\d{1,2})(?:/|-|\.(?=\d{4}|\d{1,2}\.\d))(\d{4}|\d{2})"
    r"(?:[/\-.](\d{4}|\d{2}))?(?![\d/.])")
_TOLL_FREE = re.compile(r"(?<!\d)1800[\s\-]?\d{3}[\s\-]?\d{3,4}(?!\d)")
_EMAIL_LIKE = re.compile(r"[\w.\-]+@[\w\-]+\.[\w.]+")


def _year(tok: str):
    """A plausible manufacture/expiry year, or None."""
    try:
        y = int(tok)
    except (TypeError, ValueError):
        return None
    if y < 100:
        y += 2000
    return y if 2000 <= y <= 2045 else None


def _mean_conf(line: list[TextSpan]) -> float:
    return sum(s.confidence for s in line) / len(line) if line else 0.0


# =====================================================================
# VLM extraction
# =====================================================================

EXTRACTION_SCHEMA = {
    "manufacturer_details": "string or null - full name and address of manufacturer/packer/importer",
    "common_name": "string or null - generic commodity name, NOT the brand name",
    "net_quantity_value": "number or null",
    "net_quantity_unit": "string or null - one of g, kg, ml, l, N, U, mm, cm, m",
    "net_quantity_raw": "string or null - the full quantity line as printed",
    "manufacture_date": "string or null - as MM/YYYY",
    "mrp_value": "number or null",
    "mrp_raw": "string or null - the full price line as printed, including any tax qualifier",
    "consumer_care": "string or null - full consumer care block",
    "unit_sale_price": "number or null",
    "country_of_origin": "string or null",
}

VLM_EXTRACTION_PROMPT = f"""You are reading an Indian packaged-commodity label to check compliance with the Legal Metrology (Packaged Commodities) Rules, 2011.

Extract ONLY what is literally printed on the package. Return a single JSON object, no prose, no markdown fences, with exactly these keys:

{json.dumps(EXTRACTION_SCHEMA, indent=2)}

Critical rules:
- Use null for anything not visibly printed. NEVER infer, complete or guess a value. A null is a correct answer; an invented MRP is a false accusation against a manufacturer.
- For *_raw fields, reproduce the line exactly as printed, including the currency symbol and any wording such as "inclusive of all taxes". The exact wording is legally significant and is checked separately.
- Do not put the brand name in common_name. "Surf Excel" is a brand; "Detergent Powder" is the common name.
- If a character is illegible, use "?" within the raw string rather than omitting it.
"""


class SchemaVLMExtractor:
    """
    Constrained extraction for labels the regex layer cannot parse.

    The schema constraint is not decoration. Free-form VLM output on this
    task hallucinates well-formed prices and addresses that are not on
    the package, and those are exactly the errors that would put a wrong
    violation on a legal report. Constrain, validate, and treat every
    field as null until proven otherwise.
    """

    def __init__(self, client=None, model: str = ""):
        self.client = client
        self.model = model

    def available(self) -> bool:
        return self.client is not None

    def extract(self, image, spans=None, calibration=None) -> list[Declaration]:
        if not self.available():
            return []
        payload = self._call_model(image)
        return self._to_declarations(payload)

    def _call_model(self, image) -> dict:
        raise NotImplementedError("Wire your VLM provider here.")

    def _to_declarations(self, payload: dict) -> list[Declaration]:
        out: list[Declaration] = []

        def add(field_id, value, raw=None, unit=None, conf=0.8):
            present = value is not None and value != ""
            out.append(
                Declaration(
                    field_id=field_id,
                    raw_text=raw if raw is not None else (str(value) if present else ""),
                    value=value,
                    unit=unit,
                    extraction_confidence=conf if present else 0.0,
                    present=present,
                )
            )

        add("manufacturer_details", payload.get("manufacturer_details"))
        add("common_name", payload.get("common_name"))
        add("net_quantity", payload.get("net_quantity_value"),
            raw=payload.get("net_quantity_raw"), unit=payload.get("net_quantity_unit"))
        add("manufacture_date", payload.get("manufacture_date"))
        add("retail_sale_price", payload.get("mrp_value"), raw=payload.get("mrp_raw"))
        add("consumer_care", payload.get("consumer_care"))
        add("unit_sale_price", payload.get("unit_sale_price"))
        add("country_of_origin", payload.get("country_of_origin"))
        return out


# =====================================================================
# Hybrid
# =====================================================================

class HybridExtractor:
    """
    Regex first, VLM only for fields regex could not find.

    Keeps cost and latency low, keeps most results explainable, and
    isolates the black box to the cases that actually need it. Track how
    often the VLM path fires - if it is firing on 80% of packages your
    regex layer needs work, not a bigger model.
    """

    def __init__(self, regex: Optional[RegexExtractor] = None, vlm=None):
        self.regex = regex or RegexExtractor()
        self.vlm = vlm
        self.vlm_invocations = 0

    def extract(self, spans, image=None, calibration=None) -> list[Declaration]:
        decls = self.regex.extract(spans, image=image, calibration=calibration)
        missing = [d.field_id for d in decls if not d.present]

        if missing and self.vlm is not None and self.vlm.available() and image is not None:
            self.vlm_invocations += 1
            try:
                vlm_decls = {d.field_id: d for d in self.vlm.extract(image)}
                merged = []
                for d in decls:
                    if not d.present and d.field_id in vlm_decls and vlm_decls[d.field_id].present:
                        v = vlm_decls[d.field_id]
                        v.extraction_confidence *= 0.9  # discount vs. regex
                        merged.append(v)
                    else:
                        merged.append(d)
                decls = merged
            except Exception as exc:
                print(f"[hybrid] VLM extraction failed: {exc}")

        return decls


# ---------------------------------------------------------------------
# Negative context for unlabelled fallback patterns
# ---------------------------------------------------------------------
# Phrases that mark a line as belonging to a DIFFERENT declaration.
# Consulted only in Pass 2, where patterns are deliberately loose.
_NEGATIVE_CONTEXT: dict[str, tuple[str, ...]] = {
    "retail_sale_price": ("unit sale price", "unit price", "per unit", "per 100"),
    "unit_sale_price": ("maximum retail price", "m.r.p", "mrp"),
    "net_quantity": (
        "serving size", "per serve", "per 100 g", "per 100 ml",
        # Date lines carry numbers and previously won the fallback race.
        "manufactured", "mfg", "packed on", "expiry", "best before",
        "use by", "batch", "model",
    ),
}


def _disqualified(field_id: str, line_text: str) -> bool:
    low = (line_text or "").lower()
    return any(p in low for p in _NEGATIVE_CONTEXT.get(field_id, ()))