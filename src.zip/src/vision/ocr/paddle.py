"""
PaddleOCR backend - the only real OCR engine in this project.

Written against paddleocr 3.7 / paddlex 3.x. Every setting below was
checked against the installed library source, not assumed; the reasons
are recorded next to each one because several defaults are actively
wrong for photographed packaging.

WHAT THIS CHANGES FROM A PLAIN `PaddleOCR(lang="en").predict(img)`
-------------------------------------------------------------------
1. Document preprocessing is OFF.
   PaddleOCR 3.x runs a document orientation classifier and the UVDoc
   unwarping model by default (paddlex/configs/pipelines/OCR.yaml:
   use_doc_orientation_classify: True, use_doc_unwarping: True).
   Detection and cropping then run on the PREPROCESSED image
   (paddlex .../ocr/pipeline.py feeds `doc_preprocessor_images` to the
   detector), so every returned polygon is in the coordinates of a
   rotated / warped copy - not of the image we passed in. Everything
   downstream here measures pixels at those coordinates: glyph height,
   clear space, panel placement, evidence crops. With unwarping on they
   point at the wrong pixels, which is exactly the signature of the
   impossible glyph ratios (0.07, 3.56) seen on real photos. UVDoc is
   also a heavy model, and a large share of per-photo runtime. Geometry
   is this pipeline's job (ArUco rectification), not Paddle's.

2. Detection upscales small inputs.
   The pipeline default is limit_type="min", limit_side_len=64, which
   never enlarges anything. A 1600x954 phone crop keeps 1.5 mm consumer
   care text at a handful of pixels, and small print is missed or
   merged. Raising limit_side_len makes Paddle scale the DETECTION input
   up (max_side_limit=4000 still caps it). Recognition crops still come
   from our image, so coordinates are unaffected.

3. Low-resolution inputs are upscaled on the READ path only.
   Recognition crops are cut from the image we pass in, so a tiny image
   gives the recogniser tiny crops. Below `upscale_short_side_below` the
   image is Lanczos-upscaled for OCR and every polygon is divided back
   to input coordinates. Measurement never sees the upscaled pixels.

4. Weak lines get a second look.
   Regions scoring below `refine_below_score` are re-cropped with extra
   margin (descenders survive: a clipped "g" is how "6 g" becomes "69"),
   upscaled, contrast-normalised, and re-recognised. The higher-scoring
   read wins. Bounded by `refine_max_regions` so runtime stays flat.

5. Bilingual labels.
   lang="hi" does not load the strong model: it resolves to
   devanagari_PP-OCRv5_mobile_rec, while lang="en" gets
   PP-OCRv6_medium_rec. Running Hindi-only therefore reads the English
   half of every bilingual label with a weaker model. Instead, detection
   and recognition run once in English, and each region is re-read by
   the Devanagari recogniser; the Devanagari read replaces the English
   one only where it actually contains Devanagari script.

6. Vertical text is flagged, not merged.
   Paddle already rotates tall crops before recognition, so inkjet date
   codes printed at 90 degrees are often read correctly. But their boxes
   are tall and narrow, and a row-based line grouper then splices them
   into whatever horizontal line shares their centre. Spans are marked
   `vertical=True` so extraction keeps them on a line of their own.

7. Vertical inkjet bands are re-read rotated.
   A batch code printed at 90 degrees ("60702814YA 04:52 - MAR/26-
   NOV/26-D" down the edge of a real Maggi sachet) comes out of detection
   as a column of tiny fragments that the recogniser reads as 5, 寸,
   ON, 心, M - the manufacture date is lost. A narrow column of such
   fragments is cropped as one band, rotated both ways, and read again as
   a whole; the rotation with the better read replaces the fragments.

8. Chinese glyphs are dropped.
   PP-OCRv6's recogniser is Chinese/English; on Indian packs it turns
   smudges and bar-code edges into 印, 心, 出. They are never real text
   here, so they are removed (a region left empty is skipped).

9. Results are cached on disk.
   Keyed by the exact pixels passed in plus the full config, so
   re-running a photo after an extraction or rules change skips the
   model entirely - model load and inference are the slow part, and
   they no longer repeat while iterating on anything downstream.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional

import cv2
import numpy as np

from ...core.schema import BBox, TextSpan
from .base import OCRBackend

logger = logging.getLogger(__name__)

_PROJECT_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_CACHE_DIR = _PROJECT_ROOT / "data" / ".ocr_cache"
DEFAULT_DUMP_DIR = _PROJECT_ROOT / "data" / "ocr_dumps"

_DEVANAGARI = re.compile(r"[ऀ-ॿ]")
_CJK = re.compile(r"[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uac00-\ud7af\uf900-\ufaff]")


def _visible(text: str) -> str:
    """Region text with CJK noise removed and whitespace tidied."""
    return re.sub(r"\s+", " ", _CJK.sub("", text or "")).strip()

# Loaded models are shared across backend instances in one process. A
# fresh CompliancePipeline() per test or per stability run would
# otherwise reload several hundred MB of weights each time.
_PIPELINE_CACHE: dict[str, object] = {}
_RECOGNISER_CACHE: dict[str, object] = {}


@dataclass(frozen=True)
class PaddleConfig:
    lang: str = "en"
    ocr_version: Optional[str] = None          # None -> library default
    device: Optional[str] = None               # "cpu", "gpu:0", ... None -> auto
    use_textline_orientation: bool = True      # fixes 180-degree lines
    text_det_limit_type: str = "min"
    text_det_limit_side_len: int = 1280
    text_det_thresh: Optional[float] = None
    text_det_box_thresh: Optional[float] = None
    text_det_unclip_ratio: Optional[float] = None
    upscale_short_side_below: int = 1200
    upscale_factor: float = 2.0
    max_long_side: int = 4000                  # Paddle's own max_side_limit
    refine_below_score: float = 0.80
    refine_max_regions: int = 20
    refine_scale: float = 3.0
    secondary_lang: Optional[str] = None       # "hi" for bilingual labels
    reread_vertical_bands: bool = True         # rotated re-read of inkjet codes
    enable_mkldnn: bool = False                # oneDNN/PIR crash on some CPUs
    cpu_threads: Optional[int] = None

    def key(self) -> str:
        return json.dumps(asdict(self), sort_keys=True)


def _config_from_env(**overrides) -> PaddleConfig:
    """Environment knobs, so the API and scripts can be tuned without edits."""
    env = {}
    if os.environ.get("SIH_OCR_LANG"):
        env["lang"] = os.environ["SIH_OCR_LANG"]
    if os.environ.get("SIH_OCR_SECONDARY_LANG"):
        env["secondary_lang"] = os.environ["SIH_OCR_SECONDARY_LANG"]
    if os.environ.get("SIH_OCR_DEVICE"):
        env["device"] = os.environ["SIH_OCR_DEVICE"]
    env.update({k: v for k, v in overrides.items() if v is not None})
    return PaddleConfig(**env)


class PaddleOCRBackend(OCRBackend):
    name = "paddleocr"
    supports_languages = ("en", "hi")

    def __init__(
        self,
        config: Optional[PaddleConfig] = None,
        lang: Optional[str] = None,
        cache_dir: Optional[str | Path] = DEFAULT_CACHE_DIR,
        dump_dir: Optional[str | Path] = DEFAULT_DUMP_DIR,
        use_textline_orientation: Optional[bool] = None,
    ):
        overrides = {"lang": lang}
        if use_textline_orientation is not None:
            overrides["use_textline_orientation"] = use_textline_orientation
        self.config = config or _config_from_env(**overrides)
        if os.environ.get("SIH_OCR_CACHE", "1") == "0":
            cache_dir = None
        self.cache_dir = Path(cache_dir) if cache_dir else None
        self.dump_dir = Path(dump_dir) if dump_dir else None
        self._init_error: Optional[str] = None
        # Timings of the most recent call, for scripts that report them.
        self.last_stats: dict = {}
        # For tests: inject a fake with the same .predict() contract.
        self._pipeline_override = None
        self._recogniser_override: dict[str, object] = {}

    # -----------------------------------------------------------------
    # Model loading
    # -----------------------------------------------------------------
    def _pipeline(self):
        if self._pipeline_override is not None:
            return self._pipeline_override
        k = self.config.key()
        if k in _PIPELINE_CACHE:
            return _PIPELINE_CACHE[k]
        from paddleocr import PaddleOCR

        c = self.config
        kwargs = dict(
            lang=c.lang,
            ocr_version=c.ocr_version,
            use_doc_orientation_classify=False,
            use_doc_unwarping=False,
            use_textline_orientation=c.use_textline_orientation,
            text_det_limit_type=c.text_det_limit_type,
            text_det_limit_side_len=c.text_det_limit_side_len,
            text_det_thresh=c.text_det_thresh,
            text_det_box_thresh=c.text_det_box_thresh,
            text_det_unclip_ratio=c.text_det_unclip_ratio,
            text_rec_score_thresh=0.0,
            enable_mkldnn=c.enable_mkldnn,
        )
        if c.device:
            kwargs["device"] = c.device
        if c.cpu_threads:
            kwargs["cpu_threads"] = c.cpu_threads
        kwargs = {k2: v for k2, v in kwargs.items() if v is not None}
        t0 = time.perf_counter()
        pipe = PaddleOCR(**kwargs)
        self.last_stats["model_load_s"] = round(time.perf_counter() - t0, 2)
        _PIPELINE_CACHE[k] = pipe
        return pipe

    def _rec_model_name(self, lang: str) -> str:
        """The recogniser PaddleOCR itself would pick for `lang`."""
        try:
            from paddleocr._pipelines.ocr import PaddleOCR

            _, rec = PaddleOCR._get_ocr_model_names(
                None, lang, self.config.ocr_version if lang == self.config.lang else None
            )
            if rec:
                return rec
        except Exception:
            pass
        return {"en": "PP-OCRv6_medium_rec",
                "hi": "devanagari_PP-OCRv5_mobile_rec"}.get(lang, "PP-OCRv6_medium_rec")

    def _recogniser(self, lang: str):
        if lang in self._recogniser_override:
            return self._recogniser_override[lang]
        name = self._rec_model_name(lang)
        k = f"{name}|{self.config.device}|{self.config.enable_mkldnn}"
        if k in _RECOGNISER_CACHE:
            return _RECOGNISER_CACHE[k]
        from paddleocr import TextRecognition

        kwargs = {"model_name": name, "enable_mkldnn": self.config.enable_mkldnn}
        if self.config.device:
            kwargs["device"] = self.config.device
        rec = TextRecognition(**kwargs)
        _RECOGNISER_CACHE[k] = rec
        return rec

    def available(self) -> bool:
        if self._pipeline_override is not None:
            return True
        if self._init_error is not None:
            return False
        try:
            import paddleocr  # noqa: F401
            return True
        except Exception as exc:  # pragma: no cover - environment
            self._init_error = str(exc)
            return False

    def warm_up(self) -> None:
        """Load models now rather than on the first scan."""
        self._pipeline()

    # -----------------------------------------------------------------
    # Recognition
    # -----------------------------------------------------------------
    def recognise(self, image: np.ndarray, source: Optional[str] = None) -> list[TextSpan]:
        stats: dict = {"cache_hit": False}
        self.last_stats = stats
        t_start = time.perf_counter()

        cache_key = self._cache_key(image)
        cached = self._cache_read(cache_key)
        if cached is not None:
            stats["cache_hit"] = True
            regions = cached
        else:
            regions = self._run(image, stats)
            self._cache_write(cache_key, regions)

        spans = [self._to_span(r) for r in regions if _visible(r["text"])]
        stats["regions"] = len(spans)
        stats["total_s"] = round(time.perf_counter() - t_start, 2)
        if source and self.dump_dir is not None:
            self._dump(source, image, regions, stats)
        return spans

    def _run(self, image: np.ndarray, stats: dict) -> list[dict]:
        c = self.config
        ocr_img, scale = self._ocr_input(image)
        stats["ocr_scale"] = scale

        t0 = time.perf_counter()
        results = self._pipeline().predict(ocr_img)
        stats["predict_s"] = round(time.perf_counter() - t0, 2)

        regions: list[dict] = []
        for res in results or []:
            try:
                texts, scores, polys = res["rec_texts"], res["rec_scores"], res["rec_polys"]
            except (KeyError, TypeError):
                continue
            for text, score, poly in zip(texts, scores, polys):
                pts = np.asarray(poly, dtype=np.float32).reshape(-1, 2)
                if pts.shape[0] < 4:
                    continue
                regions.append({
                    "text": str(text),
                    "score": float(score),
                    "poly_ocr": pts.tolist(),          # in ocr_img coords
                    "poly": (pts / scale).tolist(),    # in input coords
                    "engine": "paddleocr",
                    "language": "hi" if _DEVANAGARI.search(str(text)) else "en",
                })

        if c.reread_vertical_bands and regions:
            t0 = time.perf_counter()
            regions, stats["vertical_bands"] = self._vertical_bands(ocr_img, regions, scale)
            stats["vertical_s"] = round(time.perf_counter() - t0, 2)

        if c.refine_below_score and regions:
            t0 = time.perf_counter()
            stats["refined"] = self._refine(ocr_img, regions)
            stats["refine_s"] = round(time.perf_counter() - t0, 2)

        if c.secondary_lang and regions:
            t0 = time.perf_counter()
            stats["secondary_replaced"] = self._secondary(ocr_img, regions)
            stats["secondary_s"] = round(time.perf_counter() - t0, 2)

        for r in regions:
            r.pop("poly_ocr", None)
        return regions

    def _ocr_input(self, image: np.ndarray) -> tuple[np.ndarray, float]:
        c = self.config
        h, w = image.shape[:2]
        if not c.upscale_short_side_below or min(h, w) >= c.upscale_short_side_below:
            return image, 1.0
        scale = min(c.upscale_factor, c.max_long_side / float(max(h, w)))
        if scale <= 1.01:
            return image, 1.0
        up = cv2.resize(image, (int(round(w * scale)), int(round(h * scale))),
                        interpolation=cv2.INTER_LANCZOS4)
        return up, scale

    # -- second look at weak regions ----------------------------------
    def _refine(self, ocr_img: np.ndarray, regions: list[dict]) -> int:
        c = self.config
        weak = sorted(
            (i for i, r in enumerate(regions) if r["score"] < c.refine_below_score),
            key=lambda i: regions[i]["score"],
        )[: c.refine_max_regions]
        if not weak:
            return 0

        crops, owners = [], []
        for i in weak:
            base = crop_region(ocr_img, np.asarray(regions[i]["poly_ocr"]), pad_ratio=0.25)
            if base is None:
                continue
            up = cv2.resize(base, None, fx=c.refine_scale, fy=c.refine_scale,
                            interpolation=cv2.INTER_CUBIC)
            crops.append(up)
            owners.append(i)
            crops.append(_clahe(up))
            owners.append(i)
        if not crops:
            return 0

        try:
            outs = list(self._recogniser(c.lang).predict(crops))
        except Exception:
            logger.warning("Refinement recognition failed", exc_info=True)
            return 0

        best: dict[int, tuple[str, float]] = {}
        for i, out in zip(owners, outs):
            text, score = _rec_output(out)
            if text and score > best.get(i, ("", -1.0))[1]:
                best[i] = (text, score)

        replaced = 0
        for i, (text, score) in best.items():
            # A margin, so a coin-flip between two equally weak reads
            # does not churn the output from run to run. And the new read
            # must not LOSE the line: on a real sachet a 0.75 read of
            # "Aniseed, Black pepper, Fenugreek, Ginger, Clove," was
            # "improved" to "A" at 0.95. A read that keeps under 60% of
            # the characters is a different (smaller) crop, not a better
            # read of the same line.
            old_len = len(_visible(regions[i]["text"]))
            new_len = len(_visible(text))
            if new_len == 0 or (regions[i]["score"] >= 0.5 and new_len < 0.6 * old_len):
                continue
            if score >= regions[i]["score"] + 0.05:
                regions[i]["alt_text"] = regions[i]["text"]
                regions[i]["alt_score"] = regions[i]["score"]
                regions[i]["text"], regions[i]["score"] = text, score
                regions[i]["engine"] = "paddleocr(refined)"
                replaced += 1
        return replaced

    # -- rotated re-read of vertical inkjet bands ----------------------
    def _vertical_bands(self, ocr_img: np.ndarray, regions: list[dict], scale: float):
        H, W = ocr_img.shape[:2]
        boxes = []
        for i, r in enumerate(regions):
            pts = np.asarray(r["poly_ocr"], dtype=np.float32).reshape(-1, 2)
            x0, y0 = float(pts[:, 0].min()), float(pts[:, 1].min())
            x1, y1 = float(pts[:, 0].max()), float(pts[:, 1].max())
            vis = _visible(r["text"])
            suspect = (vis != r["text"].strip() or len(vis) <= 3 or r["score"] < 0.7
                       or (y1 - y0) >= 1.5 * max(1.0, x1 - x0))
            boxes.append((i, x0, y0, x1, y1, suspect))

        # Columns of suspect fragments that overlap horizontally.
        sus = sorted((b for b in boxes if b[5]), key=lambda b: (b[1] + b[3]) / 2)
        clusters: list[list[tuple]] = []
        for b in sus:
            for cl in clusters:
                cx0 = min(c[1] for c in cl); cx1 = max(c[3] for c in cl)
                if min(cx1, b[3]) - max(cx0, b[1]) > 0.3 * min(cx1 - cx0, b[3] - b[1]):
                    cl.append(b)
                    break
            else:
                clusters.append([b])

        replaced_bands = 0
        drop: set[int] = set()
        added: list[dict] = []
        for cl in clusters:
            if len(cl) < 3:
                continue
            x0 = min(c[1] for c in cl); x1 = max(c[3] for c in cl)
            y0 = min(c[2] for c in cl); y1 = max(c[4] for c in cl)
            bw, bh = x1 - x0, y1 - y0
            if bh < 3 * bw or bw > 0.15 * W:
                continue
            pad = int(0.25 * bw) + 4
            X0, Y0 = max(0, int(x0) - pad), max(0, int(y0) - pad)
            X1, Y1 = min(W, int(x1) + pad), min(H, int(y1) + pad)
            crop = ocr_img[Y0:Y1, X0:X1]
            ch, cw = crop.shape[:2]
            if ch < 8 or cw < 8:
                continue
            old_q = sum(regions[c[0]]["score"] * len(_visible(regions[c[0]]["text"]))
                        for c in cl)
            best = None
            for rot in (cv2.ROTATE_90_CLOCKWISE, cv2.ROTATE_90_COUNTERCLOCKWISE):
                rimg = np.ascontiguousarray(cv2.rotate(crop, rot))
                try:
                    res = self._pipeline().predict(rimg)
                except Exception:
                    logger.warning("Rotated re-read failed", exc_info=True)
                    continue
                reads = []
                for out in res or []:
                    try:
                        items = zip(out["rec_texts"], out["rec_scores"], out["rec_polys"])
                    except (KeyError, TypeError):
                        continue
                    for text, score, poly in items:
                        vis = _visible(str(text))
                        if not vis:
                            continue
                        pts = np.asarray(poly, dtype=np.float32).reshape(-1, 2)
                        if rot == cv2.ROTATE_90_CLOCKWISE:
                            # rotated (x', y') came from crop (y', ch-1-x')
                            back = np.stack([pts[:, 1], (ch - 1) - pts[:, 0]], axis=1)
                        else:
                            # rotated (x', y') came from crop (cw-1-y', x')
                            back = np.stack([(cw - 1) - pts[:, 1], pts[:, 0]], axis=1)
                        back = back + np.float32([X0, Y0])
                        reads.append((vis, float(score), back))
                q = sum(sc * len(t) for t, sc, _ in reads)
                if reads and (best is None or q > best[0]):
                    best = (q, reads)
            if best is None or best[0] <= 1.2 * old_q:
                continue
            if max(len(t) for t, _, _ in best[1]) < 5:
                continue
            drop.update(c[0] for c in cl)
            for text, score, back in best[1]:
                added.append({
                    "text": text,
                    "score": score,
                    "poly_ocr": back.tolist(),
                    "poly": (back / scale).tolist(),
                    "engine": "paddleocr(rotated)",
                    "language": "en",
                })
            replaced_bands += 1

        if not replaced_bands:
            return regions, 0
        return [r for i, r in enumerate(regions) if i not in drop] + added, replaced_bands

    # -- Devanagari re-read -------------------------------------------
    def _secondary(self, ocr_img: np.ndarray, regions: list[dict]) -> int:
        lang = self.config.secondary_lang
        crops, owners = [], []
        for i, r in enumerate(regions):
            crop = crop_region(ocr_img, np.asarray(r["poly_ocr"]), pad_ratio=0.08)
            if crop is not None:
                crops.append(crop)
                owners.append(i)
        if not crops:
            return 0
        try:
            outs = list(self._recogniser(lang).predict(crops))
        except Exception:
            logger.warning("Secondary-language recognition failed", exc_info=True)
            return 0

        replaced = 0
        for i, out in zip(owners, outs):
            text, score = _rec_output(out)
            if prefer_devanagari(regions[i]["text"], regions[i]["score"], text, score):
                regions[i]["alt_text"] = regions[i]["text"]
                regions[i]["alt_score"] = regions[i]["score"]
                regions[i]["text"], regions[i]["score"] = text, score
                regions[i]["engine"] = f"paddleocr({lang})"
                regions[i]["language"] = "hi"
                replaced += 1
        return replaced

    # -----------------------------------------------------------------
    @staticmethod
    def _to_span(r: dict) -> TextSpan:
        pts = np.asarray(r["poly"], dtype=np.float32)
        x, y = float(pts[:, 0].min()), float(pts[:, 1].min())
        x2, y2 = float(pts[:, 0].max()), float(pts[:, 1].max())
        return TextSpan(
            text=_visible(r["text"]),
            bbox=BBox(x, y, x2 - x, y2 - y),
            confidence=float(r["score"]),
            source_engine=r.get("engine", "paddleocr"),
            language=r.get("language", "en"),
            vertical=is_vertical(pts, _visible(r["text"])),
        )

    # -- cache and dumps ----------------------------------------------
    def _cache_key(self, image: np.ndarray) -> str:
        try:
            import paddleocr
            ver = getattr(paddleocr, "__version__", "?")
        except Exception:
            ver = "?"
        h = hashlib.sha1()
        h.update(np.ascontiguousarray(image).tobytes())
        h.update(str(image.shape).encode())
        h.update(self.config.key().encode())
        h.update(ver.encode())
        return h.hexdigest()

    def _cache_read(self, key: str) -> Optional[list[dict]]:
        if self.cache_dir is None or self._pipeline_override is not None:
            return None
        p = self.cache_dir / f"{key}.json"
        if not p.exists():
            return None
        try:
            return json.loads(p.read_text())["regions"]
        except Exception:
            return None

    def _cache_write(self, key: str, regions: list[dict]) -> None:
        if self.cache_dir is None or self._pipeline_override is not None:
            return
        try:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
            (self.cache_dir / f"{key}.json").write_text(
                json.dumps({"config": asdict(self.config), "regions": regions})
            )
        except Exception:
            logger.warning("Could not write OCR cache", exc_info=True)

    def _dump(self, source: str, image: np.ndarray, regions: list[dict], stats: dict) -> None:
        """
        A readable copy of exactly what Paddle read, named after the photo.

        This is what to send when a report looks wrong: it separates
        "Paddle misread the label" from "extraction or rules got it
        wrong", and `scripts/scan_photo.py --replay` re-runs everything
        downstream of OCR from it without loading a model.
        """
        try:
            self.dump_dir.mkdir(parents=True, exist_ok=True)
            out = self.dump_dir / f"{Path(source).stem}.paddle.json"
            out.write_text(json.dumps({
                "source": str(source),
                "ocr_input_shape": list(image.shape),
                "config": asdict(self.config),
                "stats": stats,
                "regions": regions,
            }, indent=1, ensure_ascii=False))
            stats["dump"] = str(out)
        except Exception:
            logger.warning("Could not write OCR dump", exc_info=True)


# =====================================================================
# Replay: run everything downstream of OCR from a saved Paddle dump
# =====================================================================

class ReplayOCR(OCRBackend):
    """
    Returns the regions saved in a `.paddle.json` dump instead of running
    a model. Lets extraction and rules be debugged against real Paddle
    output on a machine with no Paddle models at all, in milliseconds.
    """

    name = "paddleocr(replay)"
    supports_languages = ("en", "hi")

    def __init__(self, dump_path: str | Path):
        self.dump_path = Path(dump_path)
        self.dump = json.loads(self.dump_path.read_text())

    def recognise(self, image: np.ndarray, source: Optional[str] = None) -> list[TextSpan]:
        want = tuple(self.dump.get("ocr_input_shape", ()))[:2]
        if want and tuple(image.shape[:2]) != want:
            logger.warning(
                "Replay dump was taken on a %s image but this run fed OCR a %s "
                "image; boxes may not line up.", want, image.shape[:2],
            )
        spans = []
        for r in self.dump.get("regions", []):
            if _visible(r.get("text", "")):
                span = PaddleOCRBackend._to_span(r)
                span.source_engine = self.name
                spans.append(span)
        return spans


# =====================================================================
# Helpers (pure functions, unit-tested without any model)
# =====================================================================

def is_vertical(pts: np.ndarray, text: str) -> bool:
    """A region whose long side runs top-to-bottom, holding real text."""
    pts = np.asarray(pts, dtype=np.float32).reshape(-1, 2)
    w = float(pts[:, 0].max() - pts[:, 0].min())
    h = float(pts[:, 1].max() - pts[:, 1].min())
    return len(text.strip()) >= 3 and h >= 1.5 * max(w, 1.0)


def crop_region(img: np.ndarray, poly: np.ndarray, pad_ratio: float = 0.15) -> Optional[np.ndarray]:
    """
    Crop a text region the way Paddle does - minimum-area rectangle,
    perspective-corrected, rotated upright when tall - but with margin.

    The margin is the point: Paddle's own crop is tight to the detector
    box, and on small print a tight box shaves descenders and the gap
    between a number and its unit.
    """
    poly = np.asarray(poly, dtype=np.float32).reshape(-1, 2)
    if poly.shape[0] < 4:
        return None
    rect = cv2.minAreaRect(poly)
    (cx, cy), (rw, rh), angle = rect
    if rw < 2 or rh < 2:
        return None
    short = min(rw, rh)
    rect = ((cx, cy), (rw + 2 * pad_ratio * short, rh + 2 * pad_ratio * short), angle)
    box = cv2.boxPoints(rect)
    # Order: top-left, top-right, bottom-right, bottom-left.
    s, d = box.sum(axis=1), np.diff(box, axis=1).ravel()
    tl, br = box[np.argmin(s)], box[np.argmax(s)]
    tr, bl = box[np.argmin(d)], box[np.argmax(d)]
    width = int(max(np.linalg.norm(tr - tl), np.linalg.norm(br - bl)))
    height = int(max(np.linalg.norm(bl - tl), np.linalg.norm(br - tr)))
    if width < 2 or height < 2:
        return None
    M = cv2.getPerspectiveTransform(
        np.float32([tl, tr, br, bl]),
        np.float32([[0, 0], [width, 0], [width, height], [0, height]]),
    )
    crop = cv2.warpPerspective(img, M, (width, height),
                               borderMode=cv2.BORDER_REPLICATE,
                               flags=cv2.INTER_CUBIC)
    if height >= 1.5 * width:
        crop = np.rot90(crop)
    return np.ascontiguousarray(crop)


def _clahe(img: np.ndarray) -> np.ndarray:
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB) if img.ndim == 3 else img
    if img.ndim == 3:
        l, a, b = cv2.split(lab)
        l = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(4, 4)).apply(l)
        return cv2.cvtColor(cv2.merge([l, a, b]), cv2.COLOR_LAB2BGR)
    return cv2.createCLAHE(clipLimit=2.0, tileGridSize=(4, 4)).apply(img)


def _rec_output(out) -> tuple[str, float]:
    """TextRecognition.predict yields dict-likes with rec_text/rec_score."""
    try:
        return str(out["rec_text"]).strip(), float(out["rec_score"])
    except (KeyError, TypeError, ValueError):
        return "", 0.0


def prefer_devanagari(en_text: str, en_score: float, hi_text: str, hi_score: float) -> bool:
    """
    Take the Devanagari read only where the region really is Devanagari.

    The Devanagari model also emits Latin letters, so a region reading
    "MRP" in both models must stay with the stronger English read. The
    swap needs the Devanagari output to be mostly Devanagari script and
    to be at least roughly as confident.
    """
    if not hi_text:
        return False
    letters = [ch for ch in hi_text if not ch.isspace() and not ch.isdigit()]
    if not letters:
        return False
    dev_ratio = sum(1 for ch in letters if _DEVANAGARI.match(ch)) / len(letters)
    if dev_ratio < 0.5 or sum(1 for ch in letters if _DEVANAGARI.match(ch)) < 2:
        return False
    return hi_score >= en_score - 0.10 or hi_score >= 0.80
