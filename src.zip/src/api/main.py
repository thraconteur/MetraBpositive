"""
FastAPI service layer.

Covers the PS functional requirements that are plain software rather
than ML: image upload, scan history, the product repository, role-based
access, the dashboard aggregation, search, and report export.

SCOPE NOTE
----------
Auth here is a demonstration of the ROLE MODEL, not production security.
Tokens are static strings in a dict. Before this is deployed anywhere
real you need proper user storage, password hashing, expiring JWTs and
HTTPS. It is written this way deliberately so the role logic is readable
in one screen; do not ship it as-is and do not claim it is secure.

THE ROLE MODEL IS THE POINT
---------------------------
An inspector can scan and can propose a finding. Only a supervisor can
CONFIRM or OVERRIDE one, and every such action is recorded with who did
it and when. That separation is what makes the output usable in an
enforcement context: the machine never has the last word, a named human
does.
"""

from __future__ import annotations

import os
import json
import sqlite3
import tempfile
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import cv2
import numpy as np
from fastapi import Depends, FastAPI, File, Header, HTTPException, Query, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel

from ..core.pipeline import CompliancePipeline
from ..core.rules_engine import RuleConfig
from ..core.schema import ScanResult

DB_PATH = Path("data/compliance.db")


# =====================================================================
# Roles
# =====================================================================

ROLES = {
    "inspector": {"scan", "read"},
    "supervisor": {"scan", "read", "confirm", "override"},
    "admin": {"scan", "read", "confirm", "override", "manage", "audit"},
}

# DEMO ONLY. Replace with real user storage.
TOKENS = {
    "demo-inspector": ("insp-001", "inspector"),
    "demo-supervisor": ("supv-001", "supervisor"),
    "demo-admin": ("admin-001", "admin"),
}


class User(BaseModel):
    user_id: str
    role: str

    def can(self, action: str) -> bool:
        return action in ROLES.get(self.role, set())


def current_user(authorization: Optional[str] = Header(None)) -> User:
    token = (authorization or "").replace("Bearer ", "").strip()
    if token not in TOKENS:
        raise HTTPException(401, "Invalid or missing token.")
    uid, role = TOKENS[token]
    return User(user_id=uid, role=role)


def require(action: str):
    def dep(user: User = Depends(current_user)) -> User:
        if not user.can(action):
            raise HTTPException(
                403, f"Role '{user.role}' is not permitted to '{action}'."
            )
        return user
    return dep


# =====================================================================
# Storage
# =====================================================================

SCHEMA = """
CREATE TABLE IF NOT EXISTS scans (
    scan_id      TEXT PRIMARY KEY,
    created_at   TEXT NOT NULL,
    inspector_id TEXT,
    image_path   TEXT,
    product_name TEXT,
    category     TEXT,
    verdict      TEXT,           -- compliant / non_compliant / indeterminate
    n_violations INTEGER DEFAULT 0,
    payload      TEXT NOT NULL   -- full ScanResult as JSON
);
CREATE TABLE IF NOT EXISTS findings (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id    TEXT NOT NULL,
    rule_id    TEXT NOT NULL,
    citation   TEXT,
    outcome    TEXT,
    severity   TEXT,
    message    TEXT,
    FOREIGN KEY (scan_id) REFERENCES scans(scan_id)
);
-- Every human decision on a machine finding, kept forever.
CREATE TABLE IF NOT EXISTS actions (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id    TEXT NOT NULL,
    rule_id    TEXT NOT NULL,
    action     TEXT NOT NULL,   -- confirmed / overridden
    user_id    TEXT NOT NULL,
    note       TEXT,
    at         TEXT NOT NULL
);
-- Rule 33 relaxations are package-specific and time-bound, so they
-- live here rather than in the rules YAML.
CREATE TABLE IF NOT EXISTS relaxations (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    manufacturer TEXT NOT NULL,
    rule_id      TEXT NOT NULL,
    reference    TEXT,
    valid_until  TEXT
);
CREATE INDEX IF NOT EXISTS idx_scans_created ON scans(created_at);
CREATE INDEX IF NOT EXISTS idx_findings_scan ON findings(scan_id);
"""


_schema_ready = False


def db():
    """
    Open a connection, creating the schema on first use.

    Schema creation is done here rather than only in a startup hook
    because the hook does not run in every context that touches the
    database - test clients, one-off scripts and worker processes all
    import this module and call db() directly. Relying on the hook alone
    produced "no such table" the first time the API was exercised
    outside a full server boot.
    """
    global _schema_ready
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    if not _schema_ready:
        conn.executescript(SCHEMA)
        conn.commit()
        _schema_ready = True
    return conn


def init_db():
    with closing(db()) as conn:
        conn.commit()


def verdict_of(res: ScanResult) -> str:
    c = res.is_compliant
    return "compliant" if c is True else "non_compliant" if c is False else "indeterminate"


def persist(res: ScanResult, product_name: str = "") -> None:
    with closing(db()) as conn:
        conn.execute(
            "INSERT OR REPLACE INTO scans (scan_id, created_at, inspector_id, "
            "image_path, product_name, category, verdict, n_violations, payload) "
            "VALUES (?,?,?,?,?,?,?,?,?)",
            (
                res.scan_id, res.created_at, res.inspector_id, res.image_path,
                product_name or (res.declaration("common_name").raw_text
                                 if res.declaration("common_name") else ""),
                res.context.commodity_category, verdict_of(res),
                len(res.violations), json.dumps(res.to_dict()),
            ),
        )
        for f in res.findings:
            conn.execute(
                "INSERT INTO findings (scan_id, rule_id, citation, outcome, "
                "severity, message) VALUES (?,?,?,?,?,?)",
                (res.scan_id, f.rule_id, f.citation, f.outcome.value,
                 f.severity.value, f.message),
            )
        conn.commit()


# =====================================================================
# App
# =====================================================================

app = FastAPI(
    title="LMPC Compliance Checker",
    description=(
        "Legal Metrology (Packaged Commodities) Rules, 2011 compliance "
        "checking. Reference implementation - see README for scope limits. "
        "Mobile-app integration: docs/app_integration.md."
    ),
    version="0.3.0-scaffold",
)

# The inspector app calls this API from a phone (native) or a browser
# (web build / Expo web). Browsers need CORS; native apps ignore it.
# SIH_CORS_ORIGINS="https://app.example,http://localhost:8081" to lock down.
from fastapi.middleware.cors import CORSMiddleware  # noqa: E402

app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in os.environ.get("SIH_CORS_ORIGINS", "*").split(",")],
    allow_methods=["*"],
    allow_headers=["*"],
)

_pipeline: Optional[CompliancePipeline] = None
# One scan at a time through the shared OCR engine: PaddleOCR's predictor
# is not safe to call from two threads at once. Other requests (history,
# reports) keep being served while a scan runs.
import threading  # noqa: E402

_scan_lock = threading.Lock()


def relaxation_lookup(manufacturer: str, rule_id: str) -> Optional[dict]:
    """
    Rule 33 relaxations, matched by manufacturer and rule.

    Matched on a substring of the extracted manufacturer text rather
    than equality: the stored name is typed by an official, while the
    scanned one comes from OCR of a real package, so they will rarely
    be byte-identical.
    """
    with closing(db()) as conn:
        rows = conn.execute(
            "SELECT manufacturer, reference, valid_until FROM relaxations "
            "WHERE rule_id = ?", (rule_id,)
        ).fetchall()
    hay = (manufacturer or "").lower()
    for r in rows:
        name = (r["manufacturer"] or "").lower().strip()
        if name and name in hay:
            if r["valid_until"]:
                # An expired relaxation is not a relaxation.
                if str(r["valid_until"]) < datetime.now(timezone.utc).date().isoformat():
                    continue
            return dict(r)
    return None


def pipeline() -> CompliancePipeline:
    global _pipeline
    if _pipeline is None:
        from ..core.rules_engine import RulesEngine

        vlm = None
        if os.environ.get("SIH_VLM", "").lower() == "gemini":
            from ..vision.ocr.vlm_gemini import GeminiReader

            vlm = GeminiReader()
            vlm.check()        # fail at startup with the exact fix, not per request
        _pipeline = CompliancePipeline(
            engine=RulesEngine(relaxation_lookup=relaxation_lookup), vlm=vlm,
        )
    return _pipeline


@app.on_event("startup")
def _startup():          # kept for real server boots; db() self-heals anyway
    init_db()
    # Load the OCR models in the background, so the FIRST scan from the
    # app does not sit for a minute and hit the phone's request timeout.
    if (os.environ.get("SIH_OCR_BACKEND", "paddle") == "paddle"
            and os.environ.get("SIH_WARMUP", "1") != "0"):
        def _warm():
            try:
                warm = getattr(pipeline().ocr, "warm_up", None)
                if warm:
                    warm()
            except Exception:
                pass
        threading.Thread(target=_warm, daemon=True).start()


@app.get("/health")
def health():
    audit = RuleConfig().audit()
    return {
        "status": "ok",
        "rules_verified": len(audit["verified"]),
        "rules_unverified": len(audit["unverified"]),
        "coverage": round(audit["coverage"], 3),
        "ocr_backend": os.environ.get("SIH_OCR_BACKEND", "paddle"),
    }


@app.get("/rules/audit")
def rules_audit(user: User = Depends(require("read"))):
    """
    Which rules are backed by verified gazette values and which are
    still placeholders. Expose this rather than hiding it: a tool that
    is honest about its coverage is far more credible than one that
    implies it checks everything.
    """
    return RuleConfig().audit()


@app.post("/scan")
async def scan(
    file: UploadFile = File(...),
    product_name: str = Query(""),
    panel_width_mm: Optional[float] = Query(None, gt=0, description=(
        "Real panel width in mm (ruler), for mm checks when no marker is in frame")),
    panel_height_mm: Optional[float] = Query(None, gt=0),
    coverage_complete: bool = Query(False, description=(
        "The photos of this pack cover every panel: absence becomes a violation")),
    user: User = Depends(require("scan")),
):
    raw = await file.read()
    if not raw:
        # cv2.imdecode raises on an empty buffer rather than returning
        # None, so the `arr is None` guard below never saw it and an
        # empty upload surfaced as a 500 with an OpenCV stack trace.
        raise HTTPException(400, "Uploaded file is empty.")

    MAX_BYTES = 25 * 1024 * 1024
    if len(raw) > MAX_BYTES:
        raise HTTPException(
            413, f"Image exceeds the {MAX_BYTES // (1024 * 1024)} MB limit."
        )

    try:
        arr = cv2.imdecode(np.frombuffer(raw, np.uint8), cv2.IMREAD_COLOR)
    except cv2.error:
        arr = None
    if arr is None:
        raise HTTPException(400, "Could not decode image.")

    from fastapi.concurrency import run_in_threadpool

    panel = (panel_width_mm, panel_height_mm or 0.0) if panel_width_mm else None

    def _run(path: str) -> ScanResult:
        with _scan_lock:
            r = pipeline().scan(path, inspector_id=user.user_id, panel_size_mm=panel)
            if coverage_complete:
                r.coverage_complete = True
                r.findings = []
                pipeline().engine.evaluate(r)
            return r

    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as fh:
        cv2.imwrite(fh.name, arr)
        res = await run_in_threadpool(_run, fh.name)

    # Cropped evidence per finding. The problem statement asks for
    # "attachment of photographs and supporting evidence", and every
    # finding already carried a bounding box - but nothing ever called
    # the crop extractor, so no report ever contained a single evidence
    # image. A violation report that cites a rule and shows nothing is
    # not evidence an inspector can act on.
    from ..report.builder import extract_evidence_crops

    try:
        crop_dir = Path("data/evidence") / res.scan_id
        extract_evidence_crops(res, crop_dir)
    except Exception:
        # Evidence generation must never fail the scan itself.
        pass

    persist(res, product_name)
    payload = res.to_dict()
    payload["app"] = app_summary(payload, product_name)
    return JSONResponse(payload)


# =====================================================================
# Mobile app view
# =====================================================================

_SEV_ORDER = {"CRITICAL": 0, "MAJOR": 1, "MINOR": 2}
_OUT_ORDER = {"VIOLATION": 0, "INDETERMINATE": 1, "UNVERIFIED_RULE": 2,
              "COMPLIANT": 3, "NOT_APPLICABLE": 4, "SUPPRESSED": 5}


def app_summary(payload: dict, product_name: str = "") -> dict:
    """
    What the inspector app's screens need, in one flat object.

    Counts are plain counts, not a score: the scan page shows "3 critical,
    4 major" and the officer knows exactly what that means. A "3/10
    compliance rating" would need a definition someone can defend in a
    hearing - if the app wants one, show `checks` (passed of assessed).
    """
    findings = payload.get("findings") or []
    decls = payload.get("declarations") or []
    sid = payload.get("scan_id", "")
    viol = [f for f in findings if f.get("outcome") == "VIOLATION"]
    sev = {"CRITICAL": 0, "MAJOR": 0, "MINOR": 0}
    for f in viol:
        k = str(f.get("severity", "MINOR")).upper()
        sev[k] = sev.get(k, 0) + 1
    to_confirm = [f for f in findings if f.get("outcome") == "INDETERMINATE"]
    passed = [f for f in findings if f.get("outcome") == "COMPLIANT"]
    c = (payload.get("summary") or {}).get("compliant")
    # "undecided" = the system abstained (unreadable, or not every panel
    # seen). The app should show it as "needs another photo", not a pass.
    verdict = "compliant" if c is True else "non_compliant" if c is False else "undecided"
    common = next((d for d in decls if d.get("field_id") == "common_name" and d.get("present")), None)
    cal = payload.get("calibration") or {}

    def ev_url(f):
        p = f.get("evidence_crop_path")
        return f"/scans/{sid}/evidence/{Path(p).name}" if p else None

    retake = []
    if not payload.get("image_quality_ok", True):
        retake.append(payload.get("quality_notes") or "Image quality too low - retake.")
    for f in to_confirm:
        m = f.get("message", "")
        if "retake" in m.lower() or "closer" in m.lower():
            retake.append(m)

    return {
        "scan_id": sid,
        "created_at": payload.get("created_at"),
        "verdict": verdict,
        "product": {
            "name": product_name or (common or {}).get("raw_text") or "",
            "category": (payload.get("context") or {}).get("commodity_category", ""),
        },
        "counts": {"violations": sev, "to_confirm": len(to_confirm),
                   "passed": len(passed)},
        "checks": {"passed": len(passed), "failed": len(viol),
                   "to_confirm": len(to_confirm)},
        "findings": [
            {
                "rule_id": f.get("rule_id"), "citation": f.get("citation"),
                "outcome": f.get("outcome"), "severity": str(f.get("severity", "")).upper(),
                "field": f.get("field_id"), "message": f.get("message"),
                "measured": f.get("measured_value"), "required": f.get("required_value"),
                "unit": f.get("unit"), "confidence": f.get("confidence"),
                "evidence_url": ev_url(f),
            }
            for f in sorted(findings, key=lambda f: (
                _OUT_ORDER.get(f.get("outcome"), 9),
                _SEV_ORDER.get(str(f.get("severity", "")).upper(), 9)))
            if f.get("outcome") != "NOT_APPLICABLE"
        ],
        "declarations": [
            {"field": d.get("field_id"), "value": d.get("value"), "unit": d.get("unit"),
             "text": d.get("raw_text"), "source": d.get("source", "ocr"),
             "notes": d.get("notes") or []}
            for d in decls if d.get("present")
        ],
        "calibration": {"method": cal.get("method"), "px_per_mm": cal.get("px_per_mm"),
                        "note": cal.get("notes", "")},
        "retake_advice": list(dict.fromkeys(retake))[:3],
        "report_urls": {fmt: f"/scans/{sid}/report?fmt={fmt}"
                        for fmt in ("pdf", "html", "docx")},
    }


@app.get("/scans/{scan_id}/summary")
def scan_summary(scan_id: str, user: User = Depends(require("read"))):
    """The app view of a stored scan (History screen -> detail)."""
    with closing(db()) as conn:
        row = conn.execute("SELECT payload, product_name FROM scans WHERE scan_id = ?",
                           (scan_id,)).fetchone()
    if not row:
        raise HTTPException(404, "No such scan.")
    return app_summary(json.loads(row["payload"]), row["product_name"] or "")


@app.get("/scans/{scan_id}/evidence/{name}")
def evidence_image(scan_id: str, name: str, user: User = Depends(require("read"))):
    """An evidence crop, for the app to show next to its finding."""
    base = (Path("data/evidence") / scan_id).resolve()
    path = (base / name).resolve()
    if base not in path.parents or not path.exists() or path.suffix.lower() != ".png":
        raise HTTPException(404, "No such evidence image.")
    return FileResponse(path, media_type="image/png")


@app.get("/scans")
def list_scans(
    q: str = Query("", description="search product name or category"),
    verdict: str = Query(""),
    limit: int = Query(50, le=500),
    offset: int = Query(0, ge=0),
    user: User = Depends(require("read")),
):
    sql = "SELECT scan_id, created_at, product_name, category, verdict, n_violations FROM scans WHERE 1=1"
    args: list = []
    if q:
        sql += " AND (product_name LIKE ? OR category LIKE ?)"
        args += [f"%{q}%", f"%{q}%"]
    if verdict:
        sql += " AND verdict = ?"
        args.append(verdict)
    sql += " ORDER BY created_at DESC LIMIT ? OFFSET ?"
    args += [limit, offset]
    with closing(db()) as conn:
        return [dict(r) for r in conn.execute(sql, args)]


@app.get("/scans/{scan_id}")
def get_scan(scan_id: str, user: User = Depends(require("read"))):
    with closing(db()) as conn:
        row = conn.execute(
            "SELECT payload FROM scans WHERE scan_id = ?", (scan_id,)
        ).fetchone()
        acts = [dict(r) for r in conn.execute(
            "SELECT rule_id, action, user_id, note, at FROM actions "
            "WHERE scan_id = ? ORDER BY at", (scan_id,))]
    if not row:
        raise HTTPException(404, "No such scan.")
    payload = json.loads(row["payload"])
    payload["human_actions"] = acts
    return payload


class ActionIn(BaseModel):
    rule_id: str
    action: str        # "confirmed" | "overridden"
    note: str = ""


@app.post("/scans/{scan_id}/action")
def record_action(
    scan_id: str,
    body: ActionIn,
    user: User = Depends(require("confirm")),
):
    """
    A named human confirms or overrides a machine finding.

    Overriding requires the 'override' permission specifically, so an
    inspector cannot quietly dismiss a finding their supervisor has not
    seen. Both actions are appended, never updated - the audit trail is
    the product.
    """
    if body.action not in ("confirmed", "overridden"):
        raise HTTPException(400, "action must be 'confirmed' or 'overridden'.")
    if body.action == "overridden" and not user.can("override"):
        raise HTTPException(403, "Overriding a finding requires a supervisor.")
    if body.action == "overridden" and not body.note.strip():
        raise HTTPException(400, "An override must carry a written reason.")

    with closing(db()) as conn:
        if not conn.execute("SELECT 1 FROM scans WHERE scan_id = ?",
                            (scan_id,)).fetchone():
            raise HTTPException(404, "No such scan.")
        conn.execute(
            "INSERT INTO actions (scan_id, rule_id, action, user_id, note, at) "
            "VALUES (?,?,?,?,?,?)",
            (scan_id, body.rule_id, body.action, user.user_id, body.note,
             datetime.now(timezone.utc).isoformat()),
        )
        conn.commit()
    return {"ok": True, "recorded_by": user.user_id}


@app.get("/analysis/dual-mrp")
def dual_mrp(user: User = Depends(require("read"))):
    """
    Rule 18(2A) across the whole repository.

    Every other endpoint judges one image. This one cannot: a package
    showing Rs.120 is compliant on its own and becomes evidence only
    next to an identical one showing Rs.145. It is the reason the
    "repository of scanned products" in the problem statement is an
    evidence base rather than storage.
    """
    from ..core.cross_scan import CrossScanAnalyzer
    from ..report.builder import scan_from_dict

    with closing(db()) as conn:
        rows = conn.execute("SELECT payload FROM scans").fetchall()

    scans = []
    for r in rows:
        try:
            scans.append(scan_from_dict(json.loads(r["payload"])))
        except Exception:
            continue

    findings = CrossScanAnalyzer().findings(scans)
    return {
        "scans_compared": len(scans),
        "violations": [f.to_dict() for f in findings],
        "note": (
            "Findings without a barcode rest on brand, name and net quantity "
            "matching. Confirm the packages are genuinely identical before acting."
        ),
    }


class RelaxationIn(BaseModel):
    manufacturer: str
    rule_id: str
    reference: str = ""
    valid_until: str = ""      # ISO date; empty means no recorded expiry


@app.post("/relaxations")
def add_relaxation(
    body: RelaxationIn,
    user: User = Depends(require("manage")),
):
    """
    Record a Rule 33 relaxation granted to a manufacturer.

    Admin-only: a relaxation suppresses violations, so the ability to
    create one is the ability to make findings disappear. It is recorded
    against a specific rule and a validity date, never as a blanket
    exemption for a manufacturer.
    """
    if not body.manufacturer.strip() or not body.rule_id.strip():
        raise HTTPException(400, "manufacturer and rule_id are required.")
    with closing(db()) as conn:
        conn.execute(
            "INSERT INTO relaxations (manufacturer, rule_id, reference, valid_until) "
            "VALUES (?,?,?,?)",
            (body.manufacturer.strip(), body.rule_id.strip(),
             body.reference.strip(), body.valid_until.strip() or None),
        )
        conn.commit()
    return {"ok": True, "recorded_by": user.user_id}


@app.get("/relaxations")
def list_relaxations(user: User = Depends(require("read"))):
    with closing(db()) as conn:
        return [dict(r) for r in conn.execute(
            "SELECT id, manufacturer, rule_id, reference, valid_until FROM relaxations"
        )]


class ListingIn(BaseModel):
    url: str = ""
    title: str = ""
    text: str
    platform: str = ""
    is_imported: bool = False
    has_searchable_coo_filter: bool = False
    has_sortable_coo_filter: bool = False


@app.post("/scan/listing")
def scan_listing(body: ListingIn, user: User = Depends(require("scan"))):
    """
    Rule 6(10) compliance for an e-commerce listing.

    No image, no calibration, no marker card. The same extractor and the
    same rules engine run against listing text, so citations match those
    on a package report for the same rule - but every rule about how a
    declaration is PRINTED is reported NOT_APPLICABLE with a reason,
    because a web page has no panel to measure.
    """
    from ..core.listing import Listing, ListingScanner

    listing = Listing(
        url=body.url, title=body.title, text=body.text,
        platform=body.platform, is_imported=body.is_imported,
        has_searchable_coo_filter=body.has_searchable_coo_filter,
        has_sortable_coo_filter=body.has_sortable_coo_filter,
    )
    res = ListingScanner().scan(listing, inspector_id=user.user_id)
    persist(res, body.title)
    return JSONResponse(res.to_dict())


@app.get("/dashboard")
def dashboard(user: User = Depends(require("read"))):
    with closing(db()) as conn:
        by_verdict = {r["verdict"]: r["n"] for r in conn.execute(
            "SELECT verdict, COUNT(*) n FROM scans GROUP BY verdict")}
        by_rule = [dict(r) for r in conn.execute(
            "SELECT rule_id, citation, COUNT(*) n FROM findings "
            "WHERE outcome='VIOLATION' GROUP BY rule_id ORDER BY n DESC LIMIT 15")]
        by_category = [dict(r) for r in conn.execute(
            "SELECT category, COUNT(*) n FROM scans WHERE verdict='non_compliant' "
            "GROUP BY category ORDER BY n DESC")]
        trend = [dict(r) for r in conn.execute(
            "SELECT substr(created_at,1,10) day, COUNT(*) n, "
            "SUM(CASE WHEN verdict='non_compliant' THEN 1 ELSE 0 END) bad "
            "FROM scans GROUP BY day ORDER BY day DESC LIMIT 30")]
        total = conn.execute("SELECT COUNT(*) n FROM scans").fetchone()["n"]
    return {
        "total_scans": total,
        "by_verdict": by_verdict,
        "top_violated_rules": by_rule,
        "non_compliant_by_category": by_category,
        "trend": trend,
        # Surfaced so nobody reads the dashboard as a complete picture.
        "coverage_note": RuleConfig().audit(),
    }


@app.get("/scans/{scan_id}/report")
def report(
    scan_id: str,
    fmt: str = Query("pdf", pattern="^(pdf|html|json|docx)$"),
    user: User = Depends(require("read")),
):
    from ..report.builder import build_report

    with closing(db()) as conn:
        row = conn.execute("SELECT payload FROM scans WHERE scan_id = ?",
                           (scan_id,)).fetchone()
    if not row:
        raise HTTPException(404, "No such scan.")
    payload = json.loads(row["payload"])

    if fmt == "json":
        return payload

    if fmt == "docx":
        # "Export of reports to PDF and editable formats" is an explicit
        # functional requirement. save_docx existed and was unreachable:
        # the format was never offered by the endpoint.
        from ..report.builder import save_docx, scan_from_dict

        out_dir = Path("data/reports")
        out_dir.mkdir(parents=True, exist_ok=True)
        path = save_docx(scan_from_dict(payload), out_dir / f"{scan_id}.docx")
        if not path:
            raise HTTPException(
                501, "DOCX export unavailable: python-docx is not installed."
            )
        return FileResponse(
            path,
            media_type=(
                "application/vnd.openxmlformats-officedocument."
                "wordprocessingml.document"
            ),
            filename=Path(path).name,
        )

    out_dir = Path("data/reports")
    out_dir.mkdir(parents=True, exist_ok=True)
    path = build_report(payload, out_dir / f"{scan_id}.{fmt}", fmt=fmt)
    return FileResponse(
        path,
        media_type="application/pdf" if fmt == "pdf" else "text/html",
        filename=Path(path).name,
    )
