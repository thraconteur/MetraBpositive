"""
Real photographs, real PaddleOCR output (replayed - no model needed).

tests/fixtures/real holds phone photos of real packs and the OCR a
teammate's PaddleOCR 3.7 produced for them, with ground_truth.yaml saying
what is actually printed. These tests pin the two things that matter most
on real packaging:

  * nothing is read WRONGLY (a wrong value is worse than a missing one),
  * no violation is reported on a pack that is compliant.

The extraction fixes of Sept 2026 were made looking at these photos, so
the reading score here is a regression floor, not an accuracy claim.
"""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))

from real_eval import evaluate_dir  # noqa: E402

FIX = ROOT / "tests" / "fixtures" / "real"


def _rows(variant="default"):
    out = evaluate_dir(FIX, verbose=False)
    return [r for r in out["rows"] if r["variant"] == variant]


def test_real_photos_nothing_read_wrongly():
    rows = _rows()
    assert rows, "no real OCR fixtures found"
    wrong = [w for r in rows for w in r["wrong"]]
    assert wrong == [], wrong


def test_real_photos_no_false_violations():
    fv = [(r["photo"], v) for r in _rows() for v in r["false_violations"]]
    assert fv == [], fv


def test_real_photos_never_call_an_unreadable_declaration_missing():
    fa = [(r["photo"], f) for r in _rows() for f in r["false_absent"]]
    assert fa == [], fa


def test_real_photos_reading_floor():
    rows = _rows()
    correct = sum(len(r["correct"]) for r in rows)
    total = correct + sum(len(r["missed"]) + len(r["wrong"]) for r in rows)
    # 11 of 13 at the time of writing; the misses are OCR (a rotated inkjet
    # date read as fragments, and "per g" read as "perS").
    assert correct >= 11, (correct, total)


def test_hair_serum_is_not_an_alcoholic_beverage():
    """'rum' is inside 'serum': substring matching deferred the MRP rules to
    State excise law for a hair serum."""
    from src.core.pipeline import CompliancePipeline
    from src.vision.ocr.paddle import ReplayOCR

    res = CompliancePipeline(ocr=ReplayOCR(FIX / "photo1.paddle.json")).scan(
        str(FIX / "photo1.jpg"))
    assert res.context.commodity_category == "cosmetic"
    assert not any("Alcoholic" in f.message for f in res.findings)
