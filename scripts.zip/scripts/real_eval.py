#!/usr/bin/env python3
"""
Score the system on REAL photos, from saved PaddleOCR output.

    python scripts/real_eval.py                  # tests/fixtures/real
    python scripts/real_eval.py --dir my_photos  # any folder laid out the same way

A folder holds, per photo: `<name>.jpg`, one or more `<name>*.paddle.json`
OCR dumps (as written by scan_photo.py into data/ocr_dumps/), and one
`ground_truth.yaml` saying what is really printed on each photo (see the
one in tests/fixtures/real for the format).

No OCR model is loaded: each dump is replayed through the full pipeline
(extraction, classification, rules). So this measures what the system
does with what Paddle actually read on real packaging - the numbers you
can put on a slide, with the sample size next to them.

Reported per photo and in total:
  read correctly   - field found with the right value
  read wrongly     - field found with a WRONG value (the dangerous kind)
  missed           - printed and legible, but not found (INDETERMINATE)
  false violations - violations on packs that are compliant
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

DEFAULT_DIR = Path(__file__).resolve().parents[1] / "tests" / "fixtures" / "real"


def _matches(expected, decl) -> bool:
    if decl is None or not decl.present:
        return False
    if expected == "present":
        return True
    if isinstance(expected, (int, float)):
        try:
            return abs(float(decl.value) - float(expected)) < 0.011
        except (TypeError, ValueError):
            return False
    exp = str(expected).strip().lower()
    parts = exp.split()
    if len(parts) == 2 and parts[0].replace(".", "", 1).isdigit():
        # "45 ml" -> value + unit
        try:
            return (abs(float(decl.value) - float(parts[0])) < 0.011
                    and (decl.unit or "").lower() == parts[1])
        except (TypeError, ValueError):
            return False
    return exp in str(decl.value).lower() or exp in (decl.raw_text or "").lower()


def evaluate_dir(folder: Path, verbose: bool = True) -> dict:
    import yaml

    from src.core.pipeline import CompliancePipeline, PipelineConfig
    from src.vision.ocr.paddle import ReplayOCR

    truth = yaml.safe_load((folder / "ground_truth.yaml").read_text(encoding="utf-8"))
    rows = []
    for dump in sorted(folder.glob("*.paddle.json")):
        stem = dump.name[: -len(".paddle.json")]
        photo_key = stem.split(".")[0]
        variant = stem[len(photo_key) + 1:] or "default"
        gt = truth.get(photo_key)
        img = folder / f"{photo_key}.jpg"
        if gt is None or not img.exists():
            continue
        # "<photo>.paddle.json" is the default read (photo as taken);
        # "<photo>.enhanced.paddle.json" was read after our
        # deglare/contrast/sharpen pass (PipelineConfig.ocr_on_enhanced).
        cfg = PipelineConfig(ocr_on_enhanced=(variant == "enhanced"))
        res = CompliancePipeline(ocr=ReplayOCR(dump), config=cfg).scan(str(img))

        row = {"photo": photo_key, "variant": variant, "correct": [], "wrong": [],
               "missed": [], "false_absent": [], "false_violations": []}
        for field, exp in (gt.get("fields") or {}).items():
            d = res.declaration(field)
            if exp in ("not_legible", "not_on_panel"):
                if any(f.field_id == field and f.outcome.value == "VIOLATION"
                       and f.rule_id.endswith("presence") for f in res.findings):
                    row["false_absent"].append(field)
                continue
            if _matches(exp, d):
                row["correct"].append(field)
            elif d is not None and d.present:
                row["wrong"].append(f"{field}={d.value!r} (expected {exp!r})")
            else:
                row["missed"].append(field)
        expected_v = set(gt.get("expected_violations") or [])
        row["false_violations"] = [f"{f.rule_id}: {f.message[:80]}"
                                   for f in res.violations if f.rule_id not in expected_v]
        rows.append(row)

    tot = {k: sum(len(r[k]) for r in rows)
           for k in ("correct", "wrong", "missed", "false_absent", "false_violations")}
    if verbose:
        for r in rows:
            print(f"\n{r['photo']} [{r['variant']}]  correct {len(r['correct'])}, "
                  f"wrong {len(r['wrong'])}, missed {len(r['missed'])}, "
                  f"false violations {len(r['false_violations'])}")
            for k in ("wrong", "missed", "false_absent", "false_violations"):
                for item in r[k]:
                    print(f"   {k:17s} {item}")
        for variant in sorted({r["variant"] for r in rows}):
            sub = [r for r in rows if r["variant"] == variant]
            c = sum(len(r["correct"]) for r in sub)
            w = sum(len(r["wrong"]) for r in sub)
            m = sum(len(r["missed"]) for r in sub)
            fv = sum(len(r["false_violations"]) for r in sub)
            n = c + w + m
            print(f"\nTOTAL [{variant}] over {len(sub)} real photo(s): "
                  f"{c}/{n} legible declarations read correctly, {w} read wrongly, "
                  f"{m} missed; {fv} false violation(s).")
    return {"rows": rows, "totals": tot}


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dir", default=str(DEFAULT_DIR))
    ap.add_argument("--json", default=None, help="Also write the results here")
    args = ap.parse_args()
    out = evaluate_dir(Path(args.dir))
    if args.json:
        Path(args.json).write_text(json.dumps(out, indent=1))


if __name__ == "__main__":
    main()
