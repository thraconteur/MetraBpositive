#!/usr/bin/env python3
"""
Scan real photos with PaddleOCR and write one compliance report per photo.

    python scripts/scan_photo.py back_9.jpeg
    python scripts/scan_photo.py photos/                     # every image in a folder
    python scripts/scan_photo.py back_9.jpeg --secondary-lang hi   # bilingual label
    python scripts/scan_photo.py back_9.jpeg --replay data/ocr_dumps/back_9.paddle.json

PaddleOCR is the only engine. If it is not installed this stops and
says so - it never quietly reads with something weaker.

Each scan writes three things:
  data/reports/<photo>.html          the inspector report (also shows the
                                     raw OCR lines and what was extracted)
  data/ocr_dumps/<photo>.paddle.json exactly what Paddle read - send this
                                     back when a report looks wrong
  data/.ocr_cache/                   cached OCR, so re-running the same
                                     photo after a code change skips the
                                     model entirely (--no-cache to force)

--replay re-runs everything downstream of OCR from a saved dump without
loading any model, in well under a second. Use it to check an
extraction or rules fix against a photo someone else scanned.
"""

import argparse
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}


def _photos(paths: list[str]) -> list[Path]:
    out: list[Path] = []
    for p in map(Path, paths):
        if p.is_dir():
            out += sorted(q for q in p.iterdir() if q.suffix.lower() in IMAGE_EXTS)
        elif p.exists():
            out.append(p)
        else:
            sys.exit(f"No such file or folder: {p}")
    if not out:
        sys.exit("No images found.")
    return out


def _build_ocr(args):
    if args.replay:
        from src.vision.ocr.paddle import ReplayOCR

        return ReplayOCR(args.replay), f"replay of {args.replay}"

    from src.vision.ocr.paddle import PaddleConfig, PaddleOCRBackend

    cfg = dict(
        lang=args.lang,
        ocr_version=args.ocr_version,
        secondary_lang=args.secondary_lang,
        device=args.device,
        enable_mkldnn=args.mkldnn,
        text_det_limit_side_len=args.det_side,
    )
    if args.no_upscale:
        cfg["upscale_short_side_below"] = 0
    if args.no_refine:
        cfg["refine_below_score"] = 0.0
    if args.det_thresh is not None:
        cfg["text_det_thresh"] = args.det_thresh
    if args.box_thresh is not None:
        cfg["text_det_box_thresh"] = args.box_thresh
    if args.unclip is not None:
        cfg["text_det_unclip_ratio"] = args.unclip
    config = PaddleConfig(**{k: v for k, v in cfg.items() if v is not None})

    ocr = PaddleOCRBackend(config=config,
                           cache_dir=None if args.no_cache else
                           Path(__file__).resolve().parents[1] / "data" / ".ocr_cache")
    if not ocr.available():
        sys.exit(
            "PaddleOCR is not installed in this Python environment.\n"
            "    pip install paddlepaddle paddleocr\n"
            "(Check with: python -c \"import paddleocr; print(paddleocr.__version__)\")"
        )
    desc = f"paddleocr lang={config.lang} rec={ocr._rec_model_name(config.lang)}"
    if config.secondary_lang:
        desc += f" + {config.secondary_lang} re-read"
    return ocr, desc


def _parse_panel(txt):
    if not txt:
        return None
    import re

    m = re.fullmatch(r"\s*(\d+(?:\.\d+)?)\s*[xX*,]\s*(\d+(?:\.\d+)?)\s*", txt)
    if not m:
        sys.exit("--panel-mm must look like 95x70 (width x height in mm).")
    return float(m.group(1)), float(m.group(2))


def _build_vlm(choice):
    if not choice:
        return None
    from src.vision.ocr.vlm_gemini import GeminiReader, VLMUnavailable

    reader = GeminiReader()
    try:
        reader.check()
    except VLMUnavailable as exc:
        sys.exit(str(exc))
    return reader


def _print_scan(result, out, st):
    print(f"  OCR          : {st.get('regions', len(result.spans))} lines"
          + (" (cached)" if st.get("cache_hit") else
             f" in {st.get('total_s', '?')}s"
             + (f" (model load {st['model_load_s']}s)" if st.get("model_load_s") else "")
             + (f", {st['refined']} weak line(s) re-read" if st.get("refined") else "")
             + (f", {st['secondary_replaced']} Devanagari" if st.get("secondary_replaced") else "")))
    if st.get("dump"):
        print(f"  OCR dump     : {st['dump']}")
    if st.get("vertical_bands"):
        print(f"  rotated text : {st['vertical_bands']} vertical band(s) re-read")
    v = st.get("vlm")
    if v:
        print(f"  second read  : {v.get('model')} asked for {len(v.get('asked', []))}, "
              f"found {v.get('found', [])}, confirmed by OCR {v.get('confirmed_by_ocr', [])}"
              + (f", ERROR {v['error']}" if v.get("error") else ""))
    cal = result.calibration
    print(f"  scale        : " + (f"{cal.px_per_mm:.2f} px/mm ({cal.method.value})"
                                  if cal.available else f"none - {cal.notes[:90]}"))
    print("  extracted    :")
    for d in result.declarations:
        if not d.present:
            continue
        val = "" if d.value is None else f" -> {d.value}{(' ' + d.unit) if d.unit else ''}"
        src = "" if getattr(d, "source", "ocr") == "ocr" else f"  [{d.source}]"
        print(f"    {d.field_id:22s} {d.raw_text[:60]!r}{val}{src}")
        for n in d.notes or []:
            print(f"    {'':22s} note: {n}")
    verdict = {True: "COMPLIANT", False: "NON-COMPLIANT", None: "UNDECIDED"}[result.is_compliant]
    print(f"  verdict      : {verdict}  ({len(result.violations)} violation(s), "
          f"{len(result.indeterminate)} indeterminate)")
    for f in result.violations:
        print(f"    VIOLATION  {f.citation}: {f.message[:110]}")
    print(f"  report       : {out}")


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("photos", nargs="+", help="Photo(s) or folder(s) to scan")
    ap.add_argument("--out", default=None,
                    help="Output path (single photo only; default data/reports/<name>.<fmt>)")
    ap.add_argument("--fmt", default="html", choices=["html", "pdf", "json"])
    ap.add_argument("--coverage-complete", action="store_true",
                    help="Assert the photo(s) show EVERY panel, so a missing field is "
                         "a VIOLATION rather than INDETERMINATE.")
    ap.add_argument("--panel-mm", default=None, metavar="WxH",
                    help="Real size of the photographed panel in mm, measured with a "
                         "ruler (e.g. 95x70). Gives a millimetre scale when there is no "
                         "printed marker in the photo. Never paste a marker into a photo.")
    ap.add_argument("--vlm", default=None, choices=["gemini"],
                    help="Ask a vision-language model for declarations OCR missed "
                         "(needs internet and GEMINI_API_KEY). Its reads are marked "
                         "on the report and never decide a verdict alone.")

    g = ap.add_argument_group("OCR")
    g.add_argument("--lang", default="en", choices=["en", "hi"],
                   help="Primary recognition language (default en - the strongest model; "
                        "use --secondary-lang hi for bilingual labels instead)")
    g.add_argument("--secondary-lang", default=None, choices=["hi"],
                   help="Re-read every line with this recogniser and keep the result "
                        "where it contains that script (bilingual labels)")
    g.add_argument("--ocr-version", default=None,
                   choices=["PP-OCRv3", "PP-OCRv4", "PP-OCRv5", "PP-OCRv6"],
                   help="Model generation (default: PaddleOCR's choice for the "
                        "language - PP-OCRv6 medium for en)")
    g.add_argument("--device", default=None, help="cpu, gpu:0, ... (default: auto)")
    g.add_argument("--mkldnn", action="store_true",
                   help="Enable oneDNN. Faster on CPU, but crashes on some Windows "
                        "machines - off by default")
    g.add_argument("--det-side", type=int, default=None,
                   help="Detection input min side (default 1280)")
    g.add_argument("--det-thresh", type=float, default=None)
    g.add_argument("--box-thresh", type=float, default=None)
    g.add_argument("--unclip", type=float, default=None)
    g.add_argument("--no-upscale", action="store_true",
                   help="Do not upscale small photos before OCR")
    g.add_argument("--no-refine", action="store_true",
                   help="Do not re-read low-confidence lines")
    g.add_argument("--no-cache", action="store_true", help="Ignore the OCR cache")
    g.add_argument("--replay", default=None,
                   help="Use a saved .paddle.json dump instead of running Paddle")
    args = ap.parse_args()

    os.environ.setdefault("SIH_OCR_BACKEND", "paddle")
    photos = _photos(args.photos)
    if args.replay and len(photos) != 1:
        sys.exit("--replay takes exactly one photo (the one the dump was made from).")
    if args.out and len(photos) != 1:
        sys.exit("--out takes exactly one photo; use the default naming for batches.")

    from src.core.pipeline import CompliancePipeline
    from src.report.builder import build_report

    ocr, desc = _build_ocr(args)
    vlm = _build_vlm(args.vlm)
    print(f"engine: {desc}" + (f" + {vlm.label()} for missed fields" if vlm else ""))
    pipeline = CompliancePipeline(ocr=ocr, vlm=vlm)
    panel = _parse_panel(args.panel_mm)

    for photo in photos:
        print(f"\n{photo}")
        t0 = time.perf_counter()
        result = pipeline.scan(str(photo), panel_size_mm=panel)
        if args.coverage_complete:
            # Presence findings depend on coverage_complete, which is
            # only known here - so evaluate again with it set.
            result.coverage_complete = True
            result.findings = []
            pipeline.engine.evaluate(result)

        try:
            from src.report.builder import extract_evidence_crops

            extract_evidence_crops(result, Path("data/evidence") / result.scan_id)
        except Exception as exc:          # evidence must never fail the scan
            print(f"  (evidence crops failed: {exc})")

        out = (Path(args.out) if args.out
               else Path("data/reports") / f"{photo.stem}.{args.fmt}")
        out.parent.mkdir(parents=True, exist_ok=True)
        if args.fmt == "json":
            import json

            out.write_text(json.dumps(result.to_dict(), indent=1, ensure_ascii=False,
                                      default=str))
        else:
            out = build_report(result, out, fmt=args.fmt) or out
        _print_scan(result, out, dict(result.ocr_stats or {}))
        print(f"  total        : {time.perf_counter() - t0:.1f}s")


if __name__ == "__main__":
    main()
